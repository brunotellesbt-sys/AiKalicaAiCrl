import { Injectable } from '@angular/core';
import { SettingsService } from '../settings-service/settings.service';
import { nationalDexPokemon } from '../pokemon-service/national-dex-pokemon';

/**
 * Cry playback
 *
 * Sources used (in order):
 *  1) public/data/custom-cries.json (explicit URL overrides)
 *  2) public/cries/** (local overrides for GitHub Pages)
 *  3) Veekun OGG cries (per National Dex number, some form suffixes)
 *  4) GitHub mirror (OGG cries by National Dex id)
 *
 * Notes:
 * - We do NOT call PokeAPI and do NOT use Pokemon Showdown as an audio source.
 * - For Mega forms: we try a Mega-specific cry first; if unavailable we fall back to the base species cry
 *   (this avoids "no sound" for any Mega).
 */
@Injectable({
  providedIn: 'root',
})
export class CryService {
  // Optional local override directory (GitHub Pages-friendly).
  // Example: public/cries/mega/charizard-mega-x.(ogg|mp3|wav)
  private readonly localCryBase = new URL('cries', document.baseURI).toString().replace(/\/$/, '');

  // Veekun: per-form cry files as OGGs, keyed by National Dex number.
  // Example: https://veekun.com/dex/media/pokemon/cries/6-mega-x.ogg
  private readonly veekunCryBase = 'https://veekun.com/dex/media/pokemon/cries';

  // A GitHub mirror of the PokeAPI/cries repo structure (but hosted on githubusercontent).
  // We only use the "latest" base cries by National Dex ID.
  // Example: https://raw.githubusercontent.com/pvcsam-repo-fork/cries-pokemon/main/cries/pokemon/latest/25.ogg
  private readonly githubCriesLatestBase =
    'https://raw.githubusercontent.com/pvcsam-repo-fork/cries-pokemon/main/cries/pokemon/latest';

  // Runtime overrides: public/data/custom-cries.json
  private customCryMapPromise: Promise<Record<string, string>> | null = null;

  // Audio unlock flag for mobile autoplay policies.
  private unlocked = false;

  // Name -> dexId index (built from our local dex list).
  private readonly nameToDexId = new Map<string, number>();

  constructor(private settings: SettingsService) {
    this.buildNameIndex();
  }

  private buildNameIndex(): void {
    for (const p of nationalDexPokemon) {
      if (typeof (p as any)?.text === 'string' && (p as any).text.startsWith('pokemon.')) {
        const key = (p as any).text.slice('pokemon.'.length);
        // Keep the first occurrence.
        if (!this.nameToDexId.has(key)) {
          this.nameToDexId.set(key, (p as any).pokemonId);
        }
      }
    }
  }

  /**
   * Call on first user interaction (pointerdown/click) to unlock audio on mobile browsers.
   * Safe to call many times.
   */
  async unlockAudio(): Promise<void> {
    if (this.unlocked) return;
    if (this.settings.currentSettings.muteAudio) return;

    try {
      const a = new Audio(new URL('silence.wav', document.baseURI).toString());
      a.volume = 0;
      await a.play().catch(() => {});
      this.unlocked = true;
    } catch {
      // ignore
    }
  }

  /**
   * Start warming cache while Mega Evolution animation plays.
   */
  async prefetchMegaCry(megaApiName: string): Promise<void> {
    const customMap = await this.loadCustomCryMap();
    const urls = this.buildMegaCryPrefetchUrls(megaApiName, customMap);
    this.prefetchUrls(urls);
  }

  /**
   * Plays the Mega cry after the 3s blink.
   * If Mega-specific cries aren't available, it falls back to base-species cries.
   */
  async playMegaCryOrSynthetic(_seed: string, megaApiName: string): Promise<void> {
    if (this.settings.currentSettings.muteAudio) return;

    const customMap = await this.loadCustomCryMap();
    const urls = this.buildMegaCryPrefetchUrls(megaApiName, customMap);

    const unique = Array.from(new Set(urls.filter(Boolean)));
    for (const url of unique) {
      const ok = await this.tryPlayAudioUrl(url);
      if (ok) return;
    }

    // No fallback beyond this (we simply skip sound if everything fails).
    // This keeps behavior predictable and avoids unwanted synthetic sounds.
  }

  // ------------------------------------------------------------
  // Custom cry map
  // ------------------------------------------------------------

  private async loadCustomCryMap(): Promise<Record<string, string>> {
    if (this.customCryMapPromise) return this.customCryMapPromise;

    this.customCryMapPromise = (async () => {
      try {
        const res = await fetch(new URL('data/custom-cries.json', document.baseURI).toString(), { cache: 'no-cache' });
        if (!res.ok) return {};
        const json = await res.json();
        if (!json || typeof json !== 'object') return {};
        return (json as any).cries && typeof (json as any).cries === 'object' ? (json as any).cries : {};
      } catch {
        return {};
      }
    })();

    return this.customCryMapPromise;
  }

  // ------------------------------------------------------------
  // URL building
  // ------------------------------------------------------------

  private buildMegaCryPrefetchUrls(megaApiName: string, customMap: Record<string, string>): string[] {
    const baseName = this.deriveBaseSpeciesName(megaApiName);
    const dexId = this.getDexIdForName(megaApiName) ?? this.getDexIdForName(baseName);

    const megaKey = this.toCanonicalCryKey(megaApiName);
    const baseKey = this.toCanonicalCryKey(baseName);

    const customMega = customMap?.[megaApiName] || customMap?.[megaKey] || '';
    const customBase = customMap?.[baseName] || customMap?.[baseKey] || '';

    const urls: string[] = [];

    // --- Mega form (prefer form-specific) ---
    if (customMega) urls.push(customMega);

    // Local overrides
    urls.push(`${this.localCryBase}/mega/${megaApiName}.mp3`);
    urls.push(`${this.localCryBase}/mega/${megaApiName}.ogg`);
    urls.push(`${this.localCryBase}/mega/${megaApiName}.wav`);
    if (megaKey !== megaApiName) {
      urls.push(`${this.localCryBase}/mega/${megaKey}.mp3`);
      urls.push(`${this.localCryBase}/mega/${megaKey}.ogg`);
      urls.push(`${this.localCryBase}/mega/${megaKey}.wav`);
    }

    // Veekun Mega-form OGG (if we can resolve a dex id and a known suffix)
    if (dexId != null) {
      const suffix = this.resolveCryFormSuffix(megaApiName);
      if (suffix) {
        urls.push(`${this.veekunCryBase}/${dexId}${suffix}.ogg`);
      }
    }

    // --- Base species fallback (guarantee a cry plays) ---
    if (customBase) urls.push(customBase);

    urls.push(`${this.localCryBase}/base/${baseName}.mp3`);
    urls.push(`${this.localCryBase}/base/${baseName}.ogg`);
    urls.push(`${this.localCryBase}/base/${baseName}.wav`);
    if (baseKey !== baseName) {
      urls.push(`${this.localCryBase}/base/${baseKey}.mp3`);
      urls.push(`${this.localCryBase}/base/${baseKey}.ogg`);
      urls.push(`${this.localCryBase}/base/${baseKey}.wav`);
    }

    if (dexId != null) {
      // Veekun base
      urls.push(`${this.veekunCryBase}/${dexId}.ogg`);
      // GitHub mirror base
      urls.push(`${this.githubCriesLatestBase}/${dexId}.ogg`);
    }

    return urls;
  }

  /**
   * A deterministic, filesystem-friendly cry key.
   * (Historically this matches the Showdown naming conventions, but we don't depend on Showdown as a source.)
   */
  private toCanonicalCryKey(apiName: string): string {
    let s = (apiName || '').toLowerCase();
    // Common punctuation normalization
    s = s.replace(/[':.]/g, '');
    // Collapse some known awkward names
    s = s.replace(/mr-mime/g, 'mrmime');
    s = s.replace(/mime-jr/g, 'mimejr');
    s = s.replace(/porygon-z/g, 'porygonz');

    // Megas in some sources use "-megax" instead of "-mega-x".
    s = s.replace(/-mega-x/g, '-megax');
    s = s.replace(/-mega-y/g, '-megay');

    return s;
  }

  /**
   * Resolve our local National Dex id for a given form name.
   *
   * Strategy:
   * - Try exact match (if the apiName happens to be a base species name).
   * - Otherwise, progressively strip trailing "-segment" parts until it matches a known base species.
   */
  private getDexIdForName(formName: string): number | null {
    if (!formName) return null;

    let candidate = formName.toLowerCase();
    if (this.nameToDexId.has(candidate)) return this.nameToDexId.get(candidate)!;

    while (candidate.includes('-')) {
      candidate = candidate.slice(0, candidate.lastIndexOf('-'));
      if (this.nameToDexId.has(candidate)) return this.nameToDexId.get(candidate)!;
    }

    return null;
  }

  /**
   * Extract a base-species name from a form apiName.
   */
  private deriveBaseSpeciesName(formApiName: string): string {
    const s = (formApiName || '').toLowerCase();

    // Try explicit Mega patterns first
    if (s.endsWith('-mega-x')) return s.slice(0, -'-mega-x'.length);
    if (s.endsWith('-mega-y')) return s.slice(0, -'-mega-y'.length);
    if (s.endsWith('-mega-z')) return s.slice(0, -'-mega-z'.length);
    if (s.endsWith('-mega')) return s.slice(0, -'-mega'.length);

    // Other special forms we allow (keep consistent behavior)
    if (s.endsWith('-primal')) return s.slice(0, -'-primal'.length);
    if (s.endsWith('-origin')) return s.slice(0, -'-origin'.length);
    if (s.endsWith('-eternamax')) return s.slice(0, -'-eternamax'.length);
    if (s.endsWith('-terastal')) return s.slice(0, -'-terastal'.length);
    if (s.endsWith('-stellar')) return s.slice(0, -'-stellar'.length);

    return s;
  }

  /**
   * Veekun form suffixes we support.
   */
  private resolveCryFormSuffix(formApiName: string): string {
    const s = (formApiName || '').toLowerCase();

    if (s.endsWith('-mega-x')) return '-mega-x';
    if (s.endsWith('-mega-y')) return '-mega-y';
    // "Mega Z" isn't a Veekun-specific suffix; use the base Mega cry.
    if (s.endsWith('-mega-z')) return '-mega';
    if (s.endsWith('-mega')) return '-mega';

    if (s.endsWith('-primal')) return '-primal';
    if (s.endsWith('-origin')) return '-origin';

    // If it's not a known veekun suffix, return '' so we skip the per-form URL.
    return '';
  }

  // ------------------------------------------------------------
  // Prefetch
  // ------------------------------------------------------------

  private prefetchUrls(urls: string[]): void {
    const unique = Array.from(new Set(urls.filter(Boolean)));
    if (!unique.length) return;

    // Prefer Service Worker cache if available.
    try {
      const ctrl = navigator?.serviceWorker?.controller;
      if (ctrl) {
        ctrl.postMessage({ type: 'PREFETCH', urls: unique });
        return;
      }
    } catch {
      // ignore
    }

    // Fallback: warm browser cache.
    for (const url of unique) {
      try {
        fetch(url, { mode: 'no-cors', cache: 'force-cache' }).catch(() => {});
      } catch {
        // ignore
      }
    }
  }

  // ------------------------------------------------------------
  // Playback
  // ------------------------------------------------------------

  private async tryPlayAudioUrl(url: string): Promise<boolean> {
    return new Promise<boolean>((resolve) => {
      const audio = new Audio();
      audio.preload = 'auto';
      audio.src = url;

      let done = false;

      const cleanup = () => {
        audio.removeEventListener('ended', onEnded);
        audio.removeEventListener('error', onError);
        audio.removeEventListener('loadedmetadata', onLoadedMetadata);
        try {
          audio.pause();
        } catch {
          // ignore
        }
      };

      let timeoutId: number | null = null;

      const setTimeoutSafe = (ms: number) => {
        if (timeoutId != null) window.clearTimeout(timeoutId);
        timeoutId = window.setTimeout(() => finish(false), ms);
      };

      const finish = (ok: boolean) => {
        if (done) return;
        done = true;
        if (timeoutId != null) window.clearTimeout(timeoutId);
        cleanup();
        resolve(ok);
      };

      const onEnded = () => finish(true);
      const onError = () => finish(false);

      // Avoid hanging forever on a dead URL.
      const onLoadedMetadata = () => {
        try {
          const dur = audio.duration;
          const ms = Number.isFinite(dur) && dur > 0 ? Math.min(60000, Math.ceil(dur * 1000) + 2500) : 60000;
          setTimeoutSafe(ms);
        } catch {
          setTimeoutSafe(60000);
        }
      };

      setTimeoutSafe(15000);

      audio.addEventListener('ended', onEnded);
      audio.addEventListener('error', onError);
      audio.addEventListener('loadedmetadata', onLoadedMetadata);

      try {
        const p = audio.play();
        if (p && typeof (p as any).catch === 'function') {
          (p as Promise<void>).catch(() => finish(false));
        }
      } catch {
        finish(false);
      }
    });
  }
}
