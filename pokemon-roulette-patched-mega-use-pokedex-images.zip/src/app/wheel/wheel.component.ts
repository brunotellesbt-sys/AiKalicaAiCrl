import { AfterViewInit, Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { WheelItem } from '../interfaces/wheel-item';
import { DarkModeService } from '../services/dark-mode-service/dark-mode.service';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { GameStateService } from '../services/game-state-service/game-state.service';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { AudioService } from '../services/audio-service/audio.service';

@Component({
  selector: 'app-wheel',
  imports: [
    CommonModule,
    TranslatePipe
  ],
  templateUrl: './wheel.component.html',
  styleUrl: './wheel.component.css'
})
export class WheelComponent implements AfterViewInit, OnChanges, OnDestroy {

  wheelCanvas!: HTMLCanvasElement;
  wheelCtx!: CanvasRenderingContext2D;
  pointerCanvas!: HTMLCanvasElement;
  pointerCtx!: CanvasRenderingContext2D;
  @Input() items: WheelItem[] = [];
  /**
   * Optional font scaling for wheel segment labels.
   * Useful for wheels with long labels on small screens.
   */
  @Input() fontScale: number = 1;
  @Output() selectedItemEvent = new EventEmitter<number>();
  spinning = false;
  darkMode!: Observable<boolean>;

  canvasHeight: number;
  wheelWidth: number;
  cursorWidth: number;
  fontSize: number;
  currentRotation = 0;
  startTime = 0;
  totalRotations!: number;
  duration = Math.floor(Math.random() * (5000 - 3000)) + 3000;
  finalRotation = 0;
  pointerStrokeColor = 'blue';
  pointerFillColor = 'yellow';
  winningNumber!: number;
  currentSegment: string = '-';
  clickAudio!: HTMLAudioElement;
  
  private translatedItems: WheelItem[] = [];

  private readonly MIN_WHEEL_SIZE = 240;
  private readonly MAX_WHEEL_SIZE = 520;

  private readonly onResize = () => {
    this.computeCanvasSizes();
    // Redraw at current rotation (avoid visible reset while spinning)
    if (this.wheelCanvas && this.pointerCanvas) {
      // Ensure canvas element dimensions match the newly computed sizes.
      this.wheelCanvas.width = this.wheelWidth;
      this.wheelCanvas.height = this.canvasHeight;
      this.pointerCanvas.width = this.cursorWidth;
      this.pointerCanvas.height = this.canvasHeight;

      this.drawWheel(this.spinning ? this.currentRotation : 0);
      this.drawPointer();
    }
  };

  constructor(
    private darkModeService: DarkModeService,
    private gameStateService: GameStateService,
    private translateService: TranslateService,
    private audioService: AudioService
  ) {
    this.clickAudio = this.audioService.createAudio('./click.mp3');
    this.darkMode = this.darkModeService.darkMode$;

    // Responsive sizing: on mobile the wheel was too small (0.50 of min dimension).
    // We compute a size that fits the viewport width while still keeping enough room
    // for the pointer canvas.
    this.canvasHeight = 300;
    this.wheelWidth = 300;
    this.cursorWidth = 40;
    this.fontSize = this.wheelWidth / 24;
    this.computeCanvasSizes();
  }

  // Keep the wheel readable when rotating the phone or resizing the browser.
  // (Using a method instead of a HostListener avoids importing more decorators.)
  private computeCanvasSizes(): void {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const isMobile = vw <= 576;

    // Pointer canvas width
    this.cursorWidth = isMobile ? 28 : 40;

    // Leave some space for padding + pointer + a small gap.
    const horizontalPadding = isMobile ? 16 : 24;
    const gap = isMobile ? 8 : 10;
    const maxByWidth = Math.max(0, vw - this.cursorWidth - horizontalPadding - gap);
    const maxByHeight = vh * (isMobile ? 0.55 : 0.50);

    const size = Math.floor(
      Math.max(
        this.MIN_WHEEL_SIZE,
        Math.min(this.MAX_WHEEL_SIZE, maxByWidth, maxByHeight)
      )
    );

    this.canvasHeight = size;
    this.wheelWidth = size;
    const baseFont = this.wheelWidth / (isMobile ? 20 : 24);
    this.fontSize = baseFont * (this.fontScale || 1);
  }

  ngAfterViewInit(): void {
    this.wheelCanvas = <HTMLCanvasElement>document.getElementById('wheel');
    this.wheelCtx = this.wheelCanvas.getContext('2d')!;
    this.pointerCanvas = <HTMLCanvasElement>document.getElementById('pointer');
    this.pointerCtx = this.pointerCanvas.getContext('2d')!;

    // Ensure the canvas element dimensions match our computed bindings (especially on mobile).
    this.wheelCanvas.width = this.wheelWidth;
    this.wheelCanvas.height = this.canvasHeight;
    this.pointerCanvas.width = this.cursorWidth;
    this.pointerCanvas.height = this.canvasHeight;
    if (this.items.length >= 32) {
      this.fontSize = Math.min(this.fontSize, 10);
    } else if(this.items.length >= 16) {
      this.fontSize = Math.min(this.fontSize, 14);
    }
    
    // Wait for translations to be ready
    this.translateService.get('wheel.spin').subscribe(() => {
      this.preprocessTranslations();
      this.drawWheel();
      this.drawPointer();
    });

    // Resize after view init so bindings apply with the latest viewport.
    window.addEventListener('resize', this.onResize, { passive: true });
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.onResize);
  }

  ngOnChanges(changes: SimpleChanges): void {
    const itemsChanged = changes['items'] && !changes['items'].firstChange;
    const fontScaleChanged = changes['fontScale'] && !changes['fontScale'].firstChange;

    if (itemsChanged || fontScaleChanged) {
      // Recompute sizes so fontScale is applied consistently.
      this.computeCanvasSizes();
      this.translateService.get('wheel.spin').subscribe(() => {
        this.preprocessTranslations();
        // If items change while the wheel is spinning, redraw at the current rotation
        // to avoid a visible "reset".
        this.drawWheel(this.spinning ? this.currentRotation : 0);
        this.drawPointer();
      });
    }
  }

  private preprocessTranslations(): void {
    this.translatedItems = this.items.map(item => ({
      ...item,
      text: this.safeInstant(item.text)
    }));
  }

  /**
   * ngx-translate returns the key itself when a translation isn't available yet.
   * We never want to render raw keys on the wheel (e.g. "items.super-potion.name").
   */
  private safeInstant(key: string): string {
    const k = (key ?? '').toString();
    if (!k) return '';
    const t = this.translateService.instant(k);
    if (!t || t === k) return this.humanizeKey(k);
    return t;
  }

  private humanizeKey(key: string): string {
    const k = (key ?? '').toString();
    // items.super-potion.name -> Super Potion
    const m1 = k.match(/^items\.(.+)\.name$/);
    if (m1?.[1]) return this.titleCaseFromToken(m1[1]);

    // items.super-potion.description -> Super Potion
    const m2 = k.match(/^items\.(.+)\.description$/);
    if (m2?.[1]) return this.titleCaseFromToken(m2[1]);

    // pokemon.meganium -> Meganium
    const m3 = k.match(/^pokemon\.(.+)$/);
    if (m3?.[1]) return this.titleCaseFromToken(m3[1]);

    const last = k.split('.').pop() || k;
    return this.titleCaseFromToken(last);
  }

  private titleCaseFromToken(token: string): string {
    return (token || '')
      .replace(/[_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .split(' ')
      .filter(Boolean)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }

  private drawWheel(rotation = 0): void {
    const centerX = this.wheelCanvas.width / 2;
    const centerY = this.wheelCanvas.height / 2;
    const radius = (this.wheelCanvas.width / 2);

    const totalWeight = this.getTotalWeights();
    const arcSize = (2 * Math.PI) / (totalWeight);
    this.wheelCtx.clearRect(0, 0, this.wheelCanvas.width, this.wheelCanvas.height);

    let startAngle = rotation;
    for (let index = 0; index < this.translatedItems.length; index++) {
      const item = this.translatedItems[index];
      const segmentSize = arcSize * item.weight;
      const endAngle = startAngle + segmentSize;

      /** Draw the segment */
      this.wheelCtx.beginPath();
      this.wheelCtx.arc(centerX, centerY, radius, startAngle, endAngle);
      this.wheelCtx.lineTo(centerX, centerY);
      this.wheelCtx.fillStyle = item.fillStyle;
      this.wheelCtx.fill();

      if (this.translatedItems.length < 160) {
        /** Draw the text */
        this.wheelCtx.save();
        this.wheelCtx.translate(centerX, centerY);
        this.wheelCtx.rotate(startAngle + segmentSize / 2);
        this.wheelCtx.fillStyle = '#fff';
        this.wheelCtx.font = this.fontSize + 'px Arial';
        this.wheelCtx.textAlign = 'right';
        this.wheelCtx.fillText(item.text, radius - 7, 5);
        this.wheelCtx.restore();
      }

      startAngle = endAngle;
    }
  }

  drawPointer(): void {
    this.pointerCtx.save();
    this.pointerCtx.lineWidth = 2;
    this.pointerCtx.strokeStyle = this.pointerStrokeColor;
    this.pointerCtx.fillStyle = this.pointerFillColor;
    this.pointerCtx.beginPath();
    this.pointerCtx.moveTo(this.pointerCanvas.width - 2, (this.pointerCanvas.height / 2) - 20);
    this.pointerCtx.lineTo(this.pointerCanvas.width - 2, (this.pointerCanvas.height / 2) + 20);
    this.pointerCtx.lineTo(this.pointerCanvas.width - this.cursorWidth, this.pointerCanvas.height / 2);
    this.pointerCtx.lineTo(this.pointerCanvas.width - 2, (this.pointerCanvas.height / 2) - 20);
    this.pointerCtx.stroke();
    this.pointerCtx.fill();
    this.pointerCtx.restore();
  }

  spinWheel(): void {
    if (this.spinning) {
      return;
    }

    this.spinning = true;
    this.gameStateService.setWheelSpinning(this.spinning);


    this.startTime = performance.now();
    const totalWeight = this.getTotalWeights();
    const arcSize = (2 * Math.PI) / (totalWeight);

    this.winningNumber = this.getRandomWeightedIndex();

    this.totalRotations = Math.floor(Math.random() * 4) + 1;

    let winningAngle = 0;
    const winningSegmentSize = arcSize * this.items[this.winningNumber].weight;

    for (let index = 0; index < this.items.length; index++) {
      const item = this.items[index];
      winningAngle += arcSize * item.weight;
      if (index === this.winningNumber) {
        break;
      }
    }

    const offset = Math.random() * winningSegmentSize;
    this.finalRotation = this.totalRotations * 2 * Math.PI + (2 * Math.PI - winningAngle + offset);

    requestAnimationFrame(this.animate.bind(this));
  }

  private animate(currentTime: number): void {
    const elapsed = currentTime - this.startTime;
    const progress = Math.min(elapsed / this.duration, 1);
    const easedProgress = 1 - Math.pow(1 - progress, 3);
    this.currentRotation = easedProgress * this.finalRotation;

    const totalWeight = this.getTotalWeights();

    this.drawWheel(this.currentRotation);

    if (progress < 1) {
      requestAnimationFrame(this.animate.bind(this));
    } else {
      this.spinning = false;
      this.selectedItemEvent.emit(this.winningNumber);
      this.gameStateService.setWheelSpinning(false);
    }

    const segment = this.getCurrentSegment();

    if (segment !== this.currentSegment) {
      this.currentSegment = segment;
      this.audioService.playAudio(this.clickAudio, 1.0);
    }
  }

  private getCurrentSegment(): string {
    const totalWeight = this.getTotalWeights();

    const currentAngle = (2 * Math.PI - (this.currentRotation % (2 * Math.PI))) % (2 * Math.PI);
    let accumulatedWeight = 0;

    for (const item of this.translatedItems) {
      accumulatedWeight += item.weight;
      const segmentEnd = (accumulatedWeight / totalWeight) * 2 * Math.PI;

      if (currentAngle <= segmentEnd) {
        return item.text;
      }
    }
    return '-';
  }

  private getTotalWeights(): number {
    return this.translatedItems.reduce((sum, item) => sum + item.weight, 0);
  }

  getRandomWeightedIndex(): number {
    const totalWeight = this.getTotalWeights();
    let random = Math.random() * totalWeight;
    let accumulatedWeight = 0;

    for (let i = 0; i < this.translatedItems.length; i++) {
      accumulatedWeight += this.translatedItems[i].weight;
      if (random < accumulatedWeight) {
        return i;
      }
    }
    return this.translatedItems.length - 1;
  }
}
