import { Component, HostListener } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TranslateService, TranslateModule } from '@ngx-translate/core';
import { CryService } from './services/cry-service/cry.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, TranslateModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'pokemon-roulette';

  constructor(private translate: TranslateService, private cryService: CryService) {
    // English-only build
    this.translate.addLangs(['en']);
    this.translate.setDefaultLang('en');
    this.translate.use('en');
  }

  // Mobile browsers often block delayed audio unless the page has been "unlocked"
  // by a user gesture. This guarantees Mega cries can play after the 3s animation.
  @HostListener('window:pointerdown')
  async onFirstPointerDown() {
    await this.cryService.unlockAudio();
  }

  changeLang(lang: string) {
    // Keep method for template compatibility; ignore non-English.
    if (lang === 'en') {
      this.translate.use('en');
    }
  }
}
