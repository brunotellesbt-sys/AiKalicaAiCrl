export interface EncounterCharacter {
  name: string;
  spriteUrl: string;
  blurb: string;
}

export interface VillainTeamEncounter {
  teamName: string;
  leaders: EncounterCharacter[];
  blurb: string;
}

export interface RoadblockEncounter {
  pokemonId: number;
  pokemonNameKey: string;
  blurb: string;
}

/**
 * "Battle Trainer" flavor encounters (used by the battle-trainer event).
 * Some generations have multiple possibilities (Gen 5: Bianca OR Cheren).
 */
export const battleTrainerByGeneration: Record<number, EncounterCharacter[]> = {
  1: [
    {
      name: 'Yellow',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/yellow.png',
      blurb: 'A surprise trainer battle for fun (visual only).',
    },
  ],
  2: [
    {
      name: 'Lyra',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/lyra.png',
      blurb: 'A friendly battle (visual only).',
    },
  ],
  3: [
    {
      name: 'Wally',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/wally.png',
      blurb: 'A friendly Hoenn challenger appears (visual only).',
    },
  ],
  4: [
    {
      name: 'Looker',
      // Custom image bundled in the project (public/trainers/custom/looker.png)
      spriteUrl: './trainers/custom/looker.svg',
      blurb: 'International Police encounter (visual only).',
    },
  ],
  5: [
    {
      name: 'Bianca',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/bianca.png',
      blurb: 'A cheerful challenger appears (visual only).',
    },
    {
      name: 'Cheren',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/cheren.png',
      blurb: 'A serious challenger appears (visual only).',
    },
  ],
  6: [
    {
      name: 'Trevor',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/trevor.png',
      blurb: 'A quick battle for research (visual only).',
    },
  ],
  7: [
    {
      name: 'Hau',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/hau.png',
      blurb: 'A friendly Alola battle (visual only).',
    },
  ],
  8: [
    {
      name: 'Hop',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/hop.png',
      blurb: 'Your energetic rival wants a battle (visual only).',
    },
  ],
  9: [
    {
      name: 'Cassiopeia',
      // Cassiopeia is Penny (use Penny sprite)
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/penny.png',
      blurb: 'A mysterious challenger appears… (visual only).',
    },
  ],
};

/**
 * Villain Team encounters (replaces the old "Team Rocket" encounter).
 * Some generations can randomize between version-exclusive teams.
 */
export const villainTeamByGeneration: Record<number, VillainTeamEncounter> = {
  1: {
    teamName: 'Team Rocket',
    leaders: [
      {
        name: 'Giovanni',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/giovanni.png',
        blurb: 'The boss of Team Rocket. Beware!',
      },
    ],
    blurb: 'A shady organization tries to steal your Pokémon!',
  },
  2: {
    teamName: 'Team Rocket',
    leaders: [
      {
        name: 'Proton',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/proton.png',
        blurb: 'A Team Rocket executive is causing trouble.',
      },
    ],
    blurb: 'Team Rocket is back again in Johto.',
  },
  3: {
    teamName: 'Team Magma / Team Aqua',
    leaders: [
      {
        name: 'Maxie',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/maxie.png',
        blurb: 'Team Magma wants to expand the land.',
      },
      {
        name: 'Archie',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/archie.png',
        blurb: 'Team Aqua wants to expand the sea.',
      },
    ],
    blurb: 'Two rival villain teams can appear, depending on the version.',
  },
  4: {
    teamName: 'Team Galactic',
    leaders: [
      {
        name: 'Cyrus',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/cyrus.png',
        blurb: "Team Galactic's cold and calculating leader.",
      },
    ],
    blurb: 'Team Galactic wants to reshape the world.',
  },
  5: {
    teamName: 'Team Plasma',
    leaders: [
      {
        name: 'Ghetsis',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/ghetsis.png',
        blurb: 'The true mastermind behind Team Plasma.',
      },
    ],
    blurb: 'Team Plasma is here to cause chaos.',
  },
  6: {
    teamName: 'Team Flare',
    leaders: [
      {
        name: 'Lysandre',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/lysandre.png',
        blurb: 'The stylish but dangerous Team Flare leader.',
      },
    ],
    blurb: 'Team Flare is plotting something huge.',
  },
  7: {
    teamName: 'Team Skull',
    leaders: [
      {
        name: 'Guzma',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/guzma.png',
        blurb: 'The boss of Team Skull.',
      },
    ],
    blurb: 'Team Skull grunts block your way and start trouble.',
  },
  8: {
    teamName: 'Macro Cosmos',
    leaders: [
      {
        name: 'Chairman Rose',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/rose.png',
        blurb: 'The chairman behind Macro Cosmos.',
      },
    ],
    blurb: 'A corporate villain shows up at the worst time.',
  },
  9: {
    teamName: 'Team Star',
    leaders: [
      {
        name: 'Cassiopeia',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/penny.png',
        blurb: 'The mysterious boss of Team Star.',
      },
    ],
    blurb: 'Team Star is challenging trainers across Paldea.',
  },
};

/**
 * "Snorlax" encounter reskin: a generation-themed roadblock/tool/comic Pokémon.
 */
export const roadblockByGeneration: Record<number, RoadblockEncounter> = {
  1: {
    pokemonId: 143,
    pokemonNameKey: 'pokemon.snorlax',
    blurb: 'A sleeping roadblock Pokémon.',
  },
  2: {
    pokemonId: 185,
    pokemonNameKey: 'pokemon.sudowoodo',
    blurb: 'The odd tree that blocks your way.',
  },
  3: {
    pokemonId: 352,
    pokemonNameKey: 'pokemon.kecleon',
    blurb: 'It was invisible… until you got close.',
  },
  4: {
    pokemonId: 54,
    pokemonNameKey: 'pokemon.psyduck',
    blurb: 'A pack of Psyduck blocks the road with headaches.',
  },
  5: {
    pokemonId: 558,
    pokemonNameKey: 'pokemon.crustle',
    blurb: 'Crustle are in the way. Watch your step.',
  },
  6: {
    // Gen 6: use a "tool" Pokémon from Kalos (Gogoat Shuttle).
    pokemonId: 673,
    pokemonNameKey: 'pokemon.gogoat',
    blurb: 'A Gogoat shuttle is blocking the street for a moment.',
  },
  7: {
    // Gen 7: Poké Ride partner
    pokemonId: 508,
    pokemonNameKey: 'pokemon.stoutland',
    blurb: 'Stoutland stops to sniff around and blocks the path.',
  },
  8: {
    pokemonId: 831,
    pokemonNameKey: 'pokemon.wooloo',
    blurb: 'A runaway Wooloo is causing trouble on the road.',
  },
  9: {
    pokemonId: 915,
    pokemonNameKey: 'pokemon.lechonk',
    blurb: 'A herd of Lechonk is blocking the road in Paldea.',
  },
};
