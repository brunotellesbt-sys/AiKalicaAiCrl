import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { NgIf } from '@angular/common';
import { forkJoin, map, Subscription } from 'rxjs';
import { TranslatePipe } from '@ngx-translate/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { WheelComponent } from '../../../../wheel/wheel.component';
import { PokemonItem } from '../../../../interfaces/pokemon-item';
import {
  MegaEvolutionService,
  MegaForm,
} from '../../../../services/mega-evolution-service/mega-evolution.service';
import { TrainerService } from '../../../../services/trainer-service/trainer.service';
import { CryService } from '../../../../services/cry-service/cry.service';
import { SettingsService } from '../../../../services/settings-service/settings.service';

type MegaRouletteMode = 'select-pokemon' | 'select-mega-form';

@Component({
  selector: 'app-mega-evolution-roulette',
  imports: [WheelComponent, TranslatePipe, NgIf],
  templateUrl: './mega-evolution-roulette.component.html',
  styleUrl: './mega-evolution-roulette.component.css',
})
export class MegaEvolutionRouletteComponent implements OnInit, OnDestroy {
  @Output() megaEvolutionFinished = new EventEmitter<void>();

  @ViewChild('megaEvolutionModal', { static: true })
  megaEvolutionModal!: TemplateRef<any>;

  mode: MegaRouletteMode = 'select-pokemon';
  wheelTitle = 'Mega Evolution';

  isLoading = true;

  /** Candidates: team Pokémon that can Mega Evolve and their available Mega forms. */
  private megaCandidates: Array<{ pokemon: PokemonItem; megaForms: MegaForm[] }> = [];

  /** Current wheel items (either Pokémon or Mega forms). */
  wheelItems: any[] = [];

  /** When selecting a Mega form, this is the Pokémon chosen in the previous wheel. */
  private selectedPokemonForMega: PokemonItem | null = null;

  /** Selected Mega form (for cry + display). */
  private selectedMegaForm: MegaForm | null = null;

  /** Popup data */
  popupBeforeNameKey = '';
  popupAfterName = '';
  popupBeforeSpriteUrl = '';
  popupAfterSpriteUrl = '';

  /** Animation */
  isMegaAnimating = false;
  isCryPhase = false;

  private subs = new Subscription();
  private modalRef: NgbModalRef | null = null;

  constructor(
    private trainerService: TrainerService,
    private megaEvolutionService: MegaEvolutionService,
    private cryService: CryService,
    private settingsService: SettingsService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    const team = this.trainerService.getTeam();

    if (!team || team.length === 0) {
      this.isLoading = false;
      this.megaEvolutionFinished.emit();
      return;
    }

    const requests = team.map((p) =>
      this.megaEvolutionService.getMegaFormsForPokemon(p).pipe(
        map((forms) => ({ pokemon: p, megaForms: forms }))
      )
    );

    const sub = forkJoin(requests).subscribe({
      next: (results) => {
        this.megaCandidates = results.filter((r) => (r.megaForms?.length ?? 0) > 0);
        this.isLoading = false;

        if (this.megaCandidates.length === 0) {
          this.megaEvolutionFinished.emit();
          return;
        }

        this.mode = 'select-pokemon';
        this.wheelTitle = 'Mega Evolution';
        this.wheelItems = this.megaCandidates.map((c) => c.pokemon);
      },
      error: () => {
        this.isLoading = false;
        this.megaEvolutionFinished.emit();
      },
    });

    this.subs.add(sub);
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
    try {
      this.modalRef?.close();
    } catch {
      // ignore
    }
  }

  onItemSelected(index: number): void {
    if (this.isLoading) return;

    if (this.mode === 'select-pokemon') {
      const candidate = this.megaCandidates[index];
      if (!candidate) {
        this.megaEvolutionFinished.emit();
        return;
      }

      this.selectedPokemonForMega = candidate.pokemon;

      if ((candidate.megaForms?.length ?? 0) <= 1) {
        this.applyMegaEvolution(candidate.pokemon, candidate.megaForms[0]);
        return;
      }

      this.mode = 'select-mega-form';
      this.wheelTitle = 'Mega Evolution';
      this.wheelItems = candidate.megaForms.map((f) => ({
        text: f.displayName,
        fillStyle: candidate.pokemon.fillStyle,
        weight: 1,
        _megaForm: f,
      }));
      return;
    }

    const selected = this.wheelItems[index] as any;
    const megaForm: MegaForm | undefined = selected?._megaForm;

    if (!this.selectedPokemonForMega || !megaForm) {
      this.megaEvolutionFinished.emit();
      return;
    }

    this.applyMegaEvolution(this.selectedPokemonForMega, megaForm);
  }

  private applyMegaEvolution(pokemon: PokemonItem, megaForm: MegaForm): void {
    // Snapshot BEFORE mutation
    this.popupBeforeNameKey = pokemon.text;
    this.popupBeforeSpriteUrl = pokemon.shiny
      ? pokemon.sprite?.front_shiny || pokemon.sprite?.front_default || ''
      : pokemon.sprite?.front_default || '';

    this.popupAfterName = megaForm.displayName;
    this.selectedMegaForm = megaForm;

    const sub = this.megaEvolutionService.megaEvolveForBattle(pokemon, megaForm).subscribe({
      next: () => {
        // After sprite (pokemon object already updated)
        this.popupAfterSpriteUrl = pokemon.shiny
          ? pokemon.sprite?.front_shiny || pokemon.sprite?.front_default || ''
          : pokemon.sprite?.front_default || '';

        this.openMegaPopupAndProceed();
      },
      error: () => {
        this.megaEvolutionFinished.emit();
      },
    });

    this.subs.add(sub);
  }

  private openMegaPopupAndProceed(): void {
    try {
      this.isMegaAnimating = true;
      this.isCryPhase = false;

      this.modalRef = this.modalService.open(this.megaEvolutionModal, {
        centered: true,
        backdrop: 'static',
        keyboard: false,
      });

      // Start on next tick (after DOM is available)
      setTimeout(() => {
        // 3-second "Mega Evolution" blink
        setTimeout(async () => {
          this.isMegaAnimating = false;
          this.isCryPhase = true;

          await this.playMegaCry();

          try {
            this.modalRef?.close();
          } finally {
            this.megaEvolutionFinished.emit();
          }
        }, 3000);
      }, 0);

      this.modalRef.result.finally(() => {
        this.isMegaAnimating = false;
        this.isCryPhase = false;
        this.selectedMegaForm = null;
        this.selectedPokemonForMega = null;
        this.mode = 'select-pokemon';
      });
    } catch {
      this.megaEvolutionFinished.emit();
    }
  }

  private playMegaCry(): Promise<void> {
    const mega = this.selectedMegaForm;
    if (!mega) return Promise.resolve();

    const seed = `mega:${mega.apiName}:${mega.pokemonId}`;
    // Cry plays at the END of the 3s blink, per your requirement.
    // This build uses local cry overrides (if present) + synthetic fallback.
    return this.cryService.playMegaCryOrSynthetic(seed, mega.apiName);
  }
}
