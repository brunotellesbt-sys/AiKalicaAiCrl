import { Injectable } from '@angular/core';
import {
  MissingTranslationHandler,
  MissingTranslationHandlerParams,
} from '@ngx-translate/core';

/**
 * PrettyMissingTranslationHandler
 *
 * Prevents raw keys like:
 *   - pokemon.lechonk
 *   - gymLeaders.crasher-wake.name
 *   - com.gymleader.crasher wakw
 * from showing up to the player.
 *
 * If a translation key is missing, we generate a best-effort human name.
 */
@Injectable()
export class PrettyMissingTranslationHandler implements MissingTranslationHandler {
  handle(params: MissingTranslationHandlerParams): string {
    const key = (params?.key || '').toString();
    if (!key) return '';

    // Pull the most human-relevant part of the key.
    const parts = key.split('.').map((p) => p.trim()).filter(Boolean);
    let raw = parts[parts.length - 1] || key;

    // Common patterns: ...<id>.name, ...<id>.quote1
    if (raw === 'name' && parts.length >= 2) raw = parts[parts.length - 2];
    if (/^quote\d+$/i.test(raw)) return ''; // if a quote is missing, hide it

    // Fix common typos that appear in some upstream datasets.
    raw = raw.replace(/\bwakw\b/gi, 'wake');

    // Convert separators/casing to words.
    const normalized = raw
      .replace(/[_\-]+/g, ' ')
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      // Keep accented characters (Pokémon, Érika, etc.).
      // \p{L} = any letter, \p{M} = combining marks.
      .replace(/[^\p{L}\p{M}0-9\s]/gu, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (!normalized) return '';

    return normalized
      .split(' ')
      .map((w) => (w.length ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w))
      .join(' ');
  }
}
