import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, of, shareReplay, switchMap, throwError } from 'rxjs';
import { PokemonItem } from '../../interfaces/pokemon-item';
import { PokemonService } from '../pokemon-service/pokemon.service';
import { TrainerService } from '../trainer-service/trainer.service';

export interface MegaForm {
  /** PokeAPI Pokémon id of the Mega form (or base id for custom forms). */
  pokemonId: number;
  /** PokeAPI name (e.g. "charizard-mega-x"). */
  apiName: string;
  /** Display name (e.g. "Mega Charizard X"). */
  displayName: string;

  /**
   * Optional override sprites for custom Mega forms not present on PokeAPI.
   * If provided, MegaEvolutionService will use these instead of fetching sprites.
   */
  spriteUrl?: string;
  shinySpriteUrl?: string;

  /** Where this form came from. */
  source?: 'pokeapi' | 'custom';
}

interface CustomMegaFormsFile {
  version?: number;
  forms?: CustomMegaFormDefinition[];
}

interface CustomMegaFormDefinition {
  basePokemonId: number;
  apiName: string;
  displayName: string;
  pokemonId?: number;
  spriteUrl?: string;
  shinySpriteUrl?: string;
}

interface PokemonSpeciesResponse {
  varieties: Array<{
    is_default: boolean;
    pokemon: {
      name: string;
      url: string;
    };
  }>;
}

@Injectable({
  providedIn: 'root'
})
export class MegaEvolutionService {
  private apiBaseUrl = 'https://pokeapi.co/api/v2';

  /** Cache mega forms by *species id* to avoid re-fetching every battle. */
  private megaFormsBySpeciesId = new Map<number, Observable<MegaForm[]>>();
  private customMegaFormsByBaseId$?: Observable<Map<number, MegaForm[]>>;

  /** Only one Mega per battle (by design). */
  private currentMegaPokemon: PokemonItem | null = null;

  constructor(
    private http: HttpClient,
    private pokemonService: PokemonService,
    private trainerService: TrainerService
  ) {}

  private loadCustomMegaFormsByBaseId(): Observable<Map<number, MegaForm[]>> {
    if (this.customMegaFormsByBaseId$) return this.customMegaFormsByBaseId$;

    // Optional file. If missing/invalid, we just treat as no custom forms.
    this.customMegaFormsByBaseId$ = this.http
      .get<CustomMegaFormsFile>('./data/custom-mega-forms.json')
      .pipe(
        map((file) => {
          const byBaseId = new Map<number, MegaForm[]>();
          const forms = file?.forms ?? [];

          for (const def of forms) {
            if (!def) continue;
            const baseId = Number(def.basePokemonId);
            if (!Number.isFinite(baseId) || baseId <= 0) continue;
            if (!def.apiName || !def.displayName) continue;

            const form: MegaForm = {
              // If a custom form doesn't have a dedicated id, we keep baseId so the game
              // remains stable (Mega state is still tracked via megaBackup).
              pokemonId: Number.isFinite(Number(def.pokemonId)) ? Number(def.pokemonId) : baseId,
              apiName: def.apiName,
              displayName: def.displayName,
              spriteUrl: def.spriteUrl,
              shinySpriteUrl: def.shinySpriteUrl,
              source: 'custom',
            };

            const list = byBaseId.get(baseId) ?? [];
            list.push(form);
            byBaseId.set(baseId, list);
          }

          // Stable order for UI.
          for (const [k, list] of byBaseId.entries()) {
            list.sort((a, b) => a.displayName.localeCompare(b.displayName));
            byBaseId.set(k, list);
          }

          return byBaseId;
        }),
        catchError(() => of(new Map<number, MegaForm[]>())),
        shareReplay(1)
      );

    return this.customMegaFormsByBaseId$;
  }

  /**
   * Returns all Mega forms available for the given Pokémon.
   *
   * - Primary source: PokeAPI (pokemon-species varieties containing "mega")
   * - Optional extra source: /public/data/custom-mega-forms.json
   *
   * This keeps the game forward-compatible (new Mega forms added to PokeAPI will
   * automatically appear), and also allows you to add fan-made / custom Mega forms
   * without bundling copyrighted assets.
   */
  getMegaFormsForPokemon(pokemon: PokemonItem): Observable<MegaForm[]> {
    const speciesId = pokemon.basePokemonId ?? pokemon.pokemonId;

    // Cache per species id.
    const cached = this.megaFormsBySpeciesId.get(speciesId);
    if (cached) return cached;

    const request$ = this.loadCustomMegaFormsByBaseId().pipe(
      switchMap((customByBaseId) =>
        this.http
          .get<PokemonSpeciesResponse>(`https://pokeapi.co/api/v2/pokemon-species/${speciesId}/`)
          .pipe(
            map((response) => {
              const fromApi: MegaForm[] = response.varieties
                // IMPORTANT: "mega" must be a hyphen-delimited form segment ("-mega", "-mega-x", etc.).
                // Otherwise Pokémon whose base name contains the substring "mega" (e.g. "meganium") would be
                // incorrectly treated as having a Mega form.
                .filter((v) => v.pokemon.name.includes('-mega'))
                .map((v) => ({
                  pokemonId: this.extractIdFromUrl(v.pokemon.url),
                  apiName: v.pokemon.name,
                  displayName: this.formatMegaDisplayName(v.pokemon.name),
                  source: 'pokeapi' as const,
                }))
                .filter((f) => f.pokemonId > 0);

              const custom: MegaForm[] = (customByBaseId.get(speciesId) ?? []).map((f) => ({
                ...f,
                source: f.source ?? ('custom' as const),
              }));

              // Merge + dedupe by apiName. Custom entries override PokeAPI entries if they share apiName.
              const byName = new Map<string, MegaForm>();
              for (const f of [...fromApi, ...custom]) {
                byName.set(f.apiName, f);
              }

              return Array.from(byName.values()).sort((a, b) =>
                a.displayName.localeCompare(b.displayName)
              );
            }),
            catchError((error) => {
              console.error('Failed to fetch Mega forms for species', speciesId, error);
              // If PokeAPI fails, still return custom forms (if any).
              return of(customByBaseId.get(speciesId) ?? []);
            })
          )
      ),
      shareReplay(1)
    );

    this.megaFormsBySpeciesId.set(speciesId, request$);
    return request$;
  }

  /**
   * Applies Mega Evolution for the current battle.
   * The Pokémon is reverted automatically when `revertCurrentMegaEvolution()` is called.
   */
  megaEvolveForBattle(pokemon: PokemonItem, megaForm: MegaForm): Observable<void> {
    this.revertCurrentMegaEvolution();

    pokemon.megaBackup = {
      text: pokemon.text,
      sprite: pokemon.sprite,
      power: pokemon.power,
    };

    const megaPower: 5 | 6 = pokemon.power === 5 ? 6 : 5;

    // If this is a custom Mega form with explicit sprite overrides, apply immediately
    // without requiring any PokeAPI lookup.
    if (megaForm.spriteUrl) {
      pokemon.sprite = {
        front_default: megaForm.spriteUrl,
        front_shiny: megaForm.shinySpriteUrl ?? megaForm.spriteUrl,
      };
      pokemon.text = megaForm.displayName;
      pokemon.power = megaPower;
      pokemon.isMegaEvolved = true;
      this.currentMegaPokemon = pokemon;

      this.trainerService.updateTeam();
      return of(void 0);
    }

    // Default path: use PokeAPI sprite lookup (works for official Mega forms).
    return this.pokemonService.getPokemonSprites(megaForm.pokemonId).pipe(
      map((result) => {
        pokemon.sprite = result.sprite;
        pokemon.text = megaForm.displayName;
        pokemon.power = megaPower;
        pokemon.isMegaEvolved = true;
        this.currentMegaPokemon = pokemon;

        this.trainerService.updateTeam();
      }),
      catchError((error) => {
        console.error('Failed to mega evolve', pokemon, megaForm, error);
        this.revertCurrentMegaEvolution();
        return throwError(() => error);
      })
    );
  }

  /**
   * Reverts the currently Mega-Evolved Pokémon (if any) back to its original form.
   * Call this right after a battle ends.
   */
  revertCurrentMegaEvolution(): void {
    const pokemon = this.currentMegaPokemon;
    if (!pokemon?.megaBackup) {
      this.currentMegaPokemon = null;
      return;
    }

    pokemon.text = pokemon.megaBackup.text;
    pokemon.sprite = pokemon.megaBackup.sprite;
    pokemon.power = pokemon.megaBackup.power;
    pokemon.isMegaEvolved = false;
    delete pokemon.megaBackup;

    this.currentMegaPokemon = null;

    const team = this.trainerService.getTeam();
    this.trainerService.updateTeam();
  }


  /**
   * Backwards-compatible name used by older callers.
   * (Some parts of the UI call `revertMegaEvolution()`.)
   *
   * Prefer `revertCurrentMegaEvolution()` for new code.
   */
  revertMegaEvolution(): void {
    this.revertCurrentMegaEvolution();
  }

  /**
   * Extracts the numeric id from a standard PokeAPI resource URL.
   *
   * Returns 0 if parsing fails (caller can filter it out).
   */
  private extractIdFromUrl(url: string): number {
    try {
      const parts = url.split('/').filter(Boolean);
      const idStr = parts[parts.length - 1];
      const id = Number(idStr);
      return Number.isFinite(id) ? id : 0;
    } catch {
      return 0;
    }
  }

  private formatMegaDisplayName(apiName: string): string {
    const parts = apiName.split('-').filter(Boolean);
    const megaIndex = parts.indexOf('mega');

    // Fallback: just Title Case the whole thing.
    if (megaIndex === -1) {
      return this.toTitleCase(parts.join(' '));
    }

    const baseName = parts.slice(0, megaIndex).join(' ');
    const suffixParts = parts.slice(megaIndex + 1);

    const suffix = suffixParts
      .map((p) => (['x', 'y', 'z'].includes(p) ? p.toUpperCase() : this.capitalize(p)))
      .join(' ');

    return `Mega ${this.toTitleCase(baseName)}${suffix ? ` ${suffix}` : ''}`;
  }

  private toTitleCase(str: string): string {
    return str
      .split(' ')
      .filter(Boolean)
      .map((w) => this.capitalize(w))
      .join(' ');
  }

  private capitalize(word: string): string {
    if (!word) return word;
    return word.charAt(0).toUpperCase() + word.slice(1);
  }
}
