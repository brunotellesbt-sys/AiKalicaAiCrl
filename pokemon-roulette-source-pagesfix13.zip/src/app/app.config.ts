import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withHashLocation } from '@angular/router';
import { provideIcons } from '@ng-icons/core';
import { routes } from './app.routes';
import { provideHttpClient } from '@angular/common/http';
import {
  bootstrapArrowRepeat,
  bootstrapCheck,
  bootstrapClock,
  bootstrapController,
  bootstrapCupHotFill,
  bootstrapGear,
  bootstrapMap,
  bootstrapPcDisplayHorizontal,
  bootstrapPeopleFill,
  bootstrapShare,
} from '@ng-icons/bootstrap-icons';

import { provideTranslateService, provideMissingTranslationHandler } from '@ngx-translate/core';
import { provideTranslateHttpLoader } from '@ngx-translate/http-loader';
import { PrettyMissingTranslationHandler } from './shared/pretty-missing-translation.handler';

// IMPORTANT (GitHub Pages compatibility):
// - Use hash-based routing so deep links don't 404 on static hosting.
// - Keep translation paths *relative* (no leading slash) so it works under /<repo>/
// - enable "enforceLoading" to cache-bust translation JSON files and avoid stale SW caches.

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes, withHashLocation()),
    provideIcons({
      bootstrapArrowRepeat,
      bootstrapCheck,
      bootstrapClock,
      bootstrapController,
      bootstrapCupHotFill,
      bootstrapGear,
      bootstrapPcDisplayHorizontal,
      bootstrapPeopleFill,
      bootstrapShare,
      bootstrapMap,
    }),
    provideHttpClient(),
    provideZoneChangeDetection({ eventCoalescing: true }),

    provideTranslateService({
      lang: 'en',
      fallbackLang: 'en',
      loader: provideTranslateHttpLoader({
        prefix: 'i18n/',
        suffix: '.json',
        // Adds a cache-busting timestamp to translation requests.
        // Helps when GitHub Pages + SW caches an older en.json.
        enforceLoading: true,
      }),
      missingTranslationHandler: provideMissingTranslationHandler(PrettyMissingTranslationHandler),
    }),
  ],
};
