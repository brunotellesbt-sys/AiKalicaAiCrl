import { Injectable } from '@angular/core';
import { SettingsService } from '../settings-service/settings.service';

/**
 * CryService
 *
 * How Mega cries work in this build:
 *  1) Try local overrides (./cries/mega/<megaApiName>.ogg|.mp3)
 *  2) Try to play from a remote public source (streaming; no bundling)
 *  3) Fall back to a deterministic synthetic cry (always available)
 *
 * This keeps GitHub Pages deployments small while preserving the "real cry" behavior
 * users expect (when a remote cry exists).
 */
@Injectable({ providedIn: 'root' })
export class CryService {
  constructor(private settingsService: SettingsService) {}

  async playMegaCryOrSynthetic(seed: string, megaApiName: string): Promise<void> {
    if (this.settingsService.currentSettings.muteAudio) return;

    const candidates = [
      `./cries/mega/${megaApiName}.ogg`,
      `./cries/mega/${megaApiName}.mp3`,
    ];

    for (const url of candidates) {
      const ok = await this.tryPlayLocalAsset(url);
      if (ok) return;
    }

    // Remote (stream) fallback — tries Mega name first, then base species name.
    const remoteOk = await this.tryPlayRemoteMegaCry(megaApiName);
    if (remoteOk) return;

    await this.playSyntheticCry(seed);
  }

    
  /**
   * Plays an audio URL (local or remote) in the most compatible way.
   *
   * Why this exists:
   * - Some hosts (including static CDNs) don't send CORS headers for media.
   *   Setting `crossOrigin` can make playback fail even though the file is reachable.
   * - iOS/Chrome mobile can be picky about canplaythrough; canplay/loadeddata are safer.
   */
  private tryPlayAudioUrl(url: string): Promise<boolean> {
    return new Promise((resolve) => {
      let finished = false;

      const audio = new Audio();
      audio.preload = 'auto';
      audio.src = url;

      const cleanup = () => {
        audio.onended = null;
        audio.onerror = null;
        audio.oncanplay = null;
        audio.onloadeddata = null;
      };

      const done = (ok: boolean) => {
        if (finished) return;
        finished = true;
        cleanup();
        try {
          audio.pause();
        } catch {
          // ignore
        }
        resolve(ok);
      };

      const start = async () => {
        try {
          const p = audio.play();
          // Some browsers return void, some return a Promise.
          if (p && typeof (p as any).then === 'function') {
            await p;
          }
        } catch {
          done(false);
        }
      };

      audio.onended = () => done(true);
      audio.onerror = () => done(false);

      // Start as soon as the browser says it can.
      audio.oncanplay = () => start();
      audio.onloadeddata = () => start();

      // Kick off loading.
      try {
        audio.load();
      } catch {
        // ignore
      }

      // Fallback: if canplay doesn't fire for some reason, try starting anyway.
      setTimeout(() => start(), 250);

      // Safety timeout: cries are short. If we haven't ended by now, consider it failed.
      setTimeout(() => done(false), 8000);
    });
  }

private tryPlayLocalAsset(url: string): Promise<boolean> {
    return this.tryPlayAudioUrl(url);
  }

  private async tryPlayRemoteMegaCry(megaApiName: string): Promise<boolean> {
    const megaName = this.normalizeShowdownName(megaApiName);
    const baseName = this.deriveBaseSpeciesName(megaName);

    const namesToTry = [megaName];
    if (baseName && baseName !== megaName) namesToTry.push(baseName);

    // Showdown hosts both .mp3 and .ogg cries.
    for (const n of namesToTry) {
      const mp3 = `https://play.pokemonshowdown.com/audio/cries/${n}.mp3`;
      if (await this.tryPlayRemoteAsset(mp3)) return true;

      const ogg = `https://play.pokemonshowdown.com/audio/cries/${n}.ogg`;
      if (await this.tryPlayRemoteAsset(ogg)) return true;
    }
    return false;
  }

    private tryPlayRemoteAsset(url: string): Promise<boolean> {
    return this.tryPlayAudioUrl(url);
  }

  /**
   * Convert our internal API name into the most likely Showdown cry filename.
   * Examples:
   *  - charizard-mega-x -> charizard-megax
   *  - charizard-mega-y -> charizard-megay
   *  - abomasnow-mega   -> abomasnow-mega
   */
  private normalizeShowdownName(name: string): string {
    const n = (name || '')
      .trim()
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/['’]/g, '')
      .replace(/[^a-z0-9\-]/g, '-');

    // Common Mega X/Y formatting
    return n
      .replace(/-mega-x\b/g, '-megax')
      .replace(/-mega-y\b/g, '-megay')
      .replace(/--+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  /**
   * If the Mega form cry doesn't exist remotely, we fall back to the base species cry.
   * Ex: charizard-megax -> charizard
   */
  private deriveBaseSpeciesName(showdownName: string): string {
    if (!showdownName) return showdownName;

    // Strip common Mega suffixes
    let base = showdownName
      .replace(/-megax\b/g, '')
      .replace(/-megay\b/g, '')
      .replace(/-mega\b/g, '');

    // Collapse leftover dashes
    base = base.replace(/--+/g, '-').replace(/^-+|-+$/g, '');

    // If we stripped everything somehow, keep original.
    return base || showdownName;
  }

  async playSyntheticCry(seed: string, durationMs: number = 850): Promise<void> {
    if (this.settingsService.currentSettings.muteAudio) return;

    try {
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Simple deterministic hash
      let h = 0;
      for (let i = 0; i < seed.length; i++) {
        h = (h * 31 + seed.charCodeAt(i)) >>> 0;
      }

      const base = 160 + (h % 420);
      const mid = base * (1.15 + ((h >>> 8) % 60) / 100);
      const end = base * (0.7 + ((h >>> 16) % 60) / 100);

      osc.type = (['sine', 'triangle', 'sawtooth', 'square'][h % 4] as OscillatorType) || 'triangle';
      osc.frequency.setValueAtTime(base, now);
      osc.frequency.exponentialRampToValueAtTime(mid, now + 0.18);
      osc.frequency.exponentialRampToValueAtTime(end, now + 0.6);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.22, now + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + durationMs / 1000);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + durationMs / 1000);

      await new Promise<void>((resolve) => {
        osc.onended = () => resolve();
      });

      try {
        await ctx.close();
      } catch {
        // ignore
      }
    } catch {
      // ignore
    }
  }
}
