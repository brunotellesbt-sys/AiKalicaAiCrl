import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';

import { WheelComponent } from '../../../../wheel/wheel.component';
import { GameStateService } from '../../../../services/game-state-service/game-state.service';
import { GenerationService } from '../../../../services/generation-service/generation.service';
import { TrainerService } from '../../../../services/trainer-service/trainer.service';
import { GenerationItem } from '../../../../interfaces/generation-item';
import { PokemonItem } from '../../../../interfaces/pokemon-item';
import { ItemItem } from '../../../../interfaces/item-item';
import { WheelItem } from '../../../../interfaces/wheel-item';
import { ImgFallbackDirective } from '../../../../shared/img-fallback.directive';
import { EncounterCharacter, battleTrainerByGeneration } from '../../../../data/generation-encounters';
import { RunService } from '../../../../services/run-service/run.service';
import {
  EnemyPokemon,
  EnemyTeamService,
  TypeAdvantage,
} from '../../../../services/enemy-team-service/enemy-team.service';
import { EnemyTeamPanelComponent } from '../../../enemy-team-panel/enemy-team-panel.component';
import { BATTLE_TRAINER_TYPES } from '../../../../data/trainer-type-themes';
import {
  battleTrainerAceByGeneration,
  battleTrainerTeamsByGeneration,
} from '../../../../data/trainer-teams';
import {
  scaledTrainerTeamSize,
  shouldBeFullyEvolved,
} from '../../../../services/enemy-team-service/enemy-team-size';
import { BattleRetryService } from '../../../../services/battle-retry-service/battle-retry.service';

/**
 * Roadside trainer battle.
 *
 * This encounter used to be flavour only — it showed the trainer and then jumped straight
 * to the evolution reward, with no fight at all. It is now a real battle: the trainer
 * brings the team they use in the games, scaled to the gym the player is heading towards,
 * and losing costs a potion or a life like any other battle.
 */
@Component({
  selector: 'app-trainer-battle-roulette',
  standalone: true,
  imports: [ImgFallbackDirective, CommonModule, WheelComponent, TranslatePipe, EnemyTeamPanelComponent],
  templateUrl: './trainer-battle-roulette.component.html',
  styleUrl: './trainer-battle-roulette.component.css',
})
export class TrainerBattleRouletteComponent implements OnInit, OnDestroy {
  constructor(
    private modalService: NgbModal,
    private gameStateService: GameStateService,
    private generationService: GenerationService,
    private trainerService: TrainerService,
    private runService: RunService,
    private enemyTeamService: EnemyTeamService,
    private battleRetryService: BattleRetryService,
    private translate: TranslateService
  ) {}

  private gameSubscription: Subscription | null = null;
  private generationSubscription: Subscription | null = null;
  private teamSubscription: Subscription | null = null;

  @ViewChild('trainerPresentationModal', { static: true })
  trainerPresentationModal!: TemplateRef<any>;
  @ViewChild('itemUsedModal', { static: true })
  itemUsedModal!: TemplateRef<any>;

  generation!: GenerationItem;
  trainerTeam: PokemonItem[] = [];
  trainerItems: ItemItem[] = [];

  @Input() currentRound = 0;
  @Output() battleResultEvent = new EventEmitter<boolean>();

  victoryOdds: WheelItem[] = [];
  opponent: EncounterCharacter | null = null;
  currentItem?: ItemItem;
  retries = 0;

  /** Type Advantage mode only — empty in Classic. */
  enemyTeam: EnemyPokemon[] = [];
  typeAdvantage: TypeAdvantage | null = null;

  get isTypeAdvantageMode(): boolean {
    return this.runService.isTypeAdvantageMode;
  }

  ngOnInit(): void {
    this.generationSubscription = this.generationService.getGeneration().subscribe((gen) => {
      this.generation = gen;
    });

    this.trainerItems = this.trainerService.getItems();

    this.teamSubscription = this.trainerService.getTeamObservable().subscribe((team) => {
      this.trainerTeam = team;
      this.buildEnemyTeam();
      this.calcVictoryOdds();
    });

    this.gameSubscription = this.gameStateService.currentState.subscribe((state) => {
      if (state !== 'trainer-battle') return;

      this.opponent = this.pickOpponent();
      this.buildEnemyTeam();
      this.calcVictoryOdds();

      this.modalService.open(this.trainerPresentationModal, { centered: true, size: 'lg' });
    });
  }

  ngOnDestroy(): void {
    this.gameSubscription?.unsubscribe();
    this.generationSubscription?.unsubscribe();
    this.teamSubscription?.unsubscribe();
  }

  closeModal(): void {
    this.modalService.dismissAll();
  }

  onItemSelected(index: number): void {
    this.retries--;

    if (this.victoryOdds[index]?.text === 'Yes') {
      this.battleResultEvent.emit(true);
      return;
    }

    if (this.retries > 0) return;

    const potion = this.battleRetryService.findPotion(this.trainerItems);
    if (potion) {
      this.usePotion(potion);
      return;
    }

    this.battleResultEvent.emit(false);
  }

  itemName(item: ItemItem | undefined): string {
    return item ? this.translate.instant(item.text) : '';
  }

  private usePotion(potion: ItemItem): void {
    this.currentItem = potion;
    this.retries = this.battleRetryService.consume(potion, this.trainerItems);

    this.modalService.open(this.itemUsedModal, { centered: true, size: 'md' });
  }

  private pickOpponent(): EncounterCharacter | null {
    const options = battleTrainerByGeneration[this.generation?.id] ?? [];
    if (!options.length) return null;
    return options[Math.floor(Math.random() * options.length)];
  }

  /** Same odds model as every other battle. */
  private calcVictoryOdds(): void {
    this.victoryOdds = [{ text: 'Yes', fillStyle: 'green', weight: 1 }];

    this.trainerTeam.forEach((pokemon) => {
      for (let i = 0; i < pokemon.power; i++) {
        this.victoryOdds.push({ text: 'Yes', fillStyle: 'green', weight: 1 });
      }
    });

    for (let i = 0; i < this.plusModifiers(); i++) {
      this.victoryOdds.push({ text: 'Yes', fillStyle: 'green', weight: 1 });
    }

    for (let i = 0; i < this.currentRound; i++) {
      this.victoryOdds.push({ text: 'No', fillStyle: 'crimson', weight: 1 });
    }

    this.victoryOdds.push({ text: 'No', fillStyle: 'crimson', weight: 1 });

    const slices = this.typeAdvantage?.slices ?? 0;
    for (let i = 0; i < Math.abs(slices); i++) {
      this.victoryOdds.push(
        slices > 0
          ? { text: 'Yes', fillStyle: 'green', weight: 1 }
          : { text: 'No', fillStyle: 'crimson', weight: 1 }
      );
    }
  }

  private plusModifiers(): number {
    let power = 0;
    const xAttacks = this.trainerItems.filter((item) => item.name === 'x-attack');

    xAttacks.forEach(() => {
      power += this.trainerTeam.reduce((sum, p) => sum + p.power, 0) / Math.max(1, this.trainerTeam.length);
    });

    return power;
  }

  /** Scales to the gym the player is heading towards, like the rival does. */
  private buildEnemyTeam(): void {
    if (!this.isTypeAdvantageMode || !this.generation) {
      this.enemyTeam = [];
      this.typeAdvantage = null;
      return;
    }

    const nextGym = Math.min(this.currentRound, 7);
    const roster = battleTrainerTeamsByGeneration[this.generation.id] ?? [];

    this.enemyTeam = this.enemyTeamService.buildTeam(
      roster,
      this.generation.id,
      BATTLE_TRAINER_TYPES,
      scaledTrainerTeamSize(nextGym, this.trainerTeam?.length ?? 0),
      `trainer:${this.generation.id}:${nextGym}`,
      shouldBeFullyEvolved(nextGym),
      battleTrainerAceByGeneration[this.generation.id] ?? 0
    );

    this.typeAdvantage = this.enemyTeamService.scoreAdvantage(this.trainerTeam ?? [], this.enemyTeam);
  }
}
