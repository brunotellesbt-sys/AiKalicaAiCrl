import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { rivalByGeneration } from './rival-by-generation';
import { WheelComponent } from '../../../../wheel/wheel.component';
import { GameStateService } from '../../../../services/game-state-service/game-state.service';
import { GenerationService } from '../../../../services/generation-service/generation.service';
import { TrainerService } from '../../../../services/trainer-service/trainer.service';
import { GenerationItem } from '../../../../interfaces/generation-item';
import { PokemonItem } from '../../../../interfaces/pokemon-item';
import { ItemItem } from '../../../../interfaces/item-item';
import { WheelItem } from '../../../../interfaces/wheel-item';
import { ImgFallbackDirective } from '../../../../shared/img-fallback.directive';
import { GymLeader } from '../../../../interfaces/gym-leader';
import { RunService } from '../../../../services/run-service/run.service';
import {
  EnemyPokemon,
  EnemyTeamService,
  TypeAdvantage,
} from '../../../../services/enemy-team-service/enemy-team.service';
import { EnemyTeamPanelComponent } from '../../../enemy-team-panel/enemy-team-panel.component';
import { RIVAL_TYPES } from '../../../../data/trainer-type-themes';
import { rivalAceByGeneration, rivalTeamsByGeneration } from '../../../../data/trainer-teams';
import { BattleRetryService } from '../../../../services/battle-retry-service/battle-retry.service';
import { scaledTrainerTeamSize, shouldBeFullyEvolved } from '../../../../services/enemy-team-service/enemy-team-size';

@Component({
  selector: 'app-rival-battle-roulette',
  imports: [ImgFallbackDirective, CommonModule, WheelComponent, TranslatePipe, EnemyTeamPanelComponent],
  templateUrl: './rival-battle-roulette.component.html',
  styleUrl: './rival-battle-roulette.component.css',
})
export class RivalBattleRouletteComponent implements OnInit, OnDestroy {
  rivalByGeneration = rivalByGeneration;

  constructor(
    private modalService: NgbModal,
    private gameStateService: GameStateService,
    private generationService: GenerationService,
    private trainerService: TrainerService,
    private runService: RunService,
    private enemyTeamService: EnemyTeamService,
    private battleRetryService: BattleRetryService,
    private translate: TranslateService
  ) {}

  private gameSubscription: Subscription | null = null;
  private generationSubscription: Subscription | null = null;

  @ViewChild('gymLeaderPresentationModal', { static: true })
  gymLeaderPresentationModal!: TemplateRef<any>;
  @ViewChild('itemUsedModal', { static: true })
  itemUsedModal!: TemplateRef<any>;

  generation!: GenerationItem;
  trainerTeam!: PokemonItem[];
  trainerItems!: ItemItem[];
  @Input() currentRound!: number;
  @Output() battleResultEvent = new EventEmitter<boolean>();

  victoryOdds: WheelItem[] = [
    { text: 'Yes', fillStyle: 'green', weight: 1 },
    { text: 'No', fillStyle: 'crimson', weight: 1 },
  ];

  currentRival!: GymLeader;
  currentItem!: ItemItem;
  retries = 0;

  /** Type Advantage mode only — empty in Classic. */
  enemyTeam: EnemyPokemon[] = [];
  typeAdvantage: TypeAdvantage | null = null;

  get isTypeAdvantageMode(): boolean {
    return this.runService.isTypeAdvantageMode;
  }
  private teamSubscription!: Subscription;

  ngOnInit(): void {
    this.generationSubscription = this.generationService.getGeneration().subscribe((gen) => {
      this.generation = gen;
    });

    this.trainerItems = this.trainerService.getItems();

    this.teamSubscription = this.trainerService.getTeamObservable().subscribe((team) => {
      this.trainerTeam = team;
      this.buildEnemyTeam();
      this.calcVictoryOdds();
    });

    this.gameSubscription = this.gameStateService.currentState.subscribe((state) => {
      if (state === 'battle-rival') {
        this.currentRival = this.getCurrentRival();
        this.buildEnemyTeam();
        this.calcVictoryOdds();

        this.modalService.open(this.gymLeaderPresentationModal, {
          centered: true,
          size: 'lg',
        });
      }
    });
  }

  ngOnDestroy(): void {
    this.gameSubscription?.unsubscribe();
    this.generationSubscription?.unsubscribe();
    this.teamSubscription?.unsubscribe();
  }

  closeModal(): void {
    this.modalService.dismissAll();
  }

  onItemSelected(index: number): void {
    this.retries--;

    if (this.victoryOdds[index].text === 'Yes') {
      this.battleResultEvent.emit(true);
      return;
    }

    if (this.retries > 0) return;

    // Rival fights used to ignore potions entirely; every battle now offers the re-spin.
    // Only where losing actually costs something, though — in Classic a lost rival battle
    // has no penalty, so burning a potion on it would be a trap.
    const potion = this.isTypeAdvantageMode
      ? this.battleRetryService.findPotion(this.trainerItems)
      : undefined;

    if (potion) {
      this.usePotion(potion);
      return;
    }

    this.battleResultEvent.emit(false);
  }

  private usePotion(potion: ItemItem): void {
    this.currentItem = potion;
    this.retries = this.battleRetryService.consume(potion, this.trainerItems);

    this.modalService.open(this.itemUsedModal, { centered: true, size: 'md' });
  }

  itemName(item: ItemItem | undefined): string {
    return item ? this.translate.instant(item.text) : '';
  }

  private calcVictoryOdds(): void {
    this.victoryOdds = [];

    this.victoryOdds.push({ text: 'Yes', fillStyle: 'green', weight: 1 });

    this.trainerTeam.forEach((pokemon) => {
      for (let i = 0; i < pokemon.power; i++) {
        this.victoryOdds.push({ text: 'Yes', fillStyle: 'green', weight: 1 });
      }
    });

    const powerModifier = this.plusModifiers();
    for (let i = 0; i < powerModifier; i++) {
      this.victoryOdds.push({ text: 'Yes', fillStyle: 'green', weight: 1 });
    }

    for (let i = 0; i < this.currentRound; i++) {
      this.victoryOdds.push({ text: 'No', fillStyle: 'crimson', weight: 1 });
    }

    this.victoryOdds.push({ text: 'No', fillStyle: 'crimson', weight: 1 });

    // Type Advantage mode: the matchup tilts the same bag of slices the rest of the game
    // already uses, so it stacks with power, X Attack and the round penalty.
    const slices = this.typeAdvantage?.slices ?? 0;
    for (let i = 0; i < Math.abs(slices); i++) {
      this.victoryOdds.push(
        slices > 0
          ? { text: 'Yes', fillStyle: 'green', weight: 1 }
          : { text: 'No', fillStyle: 'crimson', weight: 1 }
      );
    }
  }

  /**
   * Builds the rival's squad and scores it.
   *
   * Rivals scale to the gym the player is heading towards, so an optional fight never
   * feels lighter or heavier than the badge it sits between.
   */
  private buildEnemyTeam(): void {
    if (!this.isTypeAdvantageMode || !this.generation) {
      this.enemyTeam = [];
      this.typeAdvantage = null;
      return;
    }

    const nextGym = Math.min(this.currentRound, 7);
    const roster = rivalTeamsByGeneration[this.generation.id] ?? [];

    this.enemyTeam = this.enemyTeamService.buildTeam(
      roster,
      this.generation.id,
      RIVAL_TYPES,
      scaledTrainerTeamSize(nextGym, this.trainerTeam?.length ?? 0),
      `rival:${this.generation.id}:${nextGym}`,
      shouldBeFullyEvolved(nextGym),
      rivalAceByGeneration[this.generation.id] ?? 0
    );

    this.typeAdvantage = this.enemyTeamService.scoreAdvantage(this.trainerTeam ?? [], this.enemyTeam);
  }

  private plusModifiers(): number {
    let power = 0;
    const xAttacks = this.trainerItems.filter((item) => item.name === 'x-attack');

    xAttacks.forEach(() => {
      const meanPower =
        this.trainerTeam.reduce((sum, pokemon) => sum + pokemon.power, 0) / this.trainerTeam.length;
      power += meanPower;
    });

    return power;
  }

  private getCurrentRival(): GymLeader {
    const options = this.rivalByGeneration[this.generation.id] || [];

    if (!options || options.length === 0) {
      return {
        name: 'Rival',
        sprite: '',
        quotes: ['...'],
      };
    }

    // Some generations can have multiple possible rivals (e.g. Gen 5).
    const idx = Math.floor(Math.random() * options.length);
    return options[idx];
  }
}
