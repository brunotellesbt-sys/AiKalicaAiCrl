import { GymLeader } from '../../../../interfaces/gym-leader';

/**
 * Rival opponents per generation.
 *
 * NOTE: This roster is for the roulette (visual flavor).
 * Gen 5 intentionally has two possible rivals (Hugh OR N), picked at random.
 */
export const rivalByGeneration: Record<number, GymLeader[]> = {
  1: [
    {
      name: 'Gary',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/blue.png',
      quotes: ['Smell ya later!'],
    },
  ],
  2: [
    {
      // Eugene is the name used in some media for Eusine.
      name: 'Eugene',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/eusine.png',
      quotes: ['I am tracking the legendary Suicune!'],
    },
  ],
  3: [
    {
      name: 'Wally',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/wally.png',
      quotes: ['I will not lose!'],
    },
  ],
  4: [
    {
      name: 'Barry',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/barry.png',
      quotes: ['I am gonna fine you!'],
    },
  ],
  5: [
    {
      name: 'Hugh',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/hugh.png',
      quotes: ['Let us do this!'],
    },
    {
      name: 'N',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/n.png',
      quotes: ['Let us see what your Pokemon can do.'],
    },
  ],
  6: [
    {
      name: 'Shauna',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/shauna.png',
      quotes: ['Let us have a battle!'],
    },
  ],
  7: [
    {
      name: 'Gladion',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/gladion.png',
      quotes: ['I am not going easy on you.'],
    },
  ],
  8: [
    {
      name: 'Marnie',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/marnie.png',
      quotes: ['I will give it my all.'],
    },
  ],
  9: [
    {
      name: 'Nemona',
      sprite: 'https://play.pokemonshowdown.com/sprites/trainers/nemona-v.png',
      quotes: ['I have been waiting for this battle!'],
    },
  ],
};
