import { Component, EventEmitter, OnDestroy, OnInit, Output, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { NgIf } from '@angular/common';
import { forkJoin, map, Subscription } from 'rxjs';
import { TranslatePipe } from '@ngx-translate/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { WheelComponent } from '../../../../wheel/wheel.component';
import { PokemonItem } from '../../../../interfaces/pokemon-item';
import { MegaEvolutionService, MegaForm } from '../../../../services/mega-evolution-service/mega-evolution.service';
import { PokemonService } from '../../../../services/pokemon-service/pokemon.service';
import { TrainerService } from '../../../../services/trainer-service/trainer.service';

type MegaRouletteMode = 'select-pokemon' | 'select-mega-form';

@Component({
  selector: 'app-mega-evolution-roulette',
  imports: [WheelComponent, TranslatePipe, NgIf],
  templateUrl: './mega-evolution-roulette.component.html',
  styleUrl: './mega-evolution-roulette.component.css'
})
export class MegaEvolutionRouletteComponent implements OnInit, OnDestroy {
  @Output() megaEvolutionFinished = new EventEmitter<void>();

  @ViewChild('megaEvolutionModal', { static: true }) megaEvolutionModal!: TemplateRef<any>;
  @ViewChild('fxCanvas') fxCanvas?: ElementRef<HTMLCanvasElement>;

  mode: MegaRouletteMode = 'select-pokemon';
  wheelTitle = 'Mega Evolution';

  isLoading = true;

  /** Candidates: team Pokémon that can Mega Evolve and their available Mega forms. */
  private megaCandidates: Array<{ pokemon: PokemonItem; megaForms: MegaForm[] }> = [];

  /** Current wheel items (either Pokémon or Mega forms). */
  wheelItems: any[] = [];

  /** When selecting a Mega form, this is the Pokémon chosen in the previous wheel. */
  private selectedPokemonForMega: PokemonItem | null = null;

  /** Selected Mega form (for cry). */
  private selectedMegaForm: MegaForm | null = null;

  /** Popup data */
  popupBeforeNameKey = '';
  popupAfterName = '';
  popupBeforeSpriteUrl = '';
  popupAfterSpriteUrl = '';

  /** Animation */
  isMegaAnimating = false;
  isCryPhase = false;
  megaTypes: string[] = [];

  private subs = new Subscription();
  private modalRef: NgbModalRef | null = null;

  // VFX loop handles
  private vfxStopAt = 0;
  private vfxRaf: number | null = null;
  private sfxOscStop: (() => void) | null = null;

  constructor(
    private trainerService: TrainerService,
    private megaEvolutionService: MegaEvolutionService,
    private pokemonService: PokemonService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    const team = this.trainerService.getTeam();

    if (!team || team.length === 0) {
      this.isLoading = false;
      this.megaEvolutionFinished.emit();
      return;
    }

    const requests = team.map((p) =>
      this.megaEvolutionService.getMegaFormsForPokemon(p).pipe(
        map((forms) => ({ pokemon: p, megaForms: forms }))
      )
    );

    const sub = forkJoin(requests).subscribe({
      next: (results) => {
        this.megaCandidates = results.filter((r) => (r.megaForms?.length ?? 0) > 0);
        this.isLoading = false;

        if (this.megaCandidates.length === 0) {
          this.megaEvolutionFinished.emit();
          return;
        }

        this.mode = 'select-pokemon';
        this.wheelTitle = 'Mega Evolution';
        this.wheelItems = this.megaCandidates.map((c) => c.pokemon);
      },
      error: () => {
        this.isLoading = false;
        this.megaEvolutionFinished.emit();
      }
    });

    this.subs.add(sub);
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
    try { this.modalRef?.close(); } catch {}
    this.stopTypeVfx();
    this.stopMegaEvolutionSfx();
  }

  onItemSelected(index: number): void {
    if (this.isLoading) return;

    if (this.mode === 'select-pokemon') {
      const candidate = this.megaCandidates[index];
      if (!candidate) {
        this.megaEvolutionFinished.emit();
        return;
      }

      this.selectedPokemonForMega = candidate.pokemon;

      if ((candidate.megaForms?.length ?? 0) <= 1) {
        this.applyMegaEvolution(candidate.pokemon, candidate.megaForms[0]);
        return;
      }

      this.mode = 'select-mega-form';
      this.wheelTitle = 'Mega Evolution';
      this.wheelItems = candidate.megaForms.map((f) => ({
        text: f.displayName,
        fillStyle: candidate.pokemon.fillStyle,
        weight: 1,
        _megaForm: f,
      }));
      return;
    }

    const selected = this.wheelItems[index] as any;
    const megaForm: MegaForm | undefined = selected?._megaForm;

    if (!this.selectedPokemonForMega || !megaForm) {
      this.megaEvolutionFinished.emit();
      return;
    }

    this.applyMegaEvolution(this.selectedPokemonForMega, megaForm);
  }

  private applyMegaEvolution(pokemon: PokemonItem, megaForm: MegaForm): void {
    // Snapshot BEFORE mutation
    this.popupBeforeNameKey = pokemon.text;
    this.popupBeforeSpriteUrl = pokemon.shiny
      ? (pokemon.sprite?.front_shiny || pokemon.sprite?.front_default || '')
      : (pokemon.sprite?.front_default || '');

    this.popupAfterName = megaForm.displayName;
    this.selectedMegaForm = megaForm;

    const sub = this.megaEvolutionService.megaEvolveForBattle(pokemon, megaForm).subscribe({
      next: () => {
        // After sprite (pokemon object already updated)
        this.popupAfterSpriteUrl = pokemon.shiny
          ? (pokemon.sprite?.front_shiny || pokemon.sprite?.front_default || '')
          : (pokemon.sprite?.front_default || '');

        // Types for VFX (use Mega form id)
        this.pokemonService.getPokemonTypes(megaForm.pokemonId).subscribe({
          next: (types: string[]) => (this.megaTypes = (types ?? []).slice(0, 2)),
          error: () => (this.megaTypes = []),
        });

        this.openMegaPopupAndProceed();
      },
      error: () => {
        this.megaEvolutionFinished.emit();
      }
    });

    this.subs.add(sub);
  }

  private openMegaPopupAndProceed(): void {
    try {
      this.isMegaAnimating = true;
      this.isCryPhase = false;

      this.modalRef = this.modalService.open(this.megaEvolutionModal, {
        centered: true,
        backdrop: 'static',
        keyboard: false,
      });

      // Start on next tick (after DOM is available)
      setTimeout(() => {
        this.playMegaEvolutionSfx();
        this.startTypeVfx(3000);

        setTimeout(async () => {
          this.isMegaAnimating = false;
          this.isCryPhase = true;

          await this.playMegaCry();

          try {
            this.modalRef?.close();
          } finally {
            this.megaEvolutionFinished.emit();
          }
        }, 3000);
      }, 0);

      this.modalRef.result.finally(() => {
        this.stopTypeVfx();
        this.stopMegaEvolutionSfx();
        this.isMegaAnimating = false;
        this.isCryPhase = false;
        this.selectedMegaForm = null;
        this.selectedPokemonForMega = null;
        this.mode = 'select-pokemon';
      });
    } catch {
      this.megaEvolutionFinished.emit();
    }
  }

  private playMegaEvolutionSfx(): void {
    // Lightweight "mega evolution" sound using WebAudio (no extra assets).
    try {
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'triangle';

      osc1.frequency.setValueAtTime(220, now);
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.65);

      osc2.frequency.setValueAtTime(440, now);
      osc2.frequency.exponentialRampToValueAtTime(110, now + 0.65);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.22, now + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.70);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.75);
      osc2.stop(now + 0.75);

      this.sfxOscStop = () => {
        try { osc1.stop(); } catch {}
        try { osc2.stop(); } catch {}
        try { ctx.close(); } catch {}
      };
    } catch {
      // ignore
    }
  }

  private stopMegaEvolutionSfx(): void {
    try { this.sfxOscStop?.(); } catch {}
    this.sfxOscStop = null;
  }

  private buildShowdownCryName(apiName: string): string {
    let name = (apiName || '').toLowerCase();
    name = name.replace(/-mega-x$/, '-megax');
    name = name.replace(/-mega-y$/, '-megay');
    return name;
  }

  private playMegaCry(): Promise<void> {
    const mega = this.selectedMegaForm;
    if (!mega) return Promise.resolve();

    const base = this.buildShowdownCryName(mega.apiName);
    const baseUrl = 'https://play.pokemonshowdown.com/audio/cries/';
    const candidates = [`${baseUrl}${base}.mp3`, `${baseUrl}${base}.ogg`];

    return new Promise((resolve) => {
      let idx = 0;
      const tryPlay = () => {
        if (idx >= candidates.length) {
          resolve();
          return;
        }

        const audio = new Audio();
        audio.src = candidates[idx++];
        audio.preload = 'auto';

        audio.onended = () => resolve();
        audio.onerror = () => tryPlay();
        audio.oncanplaythrough = async () => {
          try {
            await audio.play();
          } catch {
            // If autoplay is blocked, don't stall the game.
            resolve();
          }
        };
      };

      tryPlay();
    });
  }

  private startTypeVfx(durationMs: number): void {
    const canvas = this.fxCanvas?.nativeElement;
    if (!canvas) return;

    const resize = () => {
      const parent = canvas.parentElement;
      const w = parent?.clientWidth ?? 420;
      const h = parent?.clientHeight ?? 260;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
    };

    resize();

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;

    type Particle = { x: number; y: number; vx: number; vy: number; r: number; a: number; kind: string; ttl: number; };
    const parts: Particle[] = [];
    const types = (this.megaTypes && this.megaTypes.length > 0) ? this.megaTypes : ['psychic'];

    const colorFor = (kind: string) => {
      switch (kind) {
        case 'fire': return 'rgba(255, 120, 40, ';
        case 'water': return 'rgba(80, 160, 255, ';
        case 'electric': return 'rgba(255, 235, 80, ';
        case 'grass': return 'rgba(90, 200, 90, ';
        case 'ice': return 'rgba(160, 240, 255, ';
        case 'poison': return 'rgba(200, 90, 220, ';
        case 'ground': return 'rgba(200, 160, 90, ';
        case 'rock': return 'rgba(170, 150, 120, ';
        case 'psychic': return 'rgba(255, 120, 200, ';
        case 'ghost': return 'rgba(160, 120, 220, ';
        case 'dark': return 'rgba(80, 80, 110, ';
        case 'steel': return 'rgba(170, 190, 210, ';
        case 'dragon': return 'rgba(130, 110, 255, ';
        case 'fighting': return 'rgba(230, 90, 70, ';
        case 'flying': return 'rgba(140, 200, 255, ';
        case 'bug': return 'rgba(170, 220, 80, ';
        case 'normal': return 'rgba(220, 220, 220, ';
        case 'fairy': return 'rgba(255, 170, 230, ';
        default: return 'rgba(255, 255, 255, ';
      }
    };

    const spawn = (kind: string) => {
      const w = canvas.width;
      const h = canvas.height;
      const x = Math.random() * w;
      const y = h + Math.random() * (h * 0.2);

      let vx = (Math.random() - 0.5) * 0.25 * dpr;
      let vy = -(0.6 + Math.random() * 1.2) * dpr;
      let r = (2 + Math.random() * 5) * dpr;
      let a = 0.2 + Math.random() * 0.6;
      let ttl = 900 + Math.random() * 900;

      if (kind === 'electric') { vx *= 2.4; vy *= 0.8; r *= 0.7; }
      if (kind === 'fire') { vy *= 1.3; r *= 1.1; }
      if (kind === 'water') { vy *= 0.9; r *= 1.2; }
      if (kind === 'ice') { vy *= 0.7; r *= 1.3; }
      if (kind === 'fairy') { vx *= 0.6; r *= 1.1; }

      parts.push({ x, y, vx, vy, r, a, kind, ttl });
    };

    const draw = (p: Particle) => {
      if (p.kind === 'electric') {
        ctx.strokeStyle = colorFor(p.kind) + (p.a) + ')';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        const zig = 3 + Math.floor(Math.random() * 3);
        ctx.moveTo(p.x, p.y);
        for (let i = 0; i < zig; i++) {
          ctx.lineTo(p.x + (Math.random() - 0.5) * 18 * dpr, p.y + (Math.random() - 0.5) * 18 * dpr);
        }
        ctx.stroke();
        return;
      }

      if (p.kind === 'water') {
        ctx.strokeStyle = colorFor(p.kind) + (p.a) + ')';
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.stroke();
        return;
      }

      ctx.fillStyle = colorFor(p.kind) + (p.a) + ')';
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    };

    const start = performance.now();
    this.vfxStopAt = start + durationMs;

    const tick = (t: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // spawn a mix of both types if dual-typed
      const rate = 7;
      for (let i = 0; i < rate; i++) {
        spawn(types[i % types.length]);
      }

      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.x += p.vx;
        p.y += p.vy;
        p.ttl -= 16;
        p.a *= 0.996;
        p.vx += (Math.random() - 0.5) * 0.01 * dpr;

        draw(p);

        if (p.ttl <= 0 || p.y < -50 * dpr) parts.splice(i, 1);
      }

      if (t < this.vfxStopAt) {
        this.vfxRaf = requestAnimationFrame(tick);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        this.vfxRaf = null;
      }
    };

    this.vfxRaf = requestAnimationFrame(tick);
  }

  private stopTypeVfx(): void {
    const canvas = this.fxCanvas?.nativeElement;
    if (this.vfxRaf != null) {
      cancelAnimationFrame(this.vfxRaf);
      this.vfxRaf = null;
    }
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  }
}
