import { Component, EventEmitter, OnDestroy, OnInit, Output, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { NgIf } from '@angular/common';
import { forkJoin, map, Subscription } from 'rxjs';
import { TranslatePipe } from '@ngx-translate/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { WheelComponent } from '../../../../wheel/wheel.component';
import { PokemonItem } from '../../../../interfaces/pokemon-item';
import { MegaEvolutionService, MegaForm } from '../../../../services/mega-evolution-service/mega-evolution.service';
import { PokemonService } from '../../../../services/pokemon-service/pokemon.service';
import { TrainerService } from '../../../../services/trainer-service/trainer.service';

type MegaRouletteMode = 'select-pokemon' | 'select-mega-form';

@Component({
  selector: 'app-mega-evolution-roulette',
  imports: [WheelComponent, TranslatePipe, NgIf],
  templateUrl: './mega-evolution-roulette.component.html',
  styleUrl: './mega-evolution-roulette.component.css'
})
export class MegaEvolutionRouletteComponent implements OnInit, OnDestroy {
  @Output() megaEvolutionFinished = new EventEmitter<void>();

  @ViewChild('megaEvolutionModal', { static: true }) megaEvolutionModal!: TemplateRef<any>;
  @ViewChild('fxCanvas') fxCanvas?: ElementRef<HTMLCanvasElement>;

  mode: MegaRouletteMode = 'select-pokemon';
  wheelTitle = 'Mega Evolution';

  isLoading = true;

  /** Candidates: team Pokémon that can Mega Evolve and their available Mega forms. */
  private megaCandidates: Array<{ pokemon: PokemonItem; megaForms: MegaForm[] }> = [];

  /** Current wheel items (either Pokémon or Mega forms). */
  wheelItems: any[] = [];

  /** When selecting a Mega form, this is the Pokémon chosen in the previous wheel. */
  private selectedPokemonForMega: PokemonItem | null = null;

  /** Selected Mega form (for cry). */
  private selectedMegaForm: MegaForm | null = null;

  /** Popup data */
  popupBeforeNameKey = '';
  popupAfterName = '';
  popupBeforeSpriteUrl = '';
  popupAfterSpriteUrl = '';

  /** Animation */
  isMegaAnimating = false;
  isCryPhase = false;
  megaTypes: string[] = [];

  private subs = new Subscription();
  private modalRef: NgbModalRef | null = null;

  // VFX loop handles
  private vfxStopAt = 0;
  private vfxRaf: number | null = null;
  private sfxOscStop: (() => void) | null = null;

  constructor(
    private trainerService: TrainerService,
    private megaEvolutionService: MegaEvolutionService,
    private pokemonService: PokemonService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    const team = this.trainerService.getTeam();

    if (!team || team.length === 0) {
      this.isLoading = false;
      this.megaEvolutionFinished.emit();
      return;
    }

    const requests = team.map((p) =>
      this.megaEvolutionService.getMegaFormsForPokemon(p).pipe(
        map((forms) => ({ pokemon: p, megaForms: forms }))
      )
    );

    const sub = forkJoin(requests).subscribe({
      next: (results) => {
        this.megaCandidates = results.filter((r) => (r.megaForms?.length ?? 0) > 0);
        this.isLoading = false;

        if (this.megaCandidates.length === 0) {
          this.megaEvolutionFinished.emit();
          return;
        }

        this.mode = 'select-pokemon';
        this.wheelTitle = 'Mega Evolution';
        this.wheelItems = this.megaCandidates.map((c) => c.pokemon);
      },
      error: () => {
        this.isLoading = false;
        this.megaEvolutionFinished.emit();
      }
    });

    this.subs.add(sub);
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
    try { this.modalRef?.close(); } catch {}
    this.stopTypeVfx();
    this.stopMegaEvolutionSfx();
  }

  onItemSelected(index: number): void {
    if (this.isLoading) return;

    if (this.mode === 'select-pokemon') {
      const candidate = this.megaCandidates[index];
      if (!candidate) {
        this.megaEvolutionFinished.emit();
        return;
      }

      this.selectedPokemonForMega = candidate.pokemon;

      if ((candidate.megaForms?.length ?? 0) <= 1) {
        this.applyMegaEvolution(candidate.pokemon, candidate.megaForms[0]);
        return;
      }

      this.mode = 'select-mega-form';
      this.wheelTitle = 'Mega Evolution';
      this.wheelItems = candidate.megaForms.map((f) => ({
        text: f.displayName,
        fillStyle: candidate.pokemon.fillStyle,
        weight: 1,
        _megaForm: f,
      }));
      return;
    }

    const selected = this.wheelItems[index] as any;
    const megaForm: MegaForm | undefined = selected?._megaForm;

    if (!this.selectedPokemonForMega || !megaForm) {
      this.megaEvolutionFinished.emit();
      return;
    }

    this.applyMegaEvolution(this.selectedPokemonForMega, megaForm);
  }

  private applyMegaEvolution(pokemon: PokemonItem, megaForm: MegaForm): void {
    // Snapshot BEFORE mutation
    this.popupBeforeNameKey = pokemon.text;
    this.popupBeforeSpriteUrl = pokemon.shiny
      ? (pokemon.sprite?.front_shiny || pokemon.sprite?.front_default || '')
      : (pokemon.sprite?.front_default || '');

    this.popupAfterName = megaForm.displayName;
    this.selectedMegaForm = megaForm;

    const sub = this.megaEvolutionService.megaEvolveForBattle(pokemon, megaForm).subscribe({
      next: () => {
        // After sprite (pokemon object already updated)
        this.popupAfterSpriteUrl = pokemon.shiny
          ? (pokemon.sprite?.front_shiny || pokemon.sprite?.front_default || '')
          : (pokemon.sprite?.front_default || '');

        // Types for VFX (use Mega form id)
        this.pokemonService.getPokemonTypes(megaForm.pokemonId).subscribe({
          next: (types: string[]) => (this.megaTypes = (types ?? []).slice(0, 2)),
          error: () => (this.megaTypes = []),
        });

        this.openMegaPopupAndProceed();
      },
      error: () => {
        this.megaEvolutionFinished.emit();
      }
    });

    this.subs.add(sub);
  }

  private openMegaPopupAndProceed(): void {
    try {
      this.isMegaAnimating = true;
      this.isCryPhase = false;

      this.modalRef = this.modalService.open(this.megaEvolutionModal, {
        centered: true,
        backdrop: 'static',
        keyboard: false,
      });

      // Start on next tick (after DOM is available)
      setTimeout(() => {
        this.playMegaEvolutionSfx();
        this.startTypeVfx(3000);

        setTimeout(async () => {
          this.isMegaAnimating = false;
          this.isCryPhase = true;

          await this.playMegaCry();

          try {
            this.modalRef?.close();
          } finally {
            this.megaEvolutionFinished.emit();
          }
        }, 3000);
      }, 0);

      this.modalRef.result.finally(() => {
        this.stopTypeVfx();
        this.stopMegaEvolutionSfx();
        this.isMegaAnimating = false;
        this.isCryPhase = false;
        this.selectedMegaForm = null;
        this.selectedPokemonForMega = null;
        this.mode = 'select-pokemon';
      });
    } catch {
      this.megaEvolutionFinished.emit();
    }
  }

  private playMegaEvolutionSfx(): void {
    // Lightweight "mega evolution" sound using WebAudio (no extra assets).
    try {
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'triangle';

      osc1.frequency.setValueAtTime(220, now);
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.65);

      osc2.frequency.setValueAtTime(440, now);
      osc2.frequency.exponentialRampToValueAtTime(110, now + 0.65);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.22, now + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.70);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.75);
      osc2.stop(now + 0.75);

      this.sfxOscStop = () => {
        try { osc1.stop(); } catch {}
        try { osc2.stop(); } catch {}
        try { ctx.close(); } catch {}
      };
    } catch {
      // ignore
    }
  }

  private stopMegaEvolutionSfx(): void {
    try { this.sfxOscStop?.(); } catch {}
    this.sfxOscStop = null;
  }

  private buildShowdownCryName(apiName: string): string {
    let name = (apiName || '').toLowerCase();
    name = name.replace(/-mega-x$/, '-megax');
    name = name.replace(/-mega-y$/, '-megay');
    return name;
  }

  private playMegaCry(): Promise<void> {
    const mega = this.selectedMegaForm;
    if (!mega) return Promise.resolve();

    const base = this.buildShowdownCryName(mega.apiName);
    const baseUrl = 'https://play.pokemonshowdown.com/audio/cries/';
    const candidates = [`${baseUrl}${base}.mp3`, `${baseUrl}${base}.ogg`];

    return new Promise((resolve) => {
      let idx = 0;
      const tryPlay = () => {
        if (idx >= candidates.length) {
          resolve();
          return;
        }

        const audio = new Audio();
        audio.src = candidates[idx++];
        audio.preload = 'auto';

        audio.onended = () => resolve();
        audio.onerror = () => tryPlay();
        audio.oncanplaythrough = async () => {
          try {
            await audio.play();
          } catch {
            // If autoplay is blocked, don't stall the game.
            resolve();
          }
        };
      };

      tryPlay();
    });
  }

  private startTypeVfx(durationMs: number): void {
    const canvas = this.fxCanvas?.nativeElement;
    if (!canvas) return;

    const resize = () => {
      const parent = canvas.parentElement;
      const w = parent?.clientWidth ?? 420;
      const h = parent?.clientHeight ?? 260;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
    };

    resize();

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;

    
    type Particle = {
      x: number; y: number;
      vx: number; vy: number;
      r: number; a: number;
      kind: string;
      ttl: number;
      rot: number;
      spin: number;
      w: number;
      h: number;
      phase: number;
    };

    const parts: Particle[] = [];
    const types = (this.megaTypes && this.megaTypes.length > 0) ? this.megaTypes : ['psychic'];

    const colorFor = (kind: string) => {
      switch (kind) {
        case 'fire': return 'rgba(255, 120, 40, ';
        case 'water': return 'rgba(80, 160, 255, ';
        case 'electric': return 'rgba(255, 235, 80, ';
        case 'grass': return 'rgba(90, 200, 90, ';
        case 'ice': return 'rgba(160, 240, 255, ';
        case 'poison': return 'rgba(200, 90, 220, ';
        case 'ground': return 'rgba(200, 160, 90, ';
        case 'rock': return 'rgba(170, 150, 120, ';
        case 'psychic': return 'rgba(255, 120, 200, ';
        case 'ghost': return 'rgba(160, 120, 220, ';
        case 'dark': return 'rgba(60, 60, 90, ';
        case 'steel': return 'rgba(190, 205, 225, ';
        case 'dragon': return 'rgba(130, 110, 255, ';
        case 'fighting': return 'rgba(230, 90, 70, ';
        case 'flying': return 'rgba(140, 200, 255, ';
        case 'bug': return 'rgba(170, 220, 80, ';
        case 'normal': return 'rgba(235, 235, 235, ';
        case 'fairy': return 'rgba(255, 170, 230, ';
        default: return 'rgba(255, 255, 255, ';
      }
    };

    const drawStar = (x: number, y: number, r: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.beginPath();
      for (let i = 0; i < 10; i++) {
        const rr = (i % 2 === 0) ? r : r * 0.45;
        const a = (i * Math.PI) / 5;
        ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.restore();
    };

    const drawSnowflake = (x: number, y: number, r: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (i * Math.PI) / 3;
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
        // little branches
        const bx = Math.cos(a) * r * 0.65;
        const by = Math.sin(a) * r * 0.65;
        const ba1 = a + Math.PI / 8;
        const ba2 = a - Math.PI / 8;
        ctx.moveTo(bx, by);
        ctx.lineTo(bx + Math.cos(ba1) * r * 0.22, by + Math.sin(ba1) * r * 0.22);
        ctx.moveTo(bx, by);
        ctx.lineTo(bx + Math.cos(ba2) * r * 0.22, by + Math.sin(ba2) * r * 0.22);
      }
      ctx.restore();
    };

    const drawLeaf = (x: number, y: number, w: number, h: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.beginPath();
      ctx.ellipse(0, 0, w, h, 0, 0, Math.PI * 2);
      ctx.moveTo(-w * 0.9, 0);
      ctx.quadraticCurveTo(0, h * 0.4, w * 0.9, 0);
      ctx.restore();
    };

    const drawShard = (x: number, y: number, r: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.beginPath();
      ctx.moveTo(-r, -r * 0.2);
      ctx.lineTo(r * 0.9, -r);
      ctx.lineTo(r, r * 0.2);
      ctx.lineTo(-r * 0.6, r);
      ctx.closePath();
      ctx.restore();
    };

    const drawWisp = (x: number, y: number, r: number, phase: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.beginPath();
      const k = Math.sin(phase) * r * 0.6;
      ctx.moveTo(-r, 0);
      ctx.bezierCurveTo(-r * 0.3, -r + k, r * 0.3, r + k, r, 0);
      ctx.bezierCurveTo(r * 0.2, r * 0.4, -r * 0.2, -r * 0.4, -r, 0);
      ctx.closePath();
      ctx.restore();
    };

    const drawWind = (x: number, y: number, r: number, phase: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.beginPath();
      const amp = r * 0.35;
      ctx.moveTo(-r, 0);
      for (let i = 0; i <= 16; i++) {
        const t = i / 16;
        const xx = -r + t * (2 * r);
        const yy = Math.sin(phase + t * Math.PI * 2) * amp;
        ctx.lineTo(xx, yy);
      }
      ctx.restore();
    };

    const spawn = (kind: string) => {
      const w = canvas.width;
      const h = canvas.height;

      // default spawn at bottom
      let x = Math.random() * w;
      let y = h + Math.random() * (h * 0.15);

      // some types look better spawning centered
      if (kind === 'psychic' || kind === 'ghost' || kind === 'dark' || kind === 'fairy') {
        y = (h * 0.45) + (Math.random() - 0.5) * (h * 0.35);
      }
      if (kind === 'flying') {
        y = (h * 0.30) + Math.random() * (h * 0.50);
      }

      let vx = (Math.random() - 0.5) * 0.35 * dpr;
      let vy = -(0.7 + Math.random() * 1.4) * dpr;

      let r = (2 + Math.random() * 6) * dpr;
      let a = 0.25 + Math.random() * 0.6;
      let ttl = 900 + Math.random() * 950;

      let rot = Math.random() * Math.PI * 2;
      let spin = (Math.random() - 0.5) * 0.06;
      let pw = (2 + Math.random() * 6) * dpr;
      let ph = (2 + Math.random() * 6) * dpr;
      let phase = Math.random() * Math.PI * 2;

      switch (kind) {
        case 'electric':
          vx *= 3.0; vy *= 0.65; r *= 0.8; ttl *= 0.75;
          break;
        case 'water':
          vx *= 0.7; vy *= 0.8; r *= 1.25; a *= 0.9;
          break;
        case 'fire':
          vx *= 0.6; vy *= 1.35; r *= 1.2; a *= 0.95;
          break;
        case 'grass':
          vx *= 0.9; vy *= 1.05; pw *= 1.8; ph *= 1.2; spin *= 1.6;
          break;
        case 'rock':
          vx *= 0.8; vy *= 1.1; r *= 1.2; spin *= 1.2;
          break;
        case 'ground':
          vx *= 0.8; vy *= 0.55; r *= 1.35; a *= 0.8; ttl *= 0.9;
          break;
        case 'ice':
          vx *= 0.6; vy *= 0.7; r *= 1.2; a *= 0.85; spin *= 0.8;
          break;
        case 'psychic':
          vx *= 0.25; vy *= 0.25; r *= 1.6; ttl *= 0.9;
          break;
        case 'ghost':
          vx *= 0.35; vy *= 0.55; r *= 1.5; ttl *= 1.1;
          break;
        case 'dark':
          vx *= 0.25; vy *= 0.35; r *= 1.9; a *= 0.8; ttl *= 1.1;
          break;
        case 'steel':
          vx *= 1.1; vy *= 0.9; r *= 0.8; ttl *= 0.85;
          break;
        case 'dragon':
          vx *= 0.45; vy *= 0.8; r *= 1.0; ttl *= 0.95;
          break;
        case 'fighting':
          vx *= 1.2; vy *= 0.9; r *= 0.9; ttl *= 0.8;
          break;
        case 'flying':
          vx *= 1.1; vy *= 0.55; r *= 1.1; ttl *= 0.9;
          break;
        case 'bug':
          vx *= 0.95; vy *= 0.95; pw *= 1.2; ph *= 0.9; ttl *= 0.9;
          break;
        case 'normal':
          vx *= 0.7; vy *= 0.75; r *= 1.1;
          break;
        case 'fairy':
          vx *= 0.45; vy *= 0.55; r *= 1.2; ttl *= 1.05;
          break;
        case 'poison':
          vx *= 0.55; vy *= 0.6; r *= 1.25; ttl *= 1.0;
          break;
      }

      parts.push({ x, y, vx, vy, r, a, kind, ttl, rot, spin, w: pw, h: ph, phase });
    };

    const draw = (p: Particle) => {
      const base = colorFor(p.kind);
      const alpha = Math.max(0, Math.min(1, p.a));
      const w = canvas.width;
      const h = canvas.height;

      switch (p.kind) {
        case 'electric': {
          ctx.strokeStyle = base + alpha + ')';
          ctx.lineWidth = 2.2 * dpr;
          ctx.beginPath();
          const zig = 3 + Math.floor(Math.random() * 3);
          ctx.moveTo(p.x, p.y);
          for (let i = 0; i < zig; i++) {
            ctx.lineTo(
              p.x + (Math.random() - 0.5) * 22 * dpr,
              p.y + (Math.random() - 0.5) * 22 * dpr
            );
          }
          ctx.stroke();
          // tiny spark
          ctx.fillStyle = 'rgba(255,255,255,' + (alpha * 0.7) + ')';
          ctx.beginPath();
          ctx.arc(p.x, p.y, 1.6 * dpr, 0, Math.PI * 2);
          ctx.fill();
          return;
        }

        case 'water': {
          ctx.strokeStyle = base + alpha + ')';
          ctx.lineWidth = 1.6 * dpr;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = base + (alpha * 0.25) + ')';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 0.55, 0, Math.PI * 2);
          ctx.fill();
          return;
        }

        case 'fire': {
          // flame: teardrop
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = base + alpha + ')';
          ctx.beginPath();
          ctx.moveTo(0, -p.r * 1.6);
          ctx.quadraticCurveTo(p.r, -p.r * 0.4, 0, p.r * 1.2);
          ctx.quadraticCurveTo(-p.r, -p.r * 0.4, 0, -p.r * 1.6);
          ctx.closePath();
          ctx.fill();

          ctx.fillStyle = 'rgba(255, 230, 140,' + (alpha * 0.55) + ')';
          ctx.beginPath();
          ctx.moveTo(0, -p.r * 1.1);
          ctx.quadraticCurveTo(p.r * 0.55, -p.r * 0.25, 0, p.r * 0.65);
          ctx.quadraticCurveTo(-p.r * 0.55, -p.r * 0.25, 0, -p.r * 1.1);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
          return;
        }

        case 'grass': {
          ctx.fillStyle = base + (alpha * 0.95) + ')';
          drawLeaf(p.x, p.y, p.w, p.h, p.rot);
          ctx.fill();
          ctx.strokeStyle = 'rgba(240,255,240,' + (alpha * 0.4) + ')';
          ctx.lineWidth = 1 * dpr;
          drawLeaf(p.x, p.y, p.w, p.h, p.rot);
          ctx.stroke();
          return;
        }

        case 'rock': {
          ctx.fillStyle = base + (alpha * 0.95) + ')';
          drawShard(p.x, p.y, p.r * 1.2, p.rot);
          ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,' + (alpha * 0.25) + ')';
          ctx.lineWidth = 1 * dpr;
          drawShard(p.x, p.y, p.r * 1.2, p.rot);
          ctx.stroke();
          return;
        }

        case 'ground': {
          // dust puff
          ctx.fillStyle = base + (alpha * 0.5) + ')';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 1.4, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = base + (alpha * 0.28) + ')';
          ctx.beginPath();
          ctx.arc(p.x + 6 * dpr, p.y - 3 * dpr, p.r, 0, Math.PI * 2);
          ctx.fill();
          return;
        }

        case 'ice': {
          ctx.strokeStyle = base + alpha + ')';
          ctx.lineWidth = 1.5 * dpr;
          drawSnowflake(p.x, p.y, p.r * 1.1, p.rot);
          ctx.stroke();
          return;
        }

        case 'psychic': {
          // pulse ring
          ctx.strokeStyle = base + (alpha * 0.9) + ')';
          ctx.lineWidth = 1.8 * dpr;
          ctx.beginPath();
          const rr = p.r * (1.0 + (Math.sin(p.phase) * 0.35));
          ctx.arc(p.x, p.y, rr, 0, Math.PI * 2);
          ctx.stroke();
          ctx.strokeStyle = 'rgba(255,255,255,' + (alpha * 0.15) + ')';
          ctx.lineWidth = 1 * dpr;
          ctx.beginPath();
          ctx.arc(p.x, p.y, rr * 0.55, 0, Math.PI * 2);
          ctx.stroke();
          return;
        }

        case 'ghost': {
          ctx.fillStyle = base + (alpha * 0.8) + ')';
          drawWisp(p.x, p.y, p.r * 1.3, p.phase, p.rot);
          ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,' + (alpha * 0.12) + ')';
          ctx.lineWidth = 1 * dpr;
          drawWisp(p.x, p.y, p.r * 1.3, p.phase, p.rot);
          ctx.stroke();
          return;
        }

        case 'dark': {
          // shadow blob
          const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 2.2);
          grad.addColorStop(0, base + (alpha * 0.7) + ')');
          grad.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 2.2, 0, Math.PI * 2);
          ctx.fill();
          return;
        }

        case 'steel': {
          // metallic spark / shard
          ctx.strokeStyle = base + (alpha * 0.95) + ')';
          ctx.lineWidth = 2.2 * dpr;
          ctx.beginPath();
          const len = p.r * 3.2;
          ctx.moveTo(p.x - Math.cos(p.rot) * len, p.y - Math.sin(p.rot) * len);
          ctx.lineTo(p.x + Math.cos(p.rot) * len, p.y + Math.sin(p.rot) * len);
          ctx.stroke();
          ctx.strokeStyle = 'rgba(255,255,255,' + (alpha * 0.4) + ')';
          ctx.lineWidth = 1 * dpr;
          ctx.beginPath();
          ctx.moveTo(p.x - Math.cos(p.rot + 1.2) * len * 0.5, p.y - Math.sin(p.rot + 1.2) * len * 0.5);
          ctx.lineTo(p.x + Math.cos(p.rot + 1.2) * len * 0.5, p.y + Math.sin(p.rot + 1.2) * len * 0.5);
          ctx.stroke();
          return;
        }

        case 'dragon': {
          // spiral arc
          ctx.strokeStyle = base + (alpha * 0.9) + ')';
          ctx.lineWidth = 2.0 * dpr;
          ctx.beginPath();
          const turns = 2.2;
          const step = 18;
          for (let i = 0; i <= step; i++) {
            const t = i / step;
            const ang = p.rot + t * Math.PI * 2 * turns;
            const rr = p.r * (0.3 + t * 1.2);
            const xx = p.x + Math.cos(ang) * rr;
            const yy = p.y + Math.sin(ang) * rr;
            if (i === 0) ctx.moveTo(xx, yy);
            else ctx.lineTo(xx, yy);
          }
          ctx.stroke();
          return;
        }

        case 'fighting': {
          // impact streak
          ctx.strokeStyle = base + (alpha * 0.95) + ')';
          ctx.lineWidth = 2.6 * dpr;
          ctx.beginPath();
          const len = p.r * 3.0;
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + Math.cos(p.rot) * len, p.y + Math.sin(p.rot) * len);
          ctx.stroke();
          return;
        }

        case 'flying': {
          ctx.strokeStyle = base + (alpha * 0.7) + ')';
          ctx.lineWidth = 1.8 * dpr;
          drawWind(p.x, p.y, p.r * 2.0, p.phase, p.rot);
          ctx.stroke();
          return;
        }

        case 'bug': {
          // tiny winged dot
          ctx.fillStyle = base + (alpha * 0.9) + ')';
          ctx.beginPath();
          ctx.ellipse(p.x, p.y, p.w * 0.6, p.h * 0.5, p.rot, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = 'rgba(255,255,255,' + (alpha * 0.2) + ')';
          ctx.beginPath();
          ctx.ellipse(p.x - p.w * 0.7, p.y - p.h * 0.2, p.w * 0.45, p.h * 0.25, p.rot, 0, Math.PI * 2);
          ctx.ellipse(p.x + p.w * 0.7, p.y - p.h * 0.2, p.w * 0.45, p.h * 0.25, p.rot, 0, Math.PI * 2);
          ctx.fill();
          return;
        }

        case 'poison': {
          // toxic bubble + haze
          ctx.strokeStyle = base + (alpha * 0.9) + ')';
          ctx.lineWidth = 1.4 * dpr;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 1.1, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = base + (alpha * 0.18) + ')';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r * 1.1, 0, Math.PI * 2);
          ctx.fill();
          return;
        }

        case 'normal': {
          ctx.strokeStyle = base + (alpha * 0.9) + ')';
          ctx.lineWidth = 1.4 * dpr;
          drawStar(p.x, p.y, p.r * 1.2, p.rot);
          ctx.stroke();
          return;
        }

        case 'fairy': {
          ctx.fillStyle = base + (alpha * 0.95) + ')';
          drawStar(p.x, p.y, p.r * 1.35, p.rot);
          ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,' + (alpha * 0.25) + ')';
          ctx.lineWidth = 1 * dpr;
          drawStar(p.x, p.y, p.r * 1.35, p.rot);
          ctx.stroke();
          return;
        }

        default: {
          // fallback sparkle
          ctx.fillStyle = base + alpha + ')';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fill();
          return;
        }
      }
    };

    const start = performance.now();
    this.vfxStopAt = start + durationMs;

    const tick = (t: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // spawn a mix of both types if dual-typed
      const rate = 7;
      for (let i = 0; i < rate; i++) {
        spawn(types[i % types.length]);
      }

      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.x += p.vx;
        p.y += p.vy;
        p.ttl -= 16;
        p.a *= 0.996;
        p.vx += (Math.random() - 0.5) * 0.01 * dpr;
        p.rot += p.spin;
        p.phase += 0.08;

        draw(p);

        if (p.ttl <= 0 || p.y < -50 * dpr) parts.splice(i, 1);
      }

      if (t < this.vfxStopAt) {
        this.vfxRaf = requestAnimationFrame(tick);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        this.vfxRaf = null;
      }
    };

    this.vfxRaf = requestAnimationFrame(tick);
  }

  private stopTypeVfx(): void {
    const canvas = this.fxCanvas?.nativeElement;
    if (this.vfxRaf != null) {
      cancelAnimationFrame(this.vfxRaf);
      this.vfxRaf = null;
    }
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  }
}
