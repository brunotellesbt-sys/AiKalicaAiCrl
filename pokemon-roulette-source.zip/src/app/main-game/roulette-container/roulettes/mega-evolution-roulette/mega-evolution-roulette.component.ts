import { Component, EventEmitter, OnDestroy, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { map, Subscription, forkJoin } from 'rxjs';
import { TranslatePipe } from '@ngx-translate/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { WheelComponent } from '../../../../wheel/wheel.component';
import { PokemonItem } from '../../../../interfaces/pokemon-item';
import { MegaEvolutionService, MegaForm } from '../../../../services/mega-evolution-service/mega-evolution.service';
import { TrainerService } from '../../../../services/trainer-service/trainer.service';
import { PokemonService } from '../../../../services/pokemon-service/pokemon.service';

type MegaRouletteMode = 'select-pokemon' | 'select-mega-form';

@Component({
  selector: 'app-mega-evolution-roulette',
  imports: [WheelComponent, TranslatePipe, NgIf, NgFor, NgClass],
  templateUrl: './mega-evolution-roulette.component.html',
  styleUrl: './mega-evolution-roulette.component.css'
})
export class MegaEvolutionRouletteComponent implements OnInit, OnDestroy {
  @Output() megaEvolutionFinished = new EventEmitter<void>();

  @ViewChild('megaEvolutionModal') megaEvolutionModal!: TemplateRef<any>;

  mode: MegaRouletteMode = 'select-pokemon';
  wheelTitle = 'Mega Evolution';

  isLoading = true;

  /** Candidates: team Pokémon that can Mega Evolve and their available Mega forms. */
  private megaCandidates: Array<{ pokemon: PokemonItem; megaForms: MegaForm[] }> = [];

  /** Current wheel items (either Pokémon or Mega forms). */
  wheelItems: any[] = [];

  /** When selecting a Mega form, this is the Pokémon chosen in the previous wheel. */
  private selectedPokemonForMega: PokemonItem | null = null;

  /** Data for the popup. */
  popupBeforePokemon: PokemonItem | null = null;
  popupBeforeName = '';
  popupBeforeSpriteUrl = '';
  popupAfterName = '';
  popupAfterSpriteUrl = '';
  popupAfterTypes: string[] = [];
  isMegaAnimating = false;

  private audioCtx: AudioContext | null = null;
  private audioUnlocked = false;
  private cryAudio: HTMLAudioElement | null = null;
  private hasProceeded = false;

  private subs = new Subscription();
  private modalRef: NgbModalRef | null = null;

  constructor(
    private trainerService: TrainerService,
    private megaEvolutionService: MegaEvolutionService,
    private pokemonService: PokemonService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    const team = this.trainerService.getTeam();

    if (!team || team.length === 0) {
      // Nothing to do; proceed directly.
      this.isLoading = false;
      this.megaEvolutionFinished.emit();
      return;
    }

    // Fetch Mega forms for each Pokémon in the team.
    const requests = team.map((p) =>
      this.megaEvolutionService.getMegaFormsForPokemon(p)
        .pipe(
          // Map to a consistent structure.
          // (We keep the same Pokémon object reference so we can mutate it for battle.)
          map((forms) => ({ pokemon: p, megaForms: forms }))
        )
    );

    const sub = forkJoin(requests).subscribe({
      next: (results) => {
        this.megaCandidates = results.filter((r) => (r.megaForms?.length ?? 0) > 0);

        this.isLoading = false;

        if (this.megaCandidates.length === 0) {
          // Team has no Mega-capable Pokémon; skip this state.
          this.megaEvolutionFinished.emit();
          return;
        }

        this.mode = 'select-pokemon';
        this.wheelTitle = 'Mega Evolution';
        this.wheelItems = this.megaCandidates.map((c) => c.pokemon);
      },
      error: () => {
        this.isLoading = false;
        // If anything fails, don't block the game.
        this.megaEvolutionFinished.emit();
      }
    });

    this.subs.add(sub);
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
    this.modalRef?.close();
  }

  onItemSelected(index: number): void {
    if (this.isLoading) return;
    this.unlockAudioOnce();

    if (this.mode === 'select-pokemon') {
      const candidate = this.megaCandidates[index];
      if (!candidate) {
        this.megaEvolutionFinished.emit();
        return;
      }

      this.selectedPokemonForMega = candidate.pokemon;

      if ((candidate.megaForms?.length ?? 0) <= 1) {
        // Only one Mega form; apply immediately.
        const megaForm = candidate.megaForms[0];
        this.applyMegaEvolution(candidate.pokemon, megaForm);
        return;
      }

      // Multiple Mega forms: spin another roulette between them.
      this.mode = 'select-mega-form';
      this.wheelTitle = 'Mega Evolution';
      this.wheelItems = candidate.megaForms.map((f) => ({
        text: f.displayName,
        fillStyle: candidate.pokemon.fillStyle,
        weight: 1,
        _megaForm: f,
      }));
      return;
    }

    // Selecting the Mega form.
    const selected = this.wheelItems[index] as any;
    const megaForm: MegaForm | undefined = selected?._megaForm;

    if (!this.selectedPokemonForMega || !megaForm) {
      this.megaEvolutionFinished.emit();
      return;
    }

    this.applyMegaEvolution(this.selectedPokemonForMega, megaForm);
  }


  onManualContinue(_modal: any): void {
    this.safeCloseModalAndProceed();
  }

  private applyMegaEvolution(pokemon: PokemonItem, megaForm: MegaForm): void {
    // Prepare popup BEFORE we mutate the Pokémon.
    this.popupBeforePokemon = pokemon;
    this.popupBeforeName = pokemon.text;
    const beforeSprite = pokemon.sprite;
    this.popupBeforeSpriteUrl = pokemon.shiny
      ? (beforeSprite?.front_shiny || beforeSprite?.front_default || '')
      : (beforeSprite?.front_default || '');
    this.popupAfterName = megaForm.displayName;

    const sub = this.megaEvolutionService.megaEvolveForBattle(pokemon, megaForm).subscribe({
      next: () => {
        // Build the image URL for the "after" sprite.
        // (At this point, the Pokémon object has already been updated.)
        const sprite = pokemon.sprite;
        this.popupAfterSpriteUrl = pokemon.shiny
          ? (sprite?.front_shiny || sprite?.front_default || '')
          : (sprite?.front_default || '');

        // Fetch types for VFX (use Mega form id).
        const typesSub = this.pokemonService.getPokemonTypes(megaForm.pokemonId).subscribe({
          next: (types: string[]) => {
            this.popupAfterTypes = (types && types.length ? types : ['normal']);
            this.openMegaPopupAndProceed(megaForm);
          },
          error: () => {
            this.popupAfterTypes = ['normal'];
            this.openMegaPopupAndProceed(megaForm);
          }
        });
        this.subs.add(typesSub);

      },
      error: () => {
        // If it fails, proceed without Mega.
        this.megaEvolutionFinished.emit();
      }
    });

    this.subs.add(sub);
  }

  private openMegaPopupAndProceed(megaForm: MegaForm): void {
    try {
      // Reset animation state.
      this.hasProceeded = false;
      this.cryAudio?.pause();
      this.cryAudio = null;

      this.modalRef = this.modalService.open(this.megaEvolutionModal, {
        centered: true,
        backdrop: 'static',
        keyboard: false,
      });

      // Kick off the animation on the next tick (after DOM exists).
      setTimeout(() => {
        this.isMegaAnimating = true;

        // Play Mega evolution SFX during the 3s transformation.
        this.playMegaEvolutionSfx(3000);

        // After 3s, play cry of the mega-evolved form, then close when it ends.
        setTimeout(() => {
          this.playMegaCry(megaForm)
            .then(() => {
              // Closed in onended.
            })
            .catch(() => {
              // If cry fails, playMegaCry will still close and proceed.
            });
        }, 3000);
      }, 0);
    } catch {
      // If modal fails (shouldn't), just proceed.
      this.megaEvolutionFinished.emit();
    }
  }

  private safeCloseModalAndProceed(): void {
    if (this.hasProceeded) return;
    this.hasProceeded = true;
    try {
      this.modalRef?.close();
    } finally {
      this.megaEvolutionFinished.emit();
    }
  }

  private unlockAudioOnce(): void {
    if (this.audioUnlocked) return;

    try {
      // Create an AudioContext and resume it during a user gesture to satisfy autoplay policies.
      const Ctx: any = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (Ctx) {
        this.audioCtx = this.audioCtx ?? new Ctx();
        // resume() must be called inside a user interaction for many browsers.
        this.audioCtx!.resume();
      }
    } catch {
      // ignore
    }

    this.audioUnlocked = true;
  }

  private playMegaEvolutionSfx(durationMs: number): void {
    try {
      const ctx = this.audioCtx;
      if (!ctx) return;

      const now = ctx.currentTime;

      // A short rising "energy" sound built from two oscillators + filtered noise.
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.35, now + 0.10);
      gain.gain.exponentialRampToValueAtTime(0.12, now + durationMs / 1000 - 0.15);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + durationMs / 1000);

      const o1 = ctx.createOscillator();
      o1.type = 'sawtooth';
      o1.frequency.setValueAtTime(160, now);
      o1.frequency.exponentialRampToValueAtTime(720, now + durationMs / 1000);

      const o2 = ctx.createOscillator();
      o2.type = 'triangle';
      o2.frequency.setValueAtTime(220, now);
      o2.frequency.exponentialRampToValueAtTime(980, now + durationMs / 1000);

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(420, now);
      filter.frequency.exponentialRampToValueAtTime(1400, now + durationMs / 1000);

      o1.connect(filter);
      o2.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      o1.start(now);
      o2.start(now);
      o1.stop(now + durationMs / 1000);
      o2.stop(now + durationMs / 1000);
    } catch {
      // ignore
    }
  }

  private async playMegaCry(megaForm: MegaForm): Promise<void> {
    const id = this.toShowdownCryId(megaForm.apiName);
    const base = 'https://play.pokemonshowdown.com/audio/cries/src/';
    const primaryUrl = `${base}${id}.wav`;

    const fallbackBase = this.stripMegaSuffix(megaForm.apiName);
    const fallbackUrl = `${base}${this.toShowdownCryId(fallbackBase)}.wav`;

    const audio = new Audio();
    audio.crossOrigin = 'anonymous';
    audio.preload = 'auto';
    audio.volume = 1.0;

    const tryPlay = (url: string) => new Promise<void>((resolve, reject) => {
      audio.src = url;

      const cleanup = () => {
        audio.onended = null;
        audio.onerror = null;
      };

      audio.onended = () => {
        cleanup();
        resolve();
      };

      audio.onerror = () => {
        cleanup();
        reject(new Error('cry load failed'));
      };

      // Attempt play; if blocked, reject (we'll proceed without cry).
      audio.play().catch(reject);
    });

    this.cryAudio = audio;

    try {
      await tryPlay(primaryUrl);
    } catch {
      try {
        await tryPlay(fallbackUrl);
      } catch {
        throw new Error('cry playback failed');
      }
    } finally {
      this.safeCloseModalAndProceed();
    }
  }

  private toShowdownCryId(apiName: string): string {
    const n = String(apiName || '').toLowerCase().trim();

    // Pokémon Showdown uses "megax/megay" (no extra dash), e.g. charizard-megax.wav
    return n
      .replace('-mega-x', '-megax')
      .replace('-mega-y', '-megay');
  }

  private stripMegaSuffix(apiName: string): string {
    return String(apiName || '')
      .toLowerCase()
      .replace('-mega-x', '')
      .replace('-mega-y', '')
      .replace('-mega', '');
  }
}
