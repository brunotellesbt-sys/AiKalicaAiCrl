
import {
  Component,
  EventEmitter,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
  ChangeDetectionStrategy
} from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { WheelItem } from '../../../../interfaces/wheel-item';
import { PokemonItem } from '../../../../interfaces/pokemon-item';
import { ImgFallbackDirective } from '../../../../shared/img-fallback.directive';
import { WheelComponent } from '../../../../wheel/wheel.component';
import { GenerationService } from '../../../../services/generation-service/generation.service';
import { TrainerService } from '../../../../services/trainer-service/trainer.service';
import { RunService } from '../../../../services/run-service/run.service';
import {
  EnemyPokemon,
  EnemyTeamService,
  TypeAdvantage,
} from '../../../../services/enemy-team-service/enemy-team.service';
import { villainBossTeamSize } from '../../../../services/enemy-team-service/enemy-team-size';
import { villainBossTypesByGeneration } from '../../../../data/trainer-type-themes';
import { villainBossAceByGeneration, villainBossTeamsByGeneration } from '../../../../data/trainer-teams';
import { EnemyTeamPanelComponent } from '../../../enemy-team-panel/enemy-team-panel.component';
import { villainTeamByGeneration } from '../../../../data/generation-encounters';
import { ItemItem } from '../../../../interfaces/item-item';
import { BattleRetryService } from '../../../../services/battle-retry-service/battle-retry.service';

/** Wheel labels — matched by value so appended Type Advantage slices behave correctly. */
const DEFEAT_OUTCOME = 'villainBoss.outcome.defeat';
const STEAL_OUTCOME = 'villainBoss.outcome.steal';

@Component({
  selector: 'app-villain-boss-roulette',
  imports: [WheelComponent, ImgFallbackDirective, EnemyTeamPanelComponent, TranslatePipe],
  templateUrl: './villain-boss-roulette.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrl: './villain-boss-roulette.component.css',
})
export class VillainBossRouletteComponent implements OnInit {
  constructor(
    private modalService: NgbModal,
    private generationService: GenerationService,
    private trainerService: TrainerService,
    private runService: RunService,
    private enemyTeamService: EnemyTeamService,
    private battleRetryService: BattleRetryService,
    private translate: TranslateService
  ) {}

  @Output() defeatVillainEvent = new EventEmitter<void>();
  /**
   * Losing the boss battle means the villain team steals one of your Pokémon.
   * (No "run away" option for this finale encounter.)
   */
  @Output() stealPokemonEvent = new EventEmitter<void>();

  @ViewChild('itemUsedModal', { static: true })
  itemUsedModal!: TemplateRef<any>;

  @ViewChild('villainBossModal', { static: true })
  villainBossModal!: TemplateRef<any>;

  villainTeamName = 'Villain Team';
  villainTeamBlurb = '';
  villainLeaderName = '';
  villainLeaderSpriteUrl = '';
  villainLeaderBlurb = '';

  outcomes: WheelItem[] = [];

  trainerItems: ItemItem[] = [];
  currentItem?: ItemItem;
  /** Extra spins bought with a potion. */
  retries = 0;

  /** Type Advantage mode only — empty in Classic. */
  enemyTeam: EnemyPokemon[] = [];
  typeAdvantage: TypeAdvantage | null = null;
  playerTeam: PokemonItem[] = [];

  get isTypeAdvantageMode(): boolean {
    return this.runService.isTypeAdvantageMode;
  }

  /** Index of the boss on screen, so the roster lookup matches them. */
  bossIndex = 0;
  /** Wheel of possible bosses, for the regions that have more than one. */
  bossChoices: WheelItem[] = [];
  choosingBoss = false;

  /** The wheel stopped: that professor (or admin) is the one waiting for you. */
  onBossChosen(index: number): void {
    const genId = this.generationService.getCurrentGeneration().id;
    const leaders = (villainTeamByGeneration[genId] ?? villainTeamByGeneration[1]).leaders ?? [];

    this.bossIndex = index >= 0 && index < leaders.length ? index : 0;
    const leader = leaders[this.bossIndex];
    if (leader) {
      this.villainLeaderName = leader.name;
      this.villainLeaderSpriteUrl = leader.spriteUrl;
      this.villainLeaderBlurb = leader.blurb;
    }

    this.choosingBoss = false;
    this.buildEnemyTeam(genId);
  }

  /** The boss shows up after the 8th badge, so the squad matches the hardest rung. */
  private buildEnemyTeam(genId: number): void {
    if (!this.isTypeAdvantageMode) {
      this.enemyTeam = [];
      this.typeAdvantage = null;
      return;
    }

    this.playerTeam = this.trainerService.getTeam() ?? [];

    this.enemyTeam = this.enemyTeamService.buildTeam(
      (villainBossTeamsByGeneration[genId] ?? [])[this.bossIndex] ?? [],
      genId,
      villainBossTypesByGeneration[genId] ?? [],
      villainBossTeamSize(this.playerTeam.length),
      `villain:${genId}:${this.bossIndex}`,
      {
        fullyEvolved: true,
        aceId: (villainBossAceByGeneration[genId] ?? [])[this.bossIndex] ?? 0,
      }
    );

    this.typeAdvantage = this.enemyTeamService.scoreAdvantage(this.playerTeam, this.enemyTeam);
  }

  ngOnInit(): void {
    const genId = this.generationService.getCurrentGeneration().id;
    const encounter = villainTeamByGeneration[genId] ?? villainTeamByGeneration[1];

    this.villainTeamName = encounter.teamName;
    this.villainTeamBlurb = encounter.blurb;

    // Hoenn picks between Magma and Aqua, Paldea between Sada and Turo — spin for it
    // rather than deciding silently.
    const leaders = encounter.leaders ?? [];
    if (leaders.length > 1) {
      const colours = ['crimson', 'darkcyan'];
      this.bossChoices = leaders.map((boss, i) => ({
        text: boss.name,
        fillStyle: colours[i % colours.length],
        weight: 1,
      }));
      this.choosingBoss = true;
    } else {
      this.onBossChosen(0);
    }

    this.trainerItems = this.trainerService.getItems();

    // Boss encounter: keep it simple and impactful.
    // 50/50 between "Defeat" and "Lose (they steal a Pokémon)".
    this.outcomes = [
      // Keep labels short so they don't overlap on mobile.
      { text: DEFEAT_OUTCOME, fillStyle: 'green', weight: 1 },
      { text: STEAL_OUTCOME, fillStyle: 'crimson', weight: 1 },
    ];

    this.buildEnemyTeam(genId);

    // Type Advantage mode tilts the 50/50 the same way it tilts every other battle.
    const slices = this.typeAdvantage?.slices ?? 0;
    for (let i = 0; i < Math.abs(slices); i++) {
      this.outcomes.push(
        slices > 0
          ? { text: DEFEAT_OUTCOME, fillStyle: 'green', weight: 1 }
          : { text: STEAL_OUTCOME, fillStyle: 'crimson', weight: 1 }
      );
    }

    this.modalService.open(this.villainBossModal, {
      centered: true,
      size: 'lg',
    });
  }

  onItemSelected(index: number): void {
    this.retries--;

    // Match on the outcome itself, never on the index: Type Advantage appends extra
    // winning/losing slices, so "defeat" no longer lives only at position 0. Reading the
    // index here made a win on an added slice register as a loss.
    if (this.outcomes[index]?.text === DEFEAT_OUTCOME) {
      this.defeatVillainEvent.emit();
      return;
    }

    if (this.retries > 0) return;

    // A potion buys another spin before the loss is committed, same as every other battle.
    const potion = this.battleRetryService.findPotion(this.trainerItems);
    if (potion) {
      this.usePotion(potion);
      return;
    }

    this.stealPokemonEvent.emit();
  }

  private usePotion(potion: ItemItem): void {
    this.currentItem = potion;
    this.retries = this.battleRetryService.consume(potion, this.trainerItems);

    this.modalService.open(this.itemUsedModal, { centered: true, size: 'md' });
  }

  itemName(item: ItemItem | undefined): string {
    return item ? this.translate.instant(item.text) : '';
  }

  closeModal(): void {
    this.modalService.dismissAll();
  }
}
