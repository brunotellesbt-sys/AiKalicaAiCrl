import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { NgIf } from "@angular/common";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { TranslatePipe } from '@ngx-translate/core';

import { WheelComponent } from '../../../../wheel/wheel.component';
import { WheelItem } from '../../../../interfaces/wheel-item';
import { ImgFallbackDirective } from '../../../../shared/img-fallback.directive';
import { TeamRocketService } from '../../../../services/team-rocket-service/team-rocket.service';
import { GenerationService } from '../../../../services/generation-service/generation.service';
import { villainTeamByGeneration } from '../../../../data/generation-encounters';

@Component({
  selector: 'app-team-rocket-roulette',
  imports: [WheelComponent, TranslatePipe, ImgFallbackDirective, NgIf],
  templateUrl: './team-rocket-roulette.component.html',
  styleUrl: './team-rocket-roulette.component.css',
})
export class TeamRocketRouletteComponent implements OnInit, OnDestroy {
  @Output() teamRocketEvent = new EventEmitter<void>();
  @Output() caughtByTeamRocketEvent = new EventEmitter<void>();

  @ViewChild('teamRockerModal', { static: true })
  teamRockerModal!: TemplateRef<any>;

  private generationSub: Subscription | null = null;

  // Villain encounter data
  villainTeamName = 'Team Rocket';
  villainTeamBlurb = '';
  villainLeaderName = 'Giovanni';
  villainLeaderSpriteUrl = '';
  villainLeaderBlurb = '';

  // Wheel items
  outcomes: WheelItem[] = [];

  constructor(
    private modalService: NgbModal,
    private teamRocketService: TeamRocketService,
    private generationService: GenerationService
  ) {}

  ngOnInit(): void {
    // Choose villain team based on the current generation.
    this.generationSub = this.generationService.getGeneration().subscribe((gen) => {
      const encounter = villainTeamByGeneration[gen.id] || villainTeamByGeneration[1];
      this.villainTeamName = encounter.teamName;
      this.villainTeamBlurb = encounter.blurb;

      const leaders = encounter.leaders || [];
      const leader = leaders[Math.floor(Math.random() * leaders.length)] || leaders[0];
      if (leader) {
        this.villainLeaderName = leader.name;
        this.villainLeaderSpriteUrl = leader.spriteUrl;
        this.villainLeaderBlurb = leader.blurb;
      }

      this.updateWheelItems();

      // Show encounter modal every time this roulette loads.
      this.modalService.open(this.teamRockerModal, {
        centered: true,
        size: 'lg',
      });
    });
  }

  ngOnDestroy(): void {
    this.generationSub?.unsubscribe();
  }

  closeModal(): void {
    this.modalService.dismissAll();
  }

  onItemSelected(index: number): void {
    if (index === 0) {
      // Steal a Pokémon (only once)
      if (!this.teamRocketService.stolenPokemon) {
        this.teamRocketService.stolenPokemon = true;
        this.caughtByTeamRocketEvent.emit();
      }
      this.updateWheelItems();
      return;
    }

    if (index === 1) {
      // Nothing happens / you escape
      this.teamRocketEvent.emit();
      return;
    }

    // Defeat the villain team
    this.teamRocketEvent.emit();
  }

  private updateWheelItems(): void {
    const stoleText = this.teamRocketService.stolenPokemon
      ? `${this.villainTeamName} already stole a Pokémon…`
      : `${this.villainTeamName} steals a Pokémon!`;

    this.outcomes = [
      { text: stoleText, fillStyle: 'crimson', weight: 1 },
      { text: 'You escape!', fillStyle: '#0d6efd', weight: 1 },
      { text: `You defeat ${this.villainTeamName}!`, fillStyle: 'green', weight: 1 },
    ];
  }
}
