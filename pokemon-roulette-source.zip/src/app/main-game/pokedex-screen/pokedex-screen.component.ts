import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { PokemonService } from '../../services/pokemon-service/pokemon.service';
import { NgbModal, NgbModalModule, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { PokedexUiService } from '../../services/pokedex-ui.service';

type PokedexRow = {
  id: number;
  name: string;
  power: number;
  imgUrl: string;
  loading: boolean;
  heightM?: number;
  weightKg?: number;
  descriptionEn?: string;

  types?: string[];
  baseId?: number;
  formLabel?: string;
  megaForms?: string[];
  regionalForms?: string[];
};

type FormInfo = {
  title: string;
  kind: 'mega' | 'regional' | 'form';
  spriteUrl?: string;
  types: string[];
  power?: number;
  descriptionEn?: string;
  bulbapediaUrl?: string;
  pokeapiUrl?: string;
};

@Component({
  selector: 'app-pokedex-screen',
  standalone: true,
  imports: [CommonModule, FormsModule, NgbModalModule],
  templateUrl: './pokedex-screen.component.html',
  styleUrl: './pokedex-screen.component.css'
})
export class PokedexScreenComponent implements OnInit {
  private apiBaseUrl = 'https://pokeapi.co/api/v2';

  search = '';

  selectedType = '';
  readonly allTypes: string[] = [
    'normal','fire','water','electric','grass','ice','fighting','poison','ground','flying',
    'psychic','bug','rock','ghost','dragon','dark','steel','fairy'
  ];
  private typeIndexCache = new Map<string, Set<number>>();

  pageSize = 48;
  pageIndex = 0;

  allRows: PokedexRow[] = [];
  visibleRows: PokedexRow[] = [];

  private pokemonCache = new Map<number, { heightM: number; weightKg: number; types: string[] }>();
  private speciesCache = new Map<number, { descriptionEn: string; megaForms: string[]; regionalForms: string[] }>();

  @ViewChild('formInfoModal', { static: true }) formInfoModal!: TemplateRef<any>;
  @ViewChild('megaSelectModal', { static: true }) megaSelectModal!: TemplateRef<any>;

  megaSelectForms: string[] = [];
  megaSelectForName: string = '';
  megaSelectBasePower: number = 1;
  private megaSelectRef: NgbModalRef | null = null;

  formInfo: FormInfo | null = null;

  constructor(
    private http: HttpClient,
    private pokemonService: PokemonService,
    private modalService: NgbModal,
    private pokedexUi: PokedexUiService
  ) {}

  ngOnInit(): void {
    const dex = this.pokemonService.getAllPokemon()
      .slice()
      .sort((a, b) => a.pokemonId - b.pokemonId);

    this.allRows = dex.map((p) => {
      const id = p.pokemonId;
      const baseId = p.basePokemonId;
      const formLabel = baseId ? this.detectFormLabel(p.text) : undefined;

      return {
        id,
        name: this.prettyName(p.text),
        power: (p as any).power ?? 1,
        imgUrl: this.officialArtworkUrl(id),
        loading: false,
        baseId,
        formLabel
      };
    });

    this.refreshVisibleRows();
  }

  closePokedex(): void {
    try { this.modalService.dismissAll(); } catch {}
    this.pokedexUi.close();
  }

  onSearchChange(): void {
    this.pageIndex = 0;
    this.refreshVisibleRows();
  }

  onTypeChange(): void {
    this.pageIndex = 0;
    if (!this.selectedType) {
      this.refreshVisibleRows();
      return;
    }
    this.ensureTypeIndex(this.selectedType).subscribe({
      next: () => this.refreshVisibleRows(),
      error: () => this.refreshVisibleRows()
    });
  }

  prevPage(): void {
    if (this.pageIndex > 0) {
      this.pageIndex -= 1;
      this.refreshVisibleRows();
    }
  }

  nextPage(): void {
    const maxPage = Math.max(0, Math.ceil(this.filteredRows().length / this.pageSize) - 1);
    if (this.pageIndex < maxPage) {
      this.pageIndex += 1;
      this.refreshVisibleRows();
    }
  }

  pageLabel(): string {
    const total = this.filteredRows().length;
    const from = total === 0 ? 0 : this.pageIndex * this.pageSize + 1;
    const to = Math.min(total, (this.pageIndex + 1) * this.pageSize);
    return `${from}–${to} / ${total}`;
  }

  openMegaChip(row: any): void {
    const forms: string[] = row?.megaForms ?? [];
    if (forms.length === 0) return;

    if (forms.length === 1) {
      this.openFormDetails(forms[0], 'mega', row?.power);
      return;
    }

    this.megaSelectForms = forms.slice();
    this.megaSelectForName = row?.name ?? '';
    this.megaSelectBasePower = row?.power ?? 1;
    this.megaSelectRef = this.modalService.open(this.megaSelectModal, { centered: true, size: 'lg' });
  }

  filteredRows(): PokedexRow[] {
    const q = this.search.trim().toLowerCase();
    const type = (this.selectedType || '').trim().toLowerCase();
    const typeSet = type ? this.typeIndexCache.get(type) : undefined;

    let rows = this.allRows;
    if (type && typeSet) {
      rows = rows.filter((r) => typeSet.has(r.baseId ?? r.id) || typeSet.has(r.id));
    }

    if (!q) return rows;

    const idQuery = Number(q);
    if (!Number.isNaN(idQuery) && idQuery > 0) {
      return rows.filter((r) => r.id === idQuery || (r.baseId === idQuery));
    }

    return rows.filter((r) => r.name.toLowerCase().includes(q));
  }

  private refreshVisibleRows(): void {
    const rows = this.filteredRows();
    const start = this.pageIndex * this.pageSize;
    this.visibleRows = rows.slice(start, start + this.pageSize);
    this.loadDetailsForVisibleRows();
  }

  private loadDetailsForVisibleRows(): void {
    const toLoad = this.visibleRows.filter((r) => !this.pokemonCache.has(r.id) || !this.speciesCache.has(r.baseId ?? r.id));
    if (toLoad.length === 0) return;

    toLoad.forEach((row) => (row.loading = true));

    const pokemonRequests = toLoad.map((row) =>
      this.fetchPokemon(row.id).pipe(
        catchError(() => of({ heightM: 0, weightKg: 0, types: [] })),
        map((p) => ({ id: row.id, ...p }))
      )
    );

    const speciesRequests = toLoad.map((row) => {
      const sid = row.baseId ?? row.id;
      return this.fetchSpecies(sid).pipe(
        catchError(() => of({ descriptionEn: '', megaForms: [], regionalForms: [] })),
        map((s) => ({ sid, ...s }))
      );
    });

    forkJoin([forkJoin(pokemonRequests), forkJoin(speciesRequests)]).subscribe({
      next: ([pokemons, species]) => {
        for (const p of pokemons) {
          this.pokemonCache.set(p.id, { heightM: p.heightM, weightKg: p.weightKg, types: p.types });
        }
        for (const s of species) {
          this.speciesCache.set(s.sid, { descriptionEn: s.descriptionEn, megaForms: s.megaForms, regionalForms: s.regionalForms });
        }

        for (const row of this.visibleRows) {
          const p = this.pokemonCache.get(row.id);
          const s = this.speciesCache.get(row.baseId ?? row.id);
          if (p) {
            row.heightM = p.heightM;
            row.weightKg = p.weightKg;
            row.types = p.types;
          }
          if (s) {
            row.descriptionEn = s.descriptionEn;
            row.megaForms = s.megaForms;
            row.regionalForms = s.regionalForms;
          }
          row.loading = false;
        }
      },
      error: () => {
        for (const row of this.visibleRows) row.loading = false;
      }
    });
  }

  megaPowerFor(basePower: number): number {
    return basePower === 5 ? 6 : 5;
  }

  private resolveFormPower(kind: 'mega' | 'regional' | 'form', basePower?: number): number | undefined {
    if (basePower === undefined || basePower === null) return undefined;
    return kind === 'mega' ? this.megaPowerFor(basePower) : basePower;
  }

  openFormDetails(formName: string, kind: 'mega' | 'regional' | 'form' = 'form', basePower?: number): void {
    const slug = formName.trim().toLowerCase();
    const resolvedPower = this.resolveFormPower(kind, basePower);

    this.fetchPokemonByNameWithFallback(slug).pipe(
      switchMap((poke) => {
        const types = (poke?.types || []).map((t: any) => t?.type?.name).filter(Boolean);
        const spriteUrl =
          poke?.sprites?.other?.['official-artwork']?.front_default ||
          poke?.sprites?.front_default ||
          '';

        const speciesUrl = poke?.species?.url as string | undefined;
        if (!speciesUrl) {
          return of({
            title: this.prettyName(formName),
            kind,
            spriteUrl,
            types,
            power: resolvedPower,
            descriptionEn: '',
            bulbapediaUrl: this.bulbapediaUrlFor(formName, kind),
            pokeapiUrl: `${this.apiBaseUrl}/pokemon/${slug}`
          } as FormInfo);
        }

        return this.http.get<any>(speciesUrl).pipe(
          catchError(() => of(null)),
          map((sp) => {
            const descriptionEn = this.pickFlavorText(sp);
            const title = this.prettyName(formName);
            return {
              title,
              kind,
              spriteUrl,
              types,
              power: resolvedPower,
              descriptionEn,
              bulbapediaUrl: this.bulbapediaUrlFor(formName, kind),
              pokeapiUrl: `${this.apiBaseUrl}/pokemon/${slug}`
            } as FormInfo;
          })
        );
      }),
      catchError(() => of(null))
    ).subscribe((info) => {
      if (!info) return;
      this.formInfo = info;
      this.modalService.open(this.formInfoModal, { centered: true, size: 'lg' });
    });
  }

  chooseMegaForm(formName: string, modal: any): void {
    try { modal?.close?.(); } catch {}
    try { this.megaSelectRef?.close?.(); } catch {}
    this.megaSelectRef = null;
    this.openFormDetails(formName, 'mega', this.megaSelectBasePower);
  }

  displayFormName(formName: string): string {
    return this.prettyName(formName);
  }

  private fetchPokemon(id: number) {
    const url = `${this.apiBaseUrl}/pokemon/${id}`;
    return this.http.get<any>(url).pipe(
      map((data) => {
        const heightM = (data.height ?? 0) / 10;
        const weightKg = (data.weight ?? 0) / 10;
        const types = (data.types ?? []).map((t: any) => t?.type?.name).filter(Boolean);
        return { heightM, weightKg, types };
      })
    );
  }

  private fetchSpecies(speciesId: number) {
    const url = `${this.apiBaseUrl}/pokemon-species/${speciesId}`;
    return this.http.get<any>(url).pipe(
      map((data) => {
        const descriptionEn = this.pickFlavorText(data);

        const varieties: string[] = (data?.varieties ?? [])
          .map((v: any) => v?.pokemon?.name)
          .filter((n: any) => typeof n === 'string');

        const megaForms = varieties.filter((n) => n.includes('-mega') || n.includes('-megax') || n.includes('-megay') || n.includes('mega-x') || n.includes('mega-y'));
        const regionalForms = varieties.filter((n) => /-(alola|galar|hisui|paldea)\b/.test(n));

        return { descriptionEn, megaForms, regionalForms };
      })
    );
  }

  private pickFlavorText(speciesData: any): string {
    const entries: any[] = speciesData?.flavor_text_entries ?? [];
    const en = entries.find((e) => e?.language?.name === 'en');
    const txt = (en?.flavor_text || '') as string;
    return txt.replace(/\f/g, ' ').replace(/\s+/g, ' ').trim();
  }

  private ensureTypeIndex(type: string) {
    const t = (type || '').trim().toLowerCase();
    if (!t) return of(null);
    if (this.typeIndexCache.has(t)) return of(null);

    const url = `${this.apiBaseUrl}/type/${t}`;
    return this.http.get<any>(url).pipe(
      map((data) => {
        const set = new Set<number>();
        const arr: any[] = data?.pokemon ?? [];
        for (const entry of arr) {
          const purl = entry?.pokemon?.url as string | undefined;
          if (!purl) continue;
          const m = purl.match(/\/pokemon\/(\d+)\//);
          if (m) set.add(Number(m[1]));
        }
        this.typeIndexCache.set(t, set);
        return null;
      }),
      catchError(() => of(null))
    );
  }

  private fetchPokemonByNameWithFallback(name: string) {
    const url = `${this.apiBaseUrl}/pokemon/${encodeURIComponent(name)}`;
    return this.http.get<any>(url).pipe(
      catchError(() => {
        let alt = name;
        alt = alt.replace(/-megax$/, '-mega-x');
        alt = alt.replace(/-megay$/, '-mega-y');
        const url2 = `${this.apiBaseUrl}/pokemon/${encodeURIComponent(alt)}`;
        return this.http.get<any>(url2);
      })
    );
  }

  private detectFormLabel(textKey: string): string | undefined {
    const key = (textKey || '').toLowerCase();
    if (key.includes('alola')) return 'Alola';
    if (key.includes('galar')) return 'Galar';
    if (key.includes('hisui')) return 'Hisui';
    if (key.includes('paldea')) return 'Paldea';
    return 'Regional';
  }

  private officialArtworkUrl(id: number): string {
    return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
  }

  private prettyName(raw: string): string {
    const s = raw.startsWith('pokemon.') ? raw.substring('pokemon.'.length) : raw;
    return s.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  }

  private bulbapediaUrlFor(formName: string, kind: 'mega' | 'regional' | 'form'): string {
    const n = formName.trim().toLowerCase();
    const parts = n.split('-').filter(Boolean);
    const base = parts[0] ? (parts[0].charAt(0).toUpperCase() + parts[0].slice(1)) : 'Pok%C3%A9mon';
    const best = kind === 'mega' ? `${base}#Mega_Evolution` : base;
    return `https://bulbapedia.bulbagarden.net/wiki/${encodeURIComponent(best)}`;
  }
}
