import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Observable, forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { PokemonService } from '../../services/pokemon-service/pokemon.service';

type PokedexRow = {
  id: number;
  name: string;
  power: number;
  imgUrl: string;
  loading: boolean;
  heightM?: number;
  weightKg?: number;
  descriptionPt?: string;
  types?: string[];
  baseId?: number;
  formLabel?: string;
  megaForms?: string[];
  regionalForms?: string[];
};

@Component({
  selector: 'app-pokedex-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './pokedex-panel.component.html',
  styleUrl: './pokedex-panel.component.css'
})
export class PokedexPanelComponent implements OnInit {
  private apiBaseUrl = 'https://pokeapi.co/api/v2';

  isOpen = false;
  search = '';

  selectedType: string = '';
  readonly allTypes: string[] = ['normal','fire','water','electric','grass','ice','fighting','poison','ground','flying','psychic','bug','rock','ghost','dragon','dark','steel','fairy'];

  private typeIndexCache = new Map<string, Set<number>>();

  pageSize = 30;
  pageIndex = 0;

  allRows: PokedexRow[] = [];
  visibleRows: PokedexRow[] = [];

  private pokemonCache = new Map<number, { heightM: number; weightKg: number; types: string[] }>();
  private speciesCache = new Map<number, { descriptionPt: string; megaForms: string[]; regionalForms: string[] }>();

  constructor(private http: HttpClient, private pokemonService: PokemonService) {}

  ngOnInit(): void {
// Use the game's dataset (includes regional/special forms) for a better Pokédex.
const dex = this.pokemonService.getAllPokemon()
  .slice()
  .sort((a, b) => a.pokemonId - b.pokemonId);

this.allRows = dex.map((p) => {
  const id = p.pokemonId;
  const baseId = p.basePokemonId;
  const formLabel = baseId ? this.detectFormLabel(p, baseId) : undefined;

  return {
    id,
    name: this.prettyName(p.text),
    power: p.power ?? 1,
    imgUrl: this.officialArtworkUrl(id),
    loading: false,
    baseId,
    formLabel
  };
});

this.refreshVisibleRows();
  }

  toggle(): void {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.refreshVisibleRows();
    }
  }

  onSearchChange(): void {
    this.pageIndex = 0;
    this.refreshVisibleRows();
  }

  onTypeChange(): void {
    this.pageIndex = 0;
    if (!this.selectedType) {
      this.refreshVisibleRows();
      return;
    }
    this.ensureTypeIndex(this.selectedType).subscribe({
      next: () => this.refreshVisibleRows(),
      error: () => this.refreshVisibleRows()
    });
  }

  prevPage(): void {
    if (this.pageIndex > 0) {
      this.pageIndex -= 1;
      this.refreshVisibleRows();
    }
  }

  nextPage(): void {
    const maxPage = Math.max(0, Math.ceil(this.filteredRows().length / this.pageSize) - 1);
    if (this.pageIndex < maxPage) {
      this.pageIndex += 1;
      this.refreshVisibleRows();
    }
  }

  pageLabel(): string {
    const total = this.filteredRows().length;
    const from = total === 0 ? 0 : this.pageIndex * this.pageSize + 1;
    const to = Math.min(total, (this.pageIndex + 1) * this.pageSize);
    return `${from}–${to} / ${total}`;
  }

  private refreshVisibleRows(): void {
    const rows = this.filteredRows();
    const start = this.pageIndex * this.pageSize;
    this.visibleRows = rows.slice(start, start + this.pageSize);
    this.loadDetailsForVisibleRows();
  }

  filteredRows(): PokedexRow[] {
    const q = this.search.trim().toLowerCase();
    const type = (this.selectedType || '').trim().toLowerCase();
    const typeSet = type ? this.typeIndexCache.get(type) : undefined;

    let rows = this.allRows;
    if (type && typeSet) {
      rows = rows.filter((r) => typeSet.has(r.baseId ?? r.id) || typeSet.has(r.id));
    } else if (type && !typeSet) {
      // If the index isn't loaded yet, don't hide everything; show name search results.
    }

    if (!q) return rows;
    const idQuery = Number(q);
    if (!Number.isNaN(idQuery) && idQuery > 0) {
      return rows.filter((r) => r.id === idQuery);
    }
    return rows.filter((r) => r.name.toLowerCase().includes(q));
  }


  private loadDetailsForVisibleRows(): void {
    const toFetch = this.visibleRows.filter((r) => !this.pokemonCache.has(r.id) || !this.speciesCache.has(r.id));
    if (toFetch.length === 0) {
      this.hydrateFromCache(this.visibleRows);
      return;
    }

    toFetch.forEach((r) => (r.loading = true));

    const requests = toFetch.map((row) => {
      const pokemon$ = this.http.get<any>(`${this.apiBaseUrl}/pokemon/${row.id}`).pipe(
        map((p) => ({
          heightM: (p.height ?? 0) / 10,
          weightKg: (p.weight ?? 0) / 10,
          types: (p?.types ?? [])
            .sort((a: any, b: any) => (a?.slot ?? 0) - (b?.slot ?? 0))
            .map((t: any) => String(t?.type?.name ?? '').toLowerCase())
            .filter(Boolean)
        })),
        catchError(() => of({ heightM: undefined, weightKg: undefined, types: [] }))
      );

      const species$ = this.http.get<any>(`${this.apiBaseUrl}/pokemon-species/${row.id}`).pipe(
        map((s) => {
          const varieties = (s?.varieties ?? []).map((v: any) => String(v?.pokemon?.name ?? ''));
          const megaForms = varieties.filter((n: string) => n.includes('-mega'));
          const regionalForms = varieties.filter((n: string) => (
            n.includes('-alola') || n.includes('-galar') || n.includes('-hisui') || n.includes('-paldea')
          ));
          return {
            descriptionPt: this.pickPortugueseFlavorText(s?.flavor_text_entries ?? []),
            megaForms,
            regionalForms
          };
        }),
        catchError(() => of({ descriptionPt: '', megaForms: [], regionalForms: [] }))
      );

      return forkJoin([pokemon$, species$]).pipe(
        map(([pokemon, species]) => ({
          id: row.id,
          pokemon,
          species
        }))
      );
    });

    forkJoin(requests).subscribe((results) => {
      results.forEach((res) => {
        if (res.pokemon?.heightM !== undefined && res.pokemon?.weightKg !== undefined) {
          this.pokemonCache.set(res.id, { heightM: res.pokemon.heightM, weightKg: res.pokemon.weightKg, types: res.pokemon.types ?? [] });
        }
        if (res.species?.descriptionPt !== undefined) {
          this.speciesCache.set(res.id, { descriptionPt: res.species.descriptionPt, megaForms: res.species.megaForms ?? [], regionalForms: res.species.regionalForms ?? [] });
        }
      });

      this.hydrateFromCache(this.visibleRows);
      this.visibleRows.forEach((r) => (r.loading = false));
    });
  }

  private hydrateFromCache(rows: PokedexRow[]): void {
    rows.forEach((r) => {
      const p = this.pokemonCache.get(r.id);
      if (p) {
        r.heightM = p.heightM;
        r.weightKg = p.weightKg;
        r.types = p.types;
      }
      const s = this.speciesCache.get(r.id);
      if (s) {
        r.descriptionPt = s.descriptionPt;
        r.megaForms = s.megaForms;
        r.regionalForms = s.regionalForms;
      }
    });
  }

  private pickPortugueseFlavorText(entries: any[]): string {
    // Prefer PT if available, otherwise fall back to EN.
    const normalize = (t: string) => (t ?? '').replace(/\f/g, ' ').replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();

    const pt = entries
      .filter((e) => e?.language?.name === 'pt')
      // Prefer modern versions if present.
      .sort((a, b) => {
        const score = (v: any) => {
          const name = v?.version?.name ?? '';
          if (name === 'scarlet' || name === 'violet') return 3;
          if (name === 'sword' || name === 'shield') return 2;
          return 1;
        };
        return score(b) - score(a);
      });

    const chosen = pt[0]?.flavor_text;
    if (chosen) return normalize(chosen);

    const en = entries.find((e) => e?.language?.name === 'en')?.flavor_text;
    return normalize(en ?? '');
  }

  private officialArtworkUrl(id: number): string {
    return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
  }


private detectFormLabel(p: any, baseId: number): string | undefined {
  // Prefer slug-based detection (works for keys like pokemon.raichu-alola)
  const raw = (p?.text || p?.name || '').toString();
  const slug = raw.startsWith('pokemon.') ? raw.substring('pokemon.'.length) : raw;

  if (slug.includes('-alola')) return 'Alola';
  if (slug.includes('-galar')) return 'Galar';
  if (slug.includes('-hisui')) return 'Hisui';
  if (slug.includes('-paldea')) return 'Paldea';
  if (baseId && baseId !== p?.pokemonId) return 'Regional';
  return undefined;
}

private ensureTypeIndex(type: string): Observable<Set<number>> {
  if (!type) return of(new Set<number>());
  const cached = this.typeIndexCache.get(type);
  if (cached) return of(cached);

  return this.http.get<any>(`${this.apiBaseUrl}/type/${type}`).pipe(
    map((res) => {
      const ids = new Set<number>();
      for (const entry of res?.pokemon || []) {
        const url: string | undefined = entry?.pokemon?.url;
        if (!url) continue;
        const m = url.match(/\/pokemon\/(\d+)\/?$/);
        if (m) ids.add(parseInt(m[1], 10));
      }
      this.typeIndexCache.set(type, ids);
      return ids;
    }),
    catchError(() => {
      const empty = new Set<number>();
      this.typeIndexCache.set(type, empty);
      return of(empty);
    })
  );
}

  private prettyName(text: string): string {
    // Convert keys like "pokemon.tapu-koko" into a readable name
    if (!text) return '';
    if (!text.startsWith('pokemon.')) return text;
    const raw = text.replace(/^pokemon\./, '');
    return raw
      .split('-')
      .map((w) => (w.length ? w[0].toUpperCase() + w.slice(1) : w))
      .join(' ');
  }
}