import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { PokedexUiService } from '../../services/pokedex-ui.service';

@Component({
  selector: 'app-pokedex-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pokedex-panel.component.html',
  styleUrl: './pokedex-panel.component.css'
})
export class PokedexPanelComponent {
  constructor(private pokedexUi: PokedexUiService) {}

  openPokedex(): void {
    this.pokedexUi.open();
  }
}
