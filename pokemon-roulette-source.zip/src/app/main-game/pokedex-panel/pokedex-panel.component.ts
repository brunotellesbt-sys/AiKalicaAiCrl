import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { PokemonService } from '../../services/pokemon-service/pokemon.service';
import { NgbModal, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';

type PokedexRow = {
  id: number;
  name: string;
  power: number;
  imgUrl: string;
  loading: boolean;
  heightM?: number;
  weightKg?: number;
  descriptionPt?: string;

  // New: helps searching & understanding
  types?: string[];
  baseId?: number;
  formLabel?: string;
  megaForms?: string[];
  regionalForms?: string[];
};

type FormInfo = {
  title: string;
  kind: 'mega' | 'regional' | 'form';
  spriteUrl?: string;
  types: string[];
  descriptionPt?: string;
  bulbapediaUrl?: string;
  pokeapiUrl?: string;
};

@Component({
  selector: 'app-pokedex-panel',
  standalone: true,
  imports: [CommonModule, FormsModule, NgbModalModule],
  templateUrl: './pokedex-panel.component.html',
  styleUrl: './pokedex-panel.component.css'
})
export class PokedexPanelComponent implements OnInit {
  private apiBaseUrl = 'https://pokeapi.co/api/v2';

  isOpen = false;
  search = '';

  // Type filter
  selectedType = '';
  readonly allTypes: string[] = [
    'normal','fire','water','electric','grass','ice','fighting','poison','ground','flying',
    'psychic','bug','rock','ghost','dragon','dark','steel','fairy'
  ];
  private typeIndexCache = new Map<string, Set<number>>();

  pageSize = 30;
  pageIndex = 0;

  allRows: PokedexRow[] = [];
  visibleRows: PokedexRow[] = [];

  private pokemonCache = new Map<number, { heightM: number; weightKg: number; types: string[] }>();
  private speciesCache = new Map<number, { descriptionPt: string; megaForms: string[]; regionalForms: string[] }>();

  @ViewChild('formInfoModal', { static: true }) formInfoModal!: TemplateRef<any>;
  formInfo: FormInfo | null = null;

  @ViewChild('megaListModal', { static: true }) megaListModal!: TemplateRef<any>;
  megaList: string[] = [];

  constructor(
    private http: HttpClient,
    private pokemonService: PokemonService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    // Use the game's dataset (includes regional/special forms) for a better Pokédex.
    const dex = this.pokemonService.getAllPokemon()
      .slice()
      .sort((a, b) => a.pokemonId - b.pokemonId);

    this.allRows = dex.map((p) => {
      const id = p.pokemonId;
      const baseId = p.basePokemonId;
      const formLabel = baseId ? this.detectFormLabel(p.text) : undefined;

      return {
        id,
        name: this.prettyName(p.text),
        power: (p as any).power ?? 1,
        imgUrl: this.officialArtworkUrl(id),
        loading: false,
        baseId,
        formLabel
      };
    });

    this.refreshVisibleRows();
  }

  toggle(): void {
    this.isOpen = !this.isOpen;
    if (this.isOpen) this.refreshVisibleRows();
  }

  onSearchChange(): void {
    this.pageIndex = 0;
    this.refreshVisibleRows();
  }

  onTypeChange(): void {
    this.pageIndex = 0;
    if (!this.selectedType) {
      this.refreshVisibleRows();
      return;
    }
    this.ensureTypeIndex(this.selectedType).subscribe({
      next: () => this.refreshVisibleRows(),
      error: () => this.refreshVisibleRows()
    });
  }

  prevPage(): void {
    if (this.pageIndex > 0) {
      this.pageIndex -= 1;
      this.refreshVisibleRows();
    }
  }

  nextPage(): void {
    const maxPage = Math.max(0, Math.ceil(this.filteredRows().length / this.pageSize) - 1);
    if (this.pageIndex < maxPage) {
      this.pageIndex += 1;
      this.refreshVisibleRows();
    }
  }

  pageLabel(): string {
    const total = this.filteredRows().length;
    const from = total === 0 ? 0 : this.pageIndex * this.pageSize + 1;
    const to = Math.min(total, (this.pageIndex + 1) * this.pageSize);
    return `${from}–${to} / ${total}`;
  }

  filteredRows(): PokedexRow[] {
    const q = this.search.trim().toLowerCase();
    const type = (this.selectedType || '').trim().toLowerCase();
    const typeSet = type ? this.typeIndexCache.get(type) : undefined;

    let rows = this.allRows;
    if (type && typeSet) {
      // Prefer base species id if it exists, but also allow filtering the form itself.
      rows = rows.filter((r) => typeSet.has(r.baseId ?? r.id) || typeSet.has(r.id));
    }

    if (!q) return rows;

    const idQuery = Number(q);
    if (!Number.isNaN(idQuery) && idQuery > 0) {
      return rows.filter((r) => r.id === idQuery || (r.baseId === idQuery));
    }

    return rows.filter((r) => r.name.toLowerCase().includes(q));
  }

  private refreshVisibleRows(): void {
    const rows = this.filteredRows();
    const start = this.pageIndex * this.pageSize;
    this.visibleRows = rows.slice(start, start + this.pageSize);
    this.loadDetailsForVisibleRows();
  }

  private loadDetailsForVisibleRows(): void {
    const toLoad = this.visibleRows.filter((r) => !this.pokemonCache.has(r.id) || !this.speciesCache.has(r.baseId ?? r.id));
    if (toLoad.length === 0) return;

    toLoad.forEach((row) => (row.loading = true));

    const pokemonRequests = toLoad.map((row) =>
      this.fetchPokemon(row.id).pipe(
        catchError(() => of({ heightM: 0, weightKg: 0, types: [] })),
        map((p) => ({ id: row.id, ...p }))
      )
    );

    const speciesRequests = toLoad.map((row) => {
      const sid = row.baseId ?? row.id;
      return this.fetchSpecies(sid).pipe(
        catchError(() => of({ descriptionPt: '', megaForms: [], regionalForms: [] })),
        map((s) => ({ sid, ...s }))
      );
    });

    forkJoin([forkJoin(pokemonRequests), forkJoin(speciesRequests)]).subscribe({
      next: ([pokemons, species]) => {
        for (const p of pokemons) {
          this.pokemonCache.set(p.id, { heightM: p.heightM, weightKg: p.weightKg, types: p.types });
        }
        for (const s of species) {
          this.speciesCache.set(s.sid, { descriptionPt: s.descriptionPt, megaForms: s.megaForms, regionalForms: s.regionalForms });
        }

        for (const row of this.visibleRows) {
          const p = this.pokemonCache.get(row.id);
          const s = this.speciesCache.get(row.baseId ?? row.id);
          if (p) {
            row.heightM = p.heightM;
            row.weightKg = p.weightKg;
            row.types = p.types;
          }
          if (s) {
            row.descriptionPt = s.descriptionPt;
            row.megaForms = s.megaForms;
            row.regionalForms = s.regionalForms;
          }
          row.loading = false;
        }
      },
      error: () => {
        for (const row of this.visibleRows) row.loading = false;
      }
    });
  }

  

onMegaCountClick(row: PokedexRow): void {
  const list = row.megaForms ?? [];
  if (list.length === 0) return;
  if (list.length === 1) {
    this.openFormDetails(list[0], 'mega');
    return;
  }
  this.megaList = list.slice();
  this.modalService.open(this.megaListModal, { centered: true, size: 'sm' });
}

prettyFormName(formSlug: string): string {
  // e.g. "charizard-mega-x" -> "Mega Charizard X"
  const s = (formSlug || '').toLowerCase();
  if (s.includes('mega')) {
    const parts = s.split('-');
    // handle ...-mega-x / ...-mega-y / ...-mega
    const base = parts[0];
    const tail = parts.slice(1);
    let suffix = '';
    if (tail.includes('x')) suffix = ' X';
    if (tail.includes('y')) suffix = ' Y';
    return `Mega ${this.titleize(base)}${suffix}`.trim();
  }
  // regional
  const regions = ['alola','galar','hisui','paldea'];
  for (const r of regions) {
    if (s.endsWith('-' + r)) {
      return `${this.titleize(s.replace('-' + r, ''))} (${this.titleize(r)})`;
    }
  }
  return this.titleize(s.replace(/-/g, ' '));
}

private titleize(x: string): string {
  return (x || '').split(' ').map(w => w ? (w[0].toUpperCase() + w.slice(1)) : w).join(' ');
}

openFormDetails(formName: string, kind: 'mega' | 'regional' | 'form' = 'form'): void {
    // Fetch form details from internet (PokeAPI) and show a modal.
    const slug = formName.trim().toLowerCase();

    this.fetchPokemonByNameWithFallback(slug).pipe(
      switchMap((poke) => {
        const types = (poke?.types || []).map((t: any) => t?.type?.name).filter(Boolean);
        const spriteUrl =
          poke?.sprites?.other?.['official-artwork']?.front_default ||
          poke?.sprites?.front_default ||
          '';

        const speciesUrl = poke?.species?.url as string | undefined;
        if (!speciesUrl) {
          return of({
            title: this.prettyName(formName),
            kind,
            spriteUrl,
            types,
            descriptionPt: '',
            bulbapediaUrl: this.bulbapediaUrlFor(formName, kind),
            pokeapiUrl: `${this.apiBaseUrl}/pokemon/${slug}`
          } as FormInfo);
        }

        return this.http.get<any>(speciesUrl).pipe(
          catchError(() => of(null)),
          map((sp) => {
            const descriptionPt = this.pickFlavorText(sp);
            const title = this.prettyName(formName);
            return {
              title,
              kind,
              spriteUrl,
              types,
              descriptionPt,
              bulbapediaUrl: this.bulbapediaUrlFor(formName, kind),
              pokeapiUrl: `${this.apiBaseUrl}/pokemon/${slug}`
            } as FormInfo;
          })
        );
      }),
      catchError(() => of(null))
    ).subscribe((info) => {
      if (!info) return;
      this.formInfo = info;
      this.modalService.open(this.formInfoModal, { centered: true, size: 'lg' });
    });
  }

  private fetchPokemon(id: number) {
    const url = `${this.apiBaseUrl}/pokemon/${id}`;
    return this.http.get<any>(url).pipe(
      map((data) => {
        const heightM = (data.height ?? 0) / 10;
        const weightKg = (data.weight ?? 0) / 10;
        const types = (data.types ?? []).map((t: any) => t?.type?.name).filter(Boolean);
        return { heightM, weightKg, types };
      })
    );
  }

  private fetchSpecies(speciesId: number) {
    const url = `${this.apiBaseUrl}/pokemon-species/${speciesId}`;
    return this.http.get<any>(url).pipe(
      map((data) => {
        const descriptionPt = this.pickFlavorText(data);

        // Collect varieties (internet data) so user can click and read details.
        const varieties: string[] = (data?.varieties ?? [])
          .map((v: any) => v?.pokemon?.name)
          .filter((n: any) => typeof n === 'string');

        const megaForms = varieties.filter((n) => n.includes('-mega') || n.includes('-megax') || n.includes('-megay') || n.includes('mega-x') || n.includes('mega-y'));
        const regionalForms = varieties.filter((n) => /-(alola|galar|hisui|paldea)/.test(n));

        return { descriptionPt, megaForms, regionalForms };
      })
    );
  }

  private pickFlavorText(speciesData: any): string {
    const entries: any[] = speciesData?.flavor_text_entries ?? [];
    // Prefer Portuguese (pt / pt-br), then English.
    const pt = entries.find((e) => e?.language?.name === 'pt' || e?.language?.name === 'pt-br');
    const en = entries.find((e) => e?.language?.name === 'en');
    const txt = (pt?.flavor_text || en?.flavor_text || '') as string;
    return txt.replace(//g, ' ').replace(/\s+/g, ' ').trim();
  }

  private ensureTypeIndex(type: string) {
    const t = (type || '').trim().toLowerCase();
    if (!t) return of(null);
    if (this.typeIndexCache.has(t)) return of(null);

    const url = `${this.apiBaseUrl}/type/${t}`;
    return this.http.get<any>(url).pipe(
      map((data) => {
        const set = new Set<number>();
        const arr: any[] = data?.pokemon ?? [];
        for (const entry of arr) {
          const purl = entry?.pokemon?.url as string | undefined;
          if (!purl) continue;
          const m = purl.match(/\/pokemon\/(\d+)\//);
          if (m) set.add(Number(m[1]));
        }
        this.typeIndexCache.set(t, set);
        return null;
      }),
      catchError(() => of(null))
    );
  }

  private fetchPokemonByNameWithFallback(name: string) {
    const url = `${this.apiBaseUrl}/pokemon/${encodeURIComponent(name)}`;
    return this.http.get<any>(url).pipe(
      catchError(() => {
        // Some mega naming differs. Try a few simple fallbacks.
        let alt = name;
        alt = alt.replace(/-mega-x$/, '-mega-x');
        alt = alt.replace(/-mega-y$/, '-mega-y');
        alt = alt.replace(/-megax$/, '-mega-x');
        alt = alt.replace(/-megay$/, '-mega-y');
        // retry
        const url2 = `${this.apiBaseUrl}/pokemon/${encodeURIComponent(alt)}`;
        return this.http.get<any>(url2);
      })
    );
  }

  private detectFormLabel(textKey: string): string | undefined {
    const key = (textKey || '').toLowerCase();
    if (key.includes('alola')) return 'Alola';
    if (key.includes('galar')) return 'Galar';
    if (key.includes('hisui')) return 'Hisui';
    if (key.includes('paldea')) return 'Paldea';
    return 'Regional';
  }

  private officialArtworkUrl(id: number): string {
    return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
  }

  private prettyName(raw: string): string {
    // raw can be a translation key (pokemon.xxx) or already a name
    const s = raw.startsWith('pokemon.') ? raw.substring('pokemon.'.length) : raw;
    return s.replace(/-/g, ' ').replace(/\w/g, (c) => c.toUpperCase());
  }

  private bulbapediaUrlFor(formName: string, kind: 'mega' | 'regional' | 'form'): string {
    // Build a reasonable Bulbapedia page URL (internet) for user to read full descriptions.
    // Example: "charizard-mega-x" -> "Charizard_Mega_X"
    const n = formName.trim().toLowerCase();
    const parts = n.split('-').filter(Boolean);

    let page = parts.map((p) => p.toUpperCase() === 'X' || p.toUpperCase() === 'Y' ? p.toUpperCase() : (p.charAt(0).toUpperCase() + p.slice(1))).join('_');

    // Normalize common patterns
    page = page.replace('_Mega_X', '_Mega_X').replace('_Mega_Y', '_Mega_Y');
    // Bulbapedia pages commonly are "Pokémonname" (mega info is inside), but this is still useful.
    const base = parts[0] ? (parts[0].charAt(0).toUpperCase() + parts[0].slice(1)) : 'Pok%C3%A9mon';
    const best = kind === 'mega' ? `${base}#Mega_Evolution` : base;
    return `https://bulbapedia.bulbagarden.net/wiki/${encodeURIComponent(best)}`;
  }
}
