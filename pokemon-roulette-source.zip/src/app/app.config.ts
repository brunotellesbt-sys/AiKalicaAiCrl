import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withHashLocation } from '@angular/router';
import { provideIcons } from '@ng-icons/core';
import { routes } from './app.routes';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import {
  bootstrapArrowRepeat,
  bootstrapCheck,
  bootstrapClock,
  bootstrapController,
  bootstrapCupHotFill,
  bootstrapGear,
  bootstrapMap,
  bootstrapPcDisplayHorizontal,
  bootstrapPeopleFill,
  bootstrapShare,
} from '@ng-icons/bootstrap-icons';

import {
  MissingTranslationHandler,
  TranslateLoader,
  TranslateModule,
} from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { PrettyMissingTranslationHandler } from './shared/pretty-missing-translation.handler';

// IMPORTANT (GitHub Pages compatibility):
// - Hash-based routing prevents 404s on deep links on static hosting.
// - Translation paths must be *relative* (no leading slash) so it works under /<repo>/.

export function httpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, 'i18n/', '.json');
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes, withHashLocation()),
    provideIcons({
      bootstrapArrowRepeat,
      bootstrapCheck,
      bootstrapClock,
      bootstrapController,
      bootstrapCupHotFill,
      bootstrapGear,
      bootstrapPcDisplayHorizontal,
      bootstrapPeopleFill,
      bootstrapShare,
      bootstrapMap,
    }),
    provideHttpClient(),
    provideZoneChangeDetection({ eventCoalescing: true }),

    importProvidersFrom(
      TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: httpLoaderFactory,
          deps: [HttpClient],
        },
        missingTranslationHandler: {
          provide: MissingTranslationHandler,
          useClass: PrettyMissingTranslationHandler,
        },
        // Actual language selection happens in AppComponent via translate.use('en').
        useDefaultLang: true,
      })
    ),
  ],
};
