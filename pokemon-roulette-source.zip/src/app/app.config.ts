import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withHashLocation } from '@angular/router';
import { provideIcons } from '@ng-icons/core';
import { routes } from './app.routes';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import {
  bootstrapArrowRepeat,
  bootstrapCheck,
  bootstrapClock,
  bootstrapController,
  bootstrapCupHotFill,
  bootstrapGear,
  bootstrapMap,
  bootstrapPcDisplayHorizontal,
  bootstrapPeopleFill,
  bootstrapShare
} from '@ng-icons/bootstrap-icons';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateLoader, TranslateModule, MissingTranslationHandler, MissingTranslationHandlerParams } from '@ngx-translate/core';

class FallbackMissingTranslationHandler implements MissingTranslationHandler {
  private titleize(slug: string): string {
    const specials: Record<string, string> = {
      'type-null': 'Type: Null',
      'tapu-koko': 'Tapu Koko',
      'tapu-lele': 'Tapu Lele',
      'tapu-bulu': 'Tapu Bulu',
      'tapu-fini': 'Tapu Fini',
      'ho-oh': 'Ho-Oh',
    };
    if (specials[slug]) return specials[slug];

    let s = slug.replace(/-/g, ' ');
    s = s.replace(/\b\w/g, (c) => c.toUpperCase());
    return s;
  }

  handle(params: MissingTranslationHandlerParams) {
    const key = params.key || '';
    if (key.startsWith('pokemon.')) {
      const slug = key.substring('pokemon.'.length);
      return this.titleize(slug);
    }
    return key;
  }
}


// IMPORTANT (GitHub Pages compatibility):
// Use a *relative* path (no leading slash) so translations load correctly
// when the app is hosted under a sub-path, e.g. https://user.github.io/<repo>/
//
// The i18n JSON files live in /public/i18n and are copied to the build output root.
const httpLoaderFactory: (http: HttpClient) => TranslateHttpLoader = (http: HttpClient) =>
  new TranslateHttpLoader(http, 'i18n/', '.json');



export const appConfig: ApplicationConfig = {
  providers: [
    // IMPORTANT (GitHub Pages compatibility):
    // Use hash-based routing so deep links don't 404 on static hosting.
    provideRouter(routes, withHashLocation()),
    provideIcons(
      { bootstrapArrowRepeat,
        bootstrapCheck,
        bootstrapClock,
        bootstrapController,
        bootstrapCupHotFill,
        bootstrapGear,
        bootstrapPcDisplayHorizontal,
        bootstrapPeopleFill,
        bootstrapShare,
        bootstrapMap
       }),
    provideHttpClient(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    importProvidersFrom([TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient]
      },
      missingTranslationHandler: { provide: MissingTranslationHandler, useClass: FallbackMissingTranslationHandler },
      defaultLanguage: 'en'
    })])
  ]
};