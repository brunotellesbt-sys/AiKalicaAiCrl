import { Injectable } from '@angular/core';
import { SettingsService } from '../settings-service/settings.service';

/**
 * Plays Pokémon cries from Pokémon Showdown's public audio directory.
 *
 * IMPORTANT: No synthetic/generic fallback here. If a cry URL fails, we simply skip playback.
 */
@Injectable({
  providedIn: 'root',
})
export class CryService {
  private readonly showdownCryBase = 'https://play.pokemonshowdown.com/audio/cries';
  private unlocked = false;

  constructor(private settings: SettingsService) {}

  /**
   * Call on the first user interaction (pointerdown/click) to unlock audio playback
   * on mobile browsers. Safe to call many times.
   */
  async unlockAudio(): Promise<void> {
    if (this.unlocked) return;

    // Respect sound settings.
    if (!this.settings.getSoundEffects()) return;

    try {
      // A tiny silent WAV data URI (very small) to satisfy iOS/Android "user gesture" audio unlock.
      const silentWav =
        'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAgD4AAIA+AAABAAgAZGF0YQAAAAA=';
      const a = new Audio(silentWav);
      a.volume = 0;
      // Some browsers require a play() call that resolves.
      await a.play();
      a.pause();
      this.unlocked = true;
    } catch {
      // Even if unlock fails, we keep trying later.
    }
  }

  /**
   * Plays the Mega form cry at the end of the 3s Mega Evolution blink.
   * If the Mega form doesn't exist on Showdown (fan-made Mega), we play the base Pokémon cry.
   */
  async playMegaCryOrSynthetic(_seed: string, megaApiName: string): Promise<void> {
    if (!this.settings.getSoundEffects()) return;

    const mega = this.toShowdownCryName(megaApiName);
    const base = this.toShowdownCryName(this.deriveBaseSpeciesName(megaApiName));

    // Try Mega first (official megas exist on Showdown), then base.
    const candidates: string[] = [];
    if (mega) {
      candidates.push(`${this.showdownCryBase}/${mega}.mp3`);
      candidates.push(`${this.showdownCryBase}/${mega}.ogg`);
    }
    if (base && base !== mega) {
      candidates.push(`${this.showdownCryBase}/${base}.mp3`);
      candidates.push(`${this.showdownCryBase}/${base}.ogg`);
    }

    for (const url of candidates) {
      const ok = await this.tryPlayAudioUrl(url);
      if (ok) return;
    }

    // No synthetic fallback by request.
  }

  // ------------------------------------------------------------
  // Internals
  // ------------------------------------------------------------

  private async tryPlayAudioUrl(url: string): Promise<boolean> {
    return new Promise<boolean>((resolve) => {
      const audio = new Audio();
      audio.preload = 'auto';
      audio.src = url;

      let done = false;
      const finish = (ok: boolean) => {
        if (done) return;
        done = true;
        try {
          audio.pause();
        } catch {
          // ignore
        }
        audio.onerror = null;
        audio.onended = null;
        audio.oncanplaythrough = null;
        resolve(ok);
      };

      audio.onended = () => finish(true);
      audio.onerror = () => finish(false);

      // If it can play, attempt playback.
      audio.oncanplaythrough = () => {
        audio
          .play()
          .then(() => {
            // ok
          })
          .catch(() => finish(false));
      };

      // Safety timeout.
      setTimeout(() => finish(false), 9000);
    });
  }

  /**
   * Converts PokeAPI-style names to Showdown cry filenames.
   *
   * Examples:
   * - "charizard-mega-x" -> "charizard-megax"
   * - "porygon-z" -> "porygonz"
   * - "mr-mime" -> "mrmime"
   * - "mewtwo-mega-y" -> "mewtwo-megay"
   * - "rayquaza-mega" -> "rayquaza-mega"
   */
  private toShowdownCryName(name: string): string {
    const raw = (name || '').toLowerCase().trim();
    if (!raw) return '';

    const tokens = raw.split('-').filter(Boolean);

    // Handle weird custom naming like "mega-meganium" (prefix mega).
    if (tokens[0] === 'mega' && tokens.length >= 2) {
      const baseId = this.toID(tokens.slice(1).join('-'));
      return `${baseId}-mega`;
    }

    // Detect form marker so we keep a single hyphen between base and form id.
    const formIndex = this.findFormIndex(tokens);
    if (formIndex <= 0) {
      // Base species: remove punctuation entirely.
      return this.toID(raw);
    }

    const base = this.toID(tokens.slice(0, formIndex).join('-'));
    const formTokens = tokens.slice(formIndex);

    // Mega X/Y: "mega-x" -> "megax", "mega-y" -> "megay".
    if (formTokens[0] === 'mega' && (formTokens[1] === 'x' || formTokens[1] === 'y')) {
      return `${base}-mega${formTokens[1]}`;
    }

    const form = this.toID(formTokens.join('-'));
    return form ? `${base}-${form}` : base;
  }

  private toID(s: string): string {
    return (s || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  }

  private findFormIndex(tokens: string[]): number {
    if (!tokens || tokens.length < 2) return -1;

    const KNOWN_FORM_TOKENS = new Set([
      'mega',
      'gmax',
      'alola',
      'galar',
      'hisui',
      'paldea',
      'primal',
      'origin',
      'complete',
      'crowned',
      'dusk',
      'dawn',
      'ultra',
      'therian',
      'incarnate',
      'attack',
      'defense',
      'speed',
      'sunny',
      'rainy',
      'snowy',
      'hangry',
      'busted',
      'starter',
      'ash',
      'school',
      'midnight',
      'dawnwings',
      'duskmane',
      'rapidstrike',
      'singlestrike',
      'blaze',
      'aqua',
      'white',
      'black',
      'small',
      'large',
      'super',
      'totem',
    ]);

    // If the last token is a number, treat it as a form (zygarde-10, etc.).
    if (/^\d+$/.test(tokens[tokens.length - 1])) return tokens.length - 1;

    for (let i = 1; i < tokens.length; i++) {
      if (KNOWN_FORM_TOKENS.has(tokens[i])) return i;
      // Mega X/Y pattern: ...-mega-x or ...-mega-y
      if (tokens[i] === 'mega') return i;
    }

    return -1;
  }

  /**
   * Derives a *base species* name from a Mega API name.
   *
   * Works for:
   * - "charizard-mega-x" -> "charizard"
   * - "rayquaza-mega" -> "rayquaza"
   * - "mega-meganium" -> "meganium" (custom)
   */
  private deriveBaseSpeciesName(megaApiName: string): string {
    const raw = (megaApiName || '').toLowerCase().trim();
    if (!raw) return '';

    if (raw.startsWith('mega-')) return raw.substring(5);

    const idx = raw.indexOf('-mega');
    if (idx > 0) return raw.substring(0, idx);

    // If it's already a base name, return as-is.
    return raw;
  }
}
