import { Injectable } from '@angular/core';
import { PokemonItem } from '../../interfaces/pokemon-item';
import { evolutionChain } from './evolution-chain';
import { PokemonService } from '../pokemon-service/pokemon.service';

@Injectable({
  providedIn: 'root'
})
export class EvolutionService {

  constructor(private pokemonService: PokemonService) {
    this.nationalDexPokemon = this.pokemonService.getAllPokemon();
  }

  evolutionChain = evolutionChain;
  nationalDexPokemon: PokemonItem[];

  private isHisuianFormId(id: number): boolean {
    return id >= 10229 && id <= 10247;
  }

  canEvolve(pokemon: PokemonItem): boolean {
    return this.getEvolutions(pokemon).length > 0;
  }

  getEvolutions(pokemon: PokemonItem): PokemonItem[] {
    const chain = this.evolutionChain[pokemon.pokemonId];
    if (!chain || chain.length === 0) return [];

    const evolutions: PokemonItem[] = [];
    for (const evolutionId of chain) {
      const evolution = this.pokemonService.getPokemonById(evolutionId);
      if (evolution) evolutions.push(evolution);
    }

    // Exception: Pikachu normal can evolve into Alolan Raichu
    if (!pokemon.basePokemonId && pokemon.pokemonId === 25) {
      return evolutions;
    }

    // Regional base forms follow their own chain
    if (pokemon.basePokemonId) {
      return evolutions;
    }

    // Non-regional base: block regional-form evolutions, except Hisui forms
    return evolutions.filter(evo => !evo.basePokemonId || this.isHisuianFormId(evo.pokemonId));
  }
}
