import { Badge } from "../../interfaces/badge";

// NOTE:
// Badge sprite indices in third-party sprite sheets can change over time.
// To keep badges stable (and correct across regions), we reference the
// Bulbagarden Archives via Special:FilePath using each badge's official file name.
const BULBA = 'https://archives.bulbagarden.net/wiki/Special:FilePath/';

export const badgesByGeneration: Record<number, (Badge | Badge[])[]> = {
  1: [
    { name: 'badges.boulder', sprite: `${BULBA}Boulder_Badge.png` },
    { name: 'badges.cascade', sprite: `${BULBA}Cascade_Badge.png` },
    { name: 'badges.thunder', sprite: `${BULBA}Thunder_Badge.png` },
    { name: 'badges.rainbow', sprite: `${BULBA}Rainbow_Badge.png` },
    { name: 'badges.soul', sprite: `${BULBA}Soul_Badge.png` },
    { name: 'badges.marsh', sprite: `${BULBA}Marsh_Badge.png` },
    { name: 'badges.volcano', sprite: `${BULBA}Volcano_Badge.png` },
    { name: 'badges.earth', sprite: `${BULBA}Earth_Badge.png` },
  ],
  2: [
    { name: 'badges.zephyr', sprite: `${BULBA}Zephyr_Badge.png` },
    { name: 'badges.hive', sprite: `${BULBA}Hive_Badge.png` },
    { name: 'badges.plain', sprite: `${BULBA}Plain_Badge.png` },
    { name: 'badges.fog', sprite: `${BULBA}Fog_Badge.png` },
    { name: 'badges.storm', sprite: `${BULBA}Storm_Badge.png` },
    { name: 'badges.mineral', sprite: `${BULBA}Mineral_Badge.png` },
    { name: 'badges.glacier', sprite: `${BULBA}Glacier_Badge.png` },
    { name: 'badges.rising', sprite: `${BULBA}Rising_Badge.png` },
  ],
  3: [
    { name: 'badges.stone', sprite: `${BULBA}Stone_Badge.png` },
    { name: 'badges.knuckle', sprite: `${BULBA}Knuckle_Badge.png` },
    { name: 'badges.dynamo', sprite: `${BULBA}Dynamo_Badge.png` },
    { name: 'badges.heat', sprite: `${BULBA}Heat_Badge.png` },
    { name: 'badges.balance', sprite: `${BULBA}Balance_Badge.png` },
    { name: 'badges.feather', sprite: `${BULBA}Feather_Badge.png` },
    { name: 'badges.mind', sprite: `${BULBA}Mind_Badge.png` },
    { name: 'badges.rain', sprite: `${BULBA}Rain_Badge.png` },
  ],
  4: [
    { name: 'badges.coal', sprite: `${BULBA}Coal_Badge.png` },
    { name: 'badges.forest', sprite: `${BULBA}Forest_Badge.png` },
    { name: 'badges.cobble', sprite: `${BULBA}Cobble_Badge.png` },
    { name: 'badges.fen', sprite: `${BULBA}Fen_Badge.png` },
    { name: 'badges.relic', sprite: `${BULBA}Relic_Badge.png` },
    { name: 'badges.mine', sprite: `${BULBA}Mine_Badge.png` },
    { name: 'badges.icicle', sprite: `${BULBA}Icicle_Badge.png` },
    { name: 'badges.beacon', sprite: `${BULBA}Beacon_Badge.png` },
  ],
  5: [
    { name: 'badges.trio', sprite: `${BULBA}Trio_Badge.png` },
    { name: 'badges.basic', sprite: `${BULBA}Basic_Badge.png` },
    { name: 'badges.insect', sprite: `${BULBA}Insect_Badge.png` },
    { name: 'badges.bolt', sprite: `${BULBA}Bolt_Badge.png` },
    { name: 'badges.quake', sprite: `${BULBA}Quake_Badge.png` },
    { name: 'badges.jet', sprite: `${BULBA}Jet_Badge.png` },
    { name: 'badges.freeze', sprite: `${BULBA}Freeze_Badge.png` },
    { name: 'badges.legend', sprite: `${BULBA}Legend_Badge.png` },
  ],
  6: [
    { name: 'badges.bug', sprite: `${BULBA}Bug_Badge.png` },
    { name: 'badges.cliff', sprite: `${BULBA}Cliff_Badge.png` },
    { name: 'badges.rumble', sprite: `${BULBA}Rumble_Badge.png` },
    { name: 'badges.plant', sprite: `${BULBA}Plant_Badge.png` },
    { name: 'badges.voltage', sprite: `${BULBA}Voltage_Badge.png` },
    { name: 'badges.fairy', sprite: `${BULBA}Fairy_Badge.png` },
    { name: 'badges.psychic', sprite: `${BULBA}Psychic_Badge.png` },
    { name: 'badges.iceberg', sprite: `${BULBA}Iceberg_Badge.png` },
  ],
  7: [
    { name: 'badges.normalium_z', sprite: 'https://archives.bulbagarden.net/media/upload/f/f0/Dream_Normalium_Z_Sprite.png' },
    { name: 'badges.fightinium_z', sprite: 'https://archives.bulbagarden.net/media/upload/0/08/Dream_Fightinium_Z_Sprite.png' },
    [
      { name: 'badges.waterium_z', sprite: 'https://archives.bulbagarden.net/media/upload/e/ee/Dream_Waterium_Z_Sprite.png' },
      { name: 'badges.firium_z', sprite: 'https://archives.bulbagarden.net/media/upload/f/f1/Dream_Firium_Z_Sprite.png' },
      { name: 'badges.grassium_z', sprite: 'https://archives.bulbagarden.net/media/upload/d/d7/Dream_Grassium_Z_Sprite.png' }
    ],
    { name: 'badges.rockium_z', sprite: 'https://archives.bulbagarden.net/media/upload/9/9b/Dream_Rockium_Z_Sprite.png' },
    [
      { name: 'badges.electrium_z', sprite: 'https://archives.bulbagarden.net/media/upload/e/e4/Dream_Electrium_Z_Sprite.png' },
      { name: 'badges.ghostium_z', sprite: 'https://archives.bulbagarden.net/media/upload/d/d1/Dream_Ghostium_Z_Sprite.png' },
    ],
    { name: 'badges.darkinium_z', sprite: 'https://archives.bulbagarden.net/media/upload/1/1e/Dream_Darkinium_Z_Sprite.png' },
    { name: 'badges.fairium_z', sprite: 'https://archives.bulbagarden.net/media/upload/b/b7/Dream_Fairium_Z_Sprite.png' },
    { name: 'badges.groundium_z', sprite: 'https://archives.bulbagarden.net/media/upload/7/7e/Dream_Groundium_Z_Sprite.png' },
  ],
  8: [
    { name: 'badges.grass', sprite: `${BULBA}Grass_Badge.png` },
    { name: 'badges.water', sprite: `${BULBA}Water_Badge.png` },
    { name: 'badges.fire', sprite: `${BULBA}Fire_Badge.png` },
    [
      { name: 'badges.fighting', sprite: `${BULBA}Fighting_Badge.png` },
      { name: 'badges.ghost', sprite: `${BULBA}Ghost_Badge.png` },
    ],
    { name: 'badges.fairy_galar', sprite: `${BULBA}GalarFairy_Badge.png` },
    [
      { name: 'badges.rock', sprite: `${BULBA}Rock_Badge.png` },
      { name: 'badges.ice', sprite: `${BULBA}Ice_Badge.png` },
    ],
    { name: 'badges.dark', sprite: `${BULBA}Dark_Badge.png` },
    { name: 'badges.dragon', sprite: `${BULBA}Dragon_Badge.png` },
  ],

  9: [
    // Paldea Gym Badges (Victory Road)
    { name: 'Bug Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Bug.png` },
    { name: 'Grass Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Grass.png` },
    { name: 'Electric Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Electric.png` },
    { name: 'Water Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Water.png` },
    { name: 'Normal Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Normal.png` },
    { name: 'Ghost Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Ghost.png` },
    { name: 'Psychic Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Psychic.png` },
    { name: 'Ice Badge', sprite: `${BULBA}SVbadge_VictoryRoad_Ice.png` },
  ]
}
