import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  catchError,
  map,
  Observable,
  of,
  shareReplay,
  switchMap,
  throwError,
} from 'rxjs';

import { PokemonItem } from '../../interfaces/pokemon-item';
import { PokemonService } from '../pokemon-service/pokemon.service';
import { TrainerService } from '../trainer-service/trainer.service';

export interface MegaForm {
  /** PokeAPI Pokémon id of the Mega form (or base id for custom-only forms). */
  pokemonId: number;
  /** Pokémon identifier (e.g. "charizard-mega-x", "raichu-mega-x"). */
  apiName: string;
  /** Display name (e.g. "Mega Charizard X"). */
  displayName: string;

  /** Optional sprite overrides (useful for custom forms not present in PokeAPI). */
  spriteUrl?: string;
  shinySpriteUrl?: string;

  /** Where this form came from. */
  source?: 'pokeapi' | 'custom';
}

interface CustomMegaFormsFile {
  version?: number;
  forms?: CustomMegaFormDefinition[];
}

interface CustomMegaFormDefinition {
  basePokemonId: number;
  apiName: string;
  displayName: string;
  pokemonId?: number;
  spriteUrl?: string;
  shinySpriteUrl?: string;
}

interface PokemonSpeciesResponse {
  varieties: Array<{
    is_default: boolean;
    pokemon: {
      name: string;
      url: string;
    };
  }>;
}

@Injectable({
  providedIn: 'root',
})
export class MegaEvolutionService {
  private readonly apiBaseUrl = 'https://pokeapi.co/api/v2';

  /** Cache mega forms by species id to avoid re-fetching every battle. */
  private megaFormsBySpeciesId = new Map<number, Observable<MegaForm[]>>();
  private customMegaFormsByBaseId$?: Observable<Map<number, MegaForm[]>>;

  /** Only one Mega per battle (by design). */
  private currentMegaPokemon: PokemonItem | null = null;

  constructor(
    private http: HttpClient,
    private pokemonService: PokemonService,
    private trainerService: TrainerService
  ) {}

  private loadCustomMegaFormsByBaseId(): Observable<Map<number, MegaForm[]>> {
    if (this.customMegaFormsByBaseId$) return this.customMegaFormsByBaseId$;

    // Optional file. If missing/invalid, we just treat as no custom forms.
    this.customMegaFormsByBaseId$ = this.http
      .get<CustomMegaFormsFile>('./data/custom-mega-forms.json')
      .pipe(
        map((file) => {
          const byBaseId = new Map<number, MegaForm[]>();
          const forms = file?.forms ?? [];

          for (const def of forms) {
            if (!def) continue;
            const baseId = Number(def.basePokemonId);
            if (!Number.isFinite(baseId) || baseId <= 0) continue;
            if (!def.apiName || !def.displayName) continue;

            const form: MegaForm = {
              // If a custom form doesn't have a dedicated id, we keep baseId so the game
              // remains stable (Mega state is still tracked via megaBackup).
              pokemonId: Number.isFinite(Number(def.pokemonId)) ? Number(def.pokemonId) : baseId,
              apiName: def.apiName,
              displayName: def.displayName,
              spriteUrl: def.spriteUrl,
              shinySpriteUrl: def.shinySpriteUrl,
              source: 'custom',
            };

            const list = byBaseId.get(baseId) ?? [];
            list.push(form);
            byBaseId.set(baseId, list);
          }

          // Stable order for UI.
          for (const [k, list] of byBaseId.entries()) {
            list.sort((a, b) => a.displayName.localeCompare(b.displayName));
            byBaseId.set(k, list);
          }

          return byBaseId;
        }),
        catchError(() => of(new Map<number, MegaForm[]>())),
        shareReplay(1)
      );

    return this.customMegaFormsByBaseId$;
  }

  /** Returns all Mega forms available for the given Pokémon. */
  getMegaFormsForPokemon(pokemon: PokemonItem): Observable<MegaForm[]> {
    const speciesId = pokemon.basePokemonId ?? pokemon.pokemonId;

    const cached = this.megaFormsBySpeciesId.get(speciesId);
    if (cached) return cached;

    const request$ = this.loadCustomMegaFormsByBaseId().pipe(
      switchMap((customByBaseId) =>
        this.http.get<PokemonSpeciesResponse>(`${this.apiBaseUrl}/pokemon-species/${speciesId}/`).pipe(
          map((response) => {
            const fromApi: MegaForm[] = (response?.varieties ?? [])
              // IMPORTANT: "mega" must be a hyphen-delimited form segment ("-mega", "-mega-x", etc.).
              // Otherwise Pokémon whose base name contains the substring "mega" (e.g. "meganium")
              // would be incorrectly treated as having a Mega form.
              .filter((v) => (v?.pokemon?.name ?? '').includes('-mega'))
              .map((v) => {
                const apiName = v.pokemon.name;
                const id = this.extractIdFromUrl(v.pokemon.url);
                return {
                  pokemonId: id > 0 ? id : speciesId,
                  apiName,
                  displayName: this.formatMegaDisplayName(apiName),
                  source: 'pokeapi' as const,
                } as MegaForm;
              });

            const custom: MegaForm[] = (customByBaseId.get(speciesId) ?? []).map((f) => ({
              ...f,
              source: f.source ?? ('custom' as const),
            }));

            // Merge + dedupe by apiName. Custom entries override others if they share apiName.
            const byName = new Map<string, MegaForm>();
            for (const f of [...fromApi, ...custom]) {
              byName.set(f.apiName, f);
            }

            return Array.from(byName.values()).sort((a, b) =>
              a.displayName.localeCompare(b.displayName)
            );
          }),
          catchError((error) => {
            console.error('Failed to fetch Mega forms for species', speciesId, error);

            const custom: MegaForm[] = (customByBaseId.get(speciesId) ?? []).map((f) => ({
              ...f,
              source: f.source ?? ('custom' as const),
            }));

            const byName = new Map<string, MegaForm>();
            for (const f of custom) {
              byName.set(f.apiName, f);
            }
            return of(Array.from(byName.values()));
          })
        )
      ),
      shareReplay(1)
    );

    this.megaFormsBySpeciesId.set(speciesId, request$);
    return request$;
  }

  /** Applies Mega Evolution for the current battle. */
  megaEvolveForBattle(pokemon: PokemonItem, megaForm: MegaForm): Observable<void> {
    this.revertCurrentMegaEvolution();

    pokemon.megaBackup = {
      text: pokemon.text,
      sprite: pokemon.sprite,
      power: pokemon.power,
    };

    const megaPower: 5 | 6 = pokemon.power === 5 ? 6 : 5;

    // Custom sprite override path (fast).
    if (megaForm.spriteUrl) {
      pokemon.sprite = {
        front_default: megaForm.spriteUrl,
        front_shiny: megaForm.shinySpriteUrl ?? megaForm.spriteUrl,
      };
      pokemon.text = megaForm.displayName;
      pokemon.power = megaPower;
      pokemon.isMegaEvolved = true;
      this.currentMegaPokemon = pokemon;

      this.trainerService.updateTeam();
      return of(void 0);
    }

    // Default path: prefer PokeAPI by name.
    const sprite$ = this.pokemonService.getPokemonSpritesByName(megaForm.apiName).pipe(
      // Last resort: base species artwork.
      catchError(() => this.pokemonService.getPokemonSprites(megaForm.pokemonId))
    );

    return sprite$.pipe(
      map((result) => {
        pokemon.sprite = result.sprite;
        pokemon.text = megaForm.displayName;
        pokemon.power = megaPower;
        pokemon.isMegaEvolved = true;
        this.currentMegaPokemon = pokemon;

        this.trainerService.updateTeam();
      }),
      catchError((error) => {
        console.error('Failed to mega evolve', pokemon, megaForm, error);
        this.revertCurrentMegaEvolution();
        return throwError(() => error);
      })
    );
  }

  /** Reverts the currently Mega-Evolved Pokémon (if any). Call this after a battle ends. */
  revertCurrentMegaEvolution(): void {
    const pokemon = this.currentMegaPokemon;
    if (!pokemon?.megaBackup) {
      this.currentMegaPokemon = null;
      return;
    }

    pokemon.text = pokemon.megaBackup.text;
    pokemon.sprite = pokemon.megaBackup.sprite;
    pokemon.power = pokemon.megaBackup.power;
    pokemon.isMegaEvolved = false;
    delete pokemon.megaBackup;

    this.currentMegaPokemon = null;

    this.trainerService.updateTeam();
  }

  /** Backwards-compatible name used by older callers. */
  revertMegaEvolution(): void {
    this.revertCurrentMegaEvolution();
  }

  /** Extracts numeric id from a PokeAPI resource URL. Returns 0 if parsing fails. */
  private extractIdFromUrl(url: string): number {
    try {
      const parts = url.split('/').filter(Boolean);
      const idStr = parts[parts.length - 1];
      const id = Number(idStr);
      return Number.isFinite(id) ? id : 0;
    } catch {
      return 0;
    }
  }

  private formatMegaDisplayName(apiName: string): string {
    const parts = apiName.split('-').filter(Boolean);
    const megaIndex = parts.indexOf('mega');

    if (megaIndex === -1) {
      return this.toTitleCase(parts.join(' '));
    }

    const baseName = parts.slice(0, megaIndex).join(' ');
    const suffixParts = parts.slice(megaIndex + 1);

    const suffix = suffixParts
      .map((p) => (['x', 'y', 'z'].includes(p) ? p.toUpperCase() : this.capitalize(p)))
      .join(' ');

    return `Mega ${this.toTitleCase(baseName)}${suffix ? ` ${suffix}` : ''}`;
  }

  private toTitleCase(str: string): string {
    return str
      .split(' ')
      .filter(Boolean)
      .map((w) => this.capitalize(w))
      .join(' ');
  }

  private capitalize(word: string): string {
    if (!word) return word;
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

}
