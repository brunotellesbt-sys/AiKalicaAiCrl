import { Component, ChangeDetectionStrategy } from '@angular/core';

import { TranslatePipe } from '@ngx-translate/core';

import {
  Competitor,
  TournamentGroup,
  TournamentMatch,
  TournamentService,
} from '../../services/tournament-service/tournament.service';

/**
 * The tournament table, shown inside the PC while a tournament is running.
 *
 * The World Tournament shows group standings until the groups are done and the bracket
 * after that; the regional tournament only ever has a bracket.
 */
@Component({
  selector: 'app-tournament-bracket',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './tournament-bracket.component.html',
  changeDetection: ChangeDetectionStrategy.Eager,
  styleUrl: './tournament-bracket.component.css',
})
export class TournamentBracketComponent {
  constructor(private tournamentService: TournamentService) {}

  get isActive(): boolean {
    return this.tournamentService.kind !== null;
  }

  get kindLabel(): string {
    return `game.main.tournament.kind.${this.tournamentService.kind ?? 'regional'}`;
  }

  get stageLabel(): string {
    return `game.main.tournament.phase.${this.tournamentService.stage}`;
  }

  get groups(): TournamentGroup[] {
    return this.tournamentService.groupTable;
  }

  get rounds(): TournamentMatch[][] {
    return this.tournamentService.bracket;
  }

  get showGroups(): boolean {
    return this.groups.length > 0;
  }

  /** Labels the bracket rounds from the back: 8 matches = round of 16, 1 = final. */
  roundLabel(round: TournamentMatch[]): string {
    return `game.main.tournament.round.${round.length}`;
  }

  displayName(competitor: Competitor | null | undefined): string {
    return competitor?.name ?? '';
  }

  isTranslationKey(name: string): boolean {
    return name.includes('.');
  }

  isPlayer(competitor: Competitor | null | undefined): boolean {
    return !!competitor?.isPlayer;
  }

  isWinner(match: TournamentMatch, competitor: Competitor | null | undefined): boolean {
    return !!competitor && !!match.winner && match.winner.id === competitor.id;
  }
}
