export interface EncounterCharacter {
  name: string;
  spriteUrl: string;
  blurb: string;
}

export interface VillainTeamEncounter {
  teamName: string;
  leaders: EncounterCharacter[];
  blurb: string;
}

export interface RoadblockEncounter {
  pokemonId: number;
  pokemonNameKey: string;
  blurb: string;
}

/**
 * "Battle Trainer" flavor encounters (used by the battle-trainer event).
 * Some generations have multiple possibilities (Gen 5: Bianca OR Cheren).
 */
export const battleTrainerByGeneration: Record<number, EncounterCharacter[]> = {
  1: [
    {
      name: 'Yellow',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/yellow.png',
      blurb: 'trainer.blurb.yellow',
    },
  ],
  2: [
    {
      // Use Eugene (Eusine) for the Gen 2 "Battle Trainer" encounter.
      name: 'Eugene',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/eusine.png',
      blurb: 'trainer.blurb.eugene',
    },
  ],
  3: [
    {
      name: 'Wally',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/wally.png',
      blurb: 'trainer.blurb.wally',
    },
  ],
  4: [
    {
      name: 'Looker',
      // No Showdown sprite exists for Looker, and Bulbagarden Archives answers 403 to
      // browsers (hotlink protection), so we ship the sprite with the app.
      spriteUrl: './trainers/custom/looker.png',
      blurb: 'trainer.blurb.looker',
    },
  ],
  5: [
    {
      name: 'Bianca',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/bianca.png',
      blurb: 'trainer.blurb.bianca',
    },
    {
      name: 'Cheren',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/cheren.png',
      blurb: 'trainer.blurb.cheren',
    },
  ],
  6: [
    {
      name: 'Trevor',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/trevor.png',
      blurb: 'trainer.blurb.trevor',
    },
  ],
  7: [
    {
      name: 'Hau',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/hau.png',
      blurb: 'trainer.blurb.hau',
    },
  ],
  8: [
    {
      name: 'Hop',
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/hop.png',
      blurb: 'trainer.blurb.hop',
    },
  ],
  9: [
    {
      name: 'Cassiopeia',
      // Cassiopeia is Penny (use Penny sprite)
      spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/penny.png',
      blurb: 'trainer.blurb.cassiopeia',
    },
  ],
};

/**
 * Villain Team encounters (replaces the old "Team Rocket" encounter).
 * Some generations can randomize between version-exclusive teams.
 */
export const villainTeamByGeneration: Record<number, VillainTeamEncounter> = {
  1: {
    teamName: 'Team Rocket',
    leaders: [
      {
        name: 'Giovanni',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/giovanni.png',
        blurb: 'The boss of Team Rocket. Beware!',
      },
    ],
    blurb: 'A shady organization tries to steal your Pokémon!',
  },
  2: {
    teamName: 'Team Rocket',
    leaders: [
      {
        name: 'Proton',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/proton.png',
        blurb: 'A Team Rocket executive is causing trouble.',
      },
    ],
    blurb: 'Team Rocket is back again in Johto.',
  },
  3: {
    teamName: 'Team Magma / Team Aqua',
    leaders: [
      {
        name: 'Maxie',
        // Showdown has no plain "maxie.png"; the ORAS sprite is the -gen6 variant.
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/maxie-gen6.png',
        blurb: 'Team Magma wants to expand the land.',
      },
      {
        name: 'Archie',
        // Same as Maxie: only the -gen6 (ORAS) sprite exists on Showdown.
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/archie-gen6.png',
        blurb: 'Team Aqua wants to expand the sea.',
      },
    ],
    blurb: 'Two rival villain teams can appear, depending on the version.',
  },
  4: {
    teamName: 'Team Galactic',
    leaders: [
      {
        name: 'Cyrus',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/cyrus.png',
        blurb: "Team Galactic's cold and calculating leader.",
      },
    ],
    blurb: 'Team Galactic wants to reshape the world.',
  },
  5: {
    teamName: 'Team Plasma',
    leaders: [
      {
        name: 'Ghetsis',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/ghetsis.png',
        blurb: 'The true mastermind behind Team Plasma.',
      },
    ],
    blurb: 'Team Plasma is here to cause chaos.',
  },
  6: {
    teamName: 'Team Flare',
    leaders: [
      {
        name: 'Lysandre',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/lysandre.png',
        blurb: 'The stylish but dangerous Team Flare leader.',
      },
    ],
    blurb: 'Team Flare is plotting something huge.',
  },
  7: {
    teamName: 'Team Skull',
    leaders: [
      {
        name: 'Guzma',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/guzma.png',
        blurb: 'The boss of Team Skull.',
      },
    ],
    blurb: 'Team Skull grunts block your way and start trouble.',
  },
  8: {
    teamName: 'Macro Cosmos',
    leaders: [
      {
        name: 'Chairman Rose',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/rose.png',
        blurb: 'The chairman behind Macro Cosmos.',
      },
    ],
    blurb: 'A corporate villain shows up at the worst time.',
  },
  9: {
    teamName: 'Team Star',
    leaders: [
      {
        name: 'Cassiopeia',
        spriteUrl: 'https://play.pokemonshowdown.com/sprites/trainers/penny.png',
        blurb: 'The mysterious boss of Team Star.',
      },
    ],
    blurb: 'Team Star is challenging trainers across Paldea.',
  },
};

/**
 * "Snorlax" encounter reskin: a generation-themed roadblock/tool/comic Pokémon.
 */
export const roadblockByGeneration: Record<number, RoadblockEncounter> = {
  1: {
    pokemonId: 143,
    pokemonNameKey: 'pokemon.snorlax',
    blurb: 'A sleeping roadblock Pokémon.',
  },
  2: {
    pokemonId: 185,
    pokemonNameKey: 'pokemon.sudowoodo',
    blurb: 'The odd tree that blocks your way.',
  },
  3: {
    pokemonId: 352,
    pokemonNameKey: 'pokemon.kecleon',
    blurb: 'It was invisible… until you got close.',
  },
  4: {
    pokemonId: 54,
    pokemonNameKey: 'pokemon.psyduck',
    blurb: 'A pack of Psyduck blocks the road with headaches.',
  },
  5: {
    pokemonId: 558,
    pokemonNameKey: 'pokemon.crustle',
    blurb: 'Crustle are in the way. Watch your step.',
  },
  6: {
    // Gen 6: use a "tool" Pokémon from Kalos (Gogoat Shuttle).
    pokemonId: 673,
    pokemonNameKey: 'pokemon.gogoat',
    blurb: 'A Gogoat shuttle is blocking the street for a moment.',
  },
  7: {
    // Gen 7: Poké Ride partner
    pokemonId: 508,
    pokemonNameKey: 'pokemon.stoutland',
    blurb: 'Stoutland stops to sniff around and blocks the path.',
  },
  8: {
    pokemonId: 831,
    pokemonNameKey: 'pokemon.wooloo',
    blurb: 'A runaway Wooloo is causing trouble on the road.',
  },
  9: {
    pokemonId: 915,
    pokemonNameKey: 'pokemon.lechonk',
    blurb: 'A herd of Lechonk is blocking the road in Paldea.',
  },
};
