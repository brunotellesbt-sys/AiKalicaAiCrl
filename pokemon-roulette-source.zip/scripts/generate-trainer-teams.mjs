#!/usr/bin/env node
/**
 * Regenerates src/app/data/trainer-teams.ts from Bulbapedia.
 *
 * The Type Advantage mode fields the roster each opponent actually uses in the games.
 * Rather than transcribing ~700 entries by hand (and silently getting some wrong), this
 * pulls the party templates straight off each trainer's page.
 *
 * Ordering matters: Bulbapedia lists parties chronologically, so the first entries are the
 * trainer's original team and the later ones come from rematches, remakes and the BW2
 * Pokémon World Tournament. Taking them in document order gives exactly the rule we want —
 * original team first, signature/PWT Pokémon only when more slots are needed.
 *
 * Run with: node scripts/generate-trainer-teams.mjs
 */
import fs from 'node:fs/promises';

const UA = {
  'user-agent': 'pokemon-roulette-data/1.0 (+https://github.com/zeroxm/pokemon-roulette)',
};

/** Some opponents are a combined slot in this game; merge every page listed. */
const GYM_LEADERS = {
  1: [['brock', 'Brock'], ['misty', 'Misty'], ['surge', 'Lt. Surge'], ['erika', 'Erika'],
      ['koga', 'Koga'], ['sabrina', 'Sabrina'], ['blaine', 'Blaine'], ['giovanni', 'Giovanni']],
  2: [['falkner', 'Falkner'], ['bugsy', 'Bugsy'], ['whitney', 'Whitney'], ['morty', 'Morty'],
      ['chuck', 'Chuck'], ['jasmine', 'Jasmine'], ['pryce', 'Pryce'], ['clair', 'Clair']],
  3: [['roxanne', 'Roxanne'], ['brawly', 'Brawly'], ['wattson', 'Wattson'], ['flannery', 'Flannery'],
      ['norman', 'Norman'], ['winona', 'Winona'], ['liza-tate', 'Tate and Liza'], ['juan', 'Juan']],
  4: [['roark', 'Roark'], ['gardenia', 'Gardenia'], ['maylene', 'Maylene'], ['crasher-wake', 'Crasher Wake'],
      ['fantina', 'Fantina'], ['byron', 'Byron'], ['candice', 'Candice'], ['volkner', 'Volkner']],
  5: [['cilan-chili-cress', 'Cilan', 'Chili', 'Cress'], ['lenora', 'Lenora'], ['burgh', 'Burgh'],
      ['elesa', 'Elesa'], ['clay', 'Clay'], ['skyla', 'Skyla'], ['brycen', 'Brycen'],
      ['drayden-iris', 'Drayden', 'Iris']],
  6: [['viola', 'Viola'], ['grant', 'Grant'], ['korrina', 'Korrina'], ['ramos', 'Ramos'],
      ['clemont', 'Clemont'], ['valerie', 'Valerie'], ['olympia', 'Olympia'], ['wulfric', 'Wulfric']],
  7: [['ilima', 'Ilima'], ['hala', 'Hala'], ['lana-kiawe-mallow', 'Lana', 'Kiawe', 'Mallow'],
      ['olivia', 'Olivia'], ['sophocles-acerola', 'Sophocles', 'Acerola'], ['nanu', 'Nanu'],
      ['mina', 'Mina'], ['hapu', 'Hapu']],
  8: [['milo', 'Milo'], ['nessa', 'Nessa'], ['kabu', 'Kabu'], ['bea-allister', 'Bea', 'Allister'],
      ['bede', 'Bede'], ['gordie-melony', 'Gordie', 'Melony'], ['piers', 'Piers'], ['raihan', 'Raihan']],
  9: [['katy', 'Katy'], ['brassius', 'Brassius'], ['iono', 'Iono'], ['kofu', 'Kofu'],
      ['larry', 'Larry'], ['ryme', 'Ryme'], ['tulip', 'Tulip'], ['grusha', 'Grusha']],
};

const ELITE_FOUR = {
  1: [['loreilei', 'Lorelei'], ['bruno-gen1', 'Bruno'], ['agatha', 'Agatha'], ['lance', 'Lance']],
  2: [['will', 'Will'], ['koga', 'Koga'], ['bruno-gen2', 'Bruno'], ['karen', 'Karen']],
  3: [['sidney', 'Sidney'], ['phoebe', 'Phoebe'], ['glacia', 'Glacia'], ['drake', 'Drake']],
  4: [['aaron', 'Aaron'], ['bertha', 'Bertha'], ['flint', 'Flint'], ['lucian', 'Lucian']],
  5: [['shauntal', 'Shauntal'], ['marshal', 'Marshal'], ['grimsley', 'Grimsley'], ['caitlin', 'Caitlin']],
  6: [['malva', 'Malva'], ['siebold', 'Siebold'], ['wikstrom', 'Wikstrom'], ['drasna', 'Drasna']],
  7: [['molayne', 'Molayne'], ['olivia', 'Olivia'], ['acerola', 'Acerola'], ['kahili', 'Kahili']],
  8: [['marnie', 'Marnie'], ['nessa', 'Nessa'], ['bea', 'Bea'], ['raihan', 'Raihan']],
  9: [['rika', 'Rika'], ['poppy', 'Poppy'], ['larry', 'Larry'], ['hassel', 'Hassel']],
};

const CHAMPIONS = {
  1: ['Blue (game)'], 2: ['Lance'], 3: ['Wallace'], 4: ['Cynthia'], 5: ['Alder'],
  6: ['Diantha'], 7: ['Professor Kukui'], 8: ['Leon'], 9: ['Geeta'],
};

const VILLAIN_BOSSES = {
  1: ['Giovanni'], 2: ['Giovanni'], 3: ['Maxie', 'Archie'], 4: ['Cyrus'], 5: ['Ghetsis'],
  6: ['Lysandre'], 7: ['Guzma'], 8: ['Rose'], 9: ['Penny'],
};

/**
 * Roadside "Battle Trainer" encounters, matching data/generation-encounters.ts.
 * Generations that field two (Unova's Bianca and Cheren) merge both rosters.
 */
const BATTLE_TRAINERS = {
  1: ['Yellow (Adventures)'], 2: ['Eusine'], 3: ['Wally'], 4: ['Looker'],
  5: ['Bianca', 'Cheren'], 6: ['Trevor'], 7: ['Hau'], 8: ['Hop'], 9: ['Penny'],
};

const RIVALS = {
  1: ['Blue (game)'], 2: ['Silver (game)'], 3: ['Wally'], 4: ['Barry (game)'], 5: ['Hugh'],
  6: ['Calem (game)'], 7: ['Gladion'], 8: ['Hop'], 9: ['Nemona'],
};

/**
 * Rosters Bulbapedia does not expose in a party template, transcribed by hand.
 *
 * Yellow is a Pokémon Adventures (manga) character and has no game party anywhere; Looker's
 * Pokémon are described in prose rather than a {{Pokémon}} block. Without these the two
 * encounters fall back to a randomly filled regional team, which is not the character.
 *
 * Keyed by the same label teamFor() reports.
 */
const MANUAL_ROSTERS = {
  // Yellow (Pokémon Adventures): Pika, Ratty, Dody, Gravvy, Kitty, Omny.
  'battleTrainer gen1': { ids: [25, 20, 85, 76, 12, 139], ace: 25 },
  // Looker: Croagunk is his signature across Platinum, X/Y and USUM.
  'battleTrainer gen4': { ids: [453], ace: 453 },
};

const failures = [];

async function wikitext(page) {
  const url = `https://bulbapedia.bulbagarden.net/w/api.php?action=parse&page=${encodeURIComponent(page)}&prop=wikitext&format=json`;
  const res = await fetch(url, { headers: UA });
  if (!res.ok) return '';
  const json = await res.json();
  return json?.parse?.wikitext?.['*'] ?? '';
}

/**
 * National Dex ids of a trainer's game parties, in first-appearance order, plus the ace.
 *
 * The ace is the highest-level Pokémon of the trainer's *first* listed party — that is the
 * signature the leader is built around, and it is the one that Mega Evolves in game.
 */
function gameParty(wt, allowAdaptations = false) {
  // Anime / manga / TCG sections list different Pokémon, so games come first.
  // A few opponents only ever existed outside the games — Yellow is a manga character and
  // Looker's game parties are not in a party template — so those fall back to the wider
  // page rather than ending up with a randomly filled team.
  const cut = wt.search(/\n==\s*In the (anime|manga|TCG)/i);
  const games = !allowAdaptations && cut > 0 ? wt.slice(0, cut) : wt;

  const ids = [];
  const seen = new Set();

  let ace = 0;
  let aceLevel = -1;
  let firstPartyEnd = Infinity;

  // Everything before the second {{Party}} block is the original team.
  const parties = [...games.matchAll(/\{\{Party\b/g)];
  if (parties.length > 1) firstPartyEnd = parties[1].index;

  for (const match of games.matchAll(/\{\{Pokémon\b[\s\S]*?\}\}\s*(?=\{\{|\n)/g)) {
    const block = match[0];
    const ndex = block.match(/\|\s*ndex\s*=\s*(\d+)/);
    if (!ndex) continue;
    const id = Number(ndex[1]);
    if (!id || id > 1025) continue;

    if (match.index < firstPartyEnd) {
      const lvl = Number(block.match(/\|\s*level\s*=\s*(\d+)/)?.[1] ?? 0);
      if (lvl > aceLevel) {
        aceLevel = lvl;
        ace = id;
      }
    }

    if (seen.has(id)) continue;
    seen.add(id);
    ids.push(id);
  }

  return { ids, ace: ace || ids[0] || 0 };
}

async function teamFor(pages, label) {
  const ids = [];
  const seen = new Set();
  let ace = 0;

  for (const page of pages) {
    const wt = await wikitext(page);
    if (!wt) {
      failures.push(`${label}: page "${page}" returned nothing`);
      continue;
    }
    let party = gameParty(wt);
    if (party.ids.length === 0) {
      // Nothing in the games section — take the anime/manga roster instead.
      party = gameParty(wt, true);
      if (party.ids.length) failures.push(`${label}: using anime/manga roster (no game party)`);
    }

    // The first page listed owns the ace (combined slots list the leader first).
    if (!ace && party.ace) ace = party.ace;
    for (const id of party.ids) {
      if (seen.has(id)) continue;
      seen.add(id);
      ids.push(id);
    }
    await new Promise((r) => setTimeout(r, 350)); // be polite to the wiki
  }

  if (ids.length === 0 && MANUAL_ROSTERS[label]) {
    const manual = MANUAL_ROSTERS[label];
    failures.push(`${label}: using the hand-written roster (nothing parseable on the wiki)`);
    return { ids: [...manual.ids], ace: manual.ace };
  }

  if (ids.length === 0) failures.push(`${label}: no Pokémon extracted`);
  else if (ids.length < 6) failures.push(`${label}: only ${ids.length} Pokémon (needs up to 6)`);

  return { ids, ace: ace || ids[0] || 0 };
}

function fmtGrouped(entries) {
  return entries
    .map(([gen, list]) => `  ${gen}: [\n${list.map(([key, t]) => `    /* ${key} */ [${t.ids.join(', ')}],`).join('\n')}\n  ],`)
    .join('\n');
}

function fmtGroupedAces(entries) {
  return entries.map(([gen, list]) => `  ${gen}: [${list.map(([, t]) => t.ace).join(', ')}],`).join('\n');
}

async function collectGrouped(source, label) {
  const out = [];
  for (const [gen, entries] of Object.entries(source)) {
    const list = [];
    for (const [key, ...pages] of entries) {
      const team = await teamFor(pages, `${label} gen${gen} ${key}`);
      list.push([key, team]);
      process.stderr.write(`${label} gen${gen} ${key}: ${team.ids.length} (ace ${team.ace})\n`);
    }
    out.push([gen, list]);
  }
  return out;
}

async function collectFlat(source, label) {
  const out = [];
  for (const [gen, pages] of Object.entries(source)) {
    const team = await teamFor(pages, `${label} gen${gen}`);
    out.push([gen, team]);
    process.stderr.write(`${label} gen${gen}: ${team.ids.length} (ace ${team.ace})\n`);
  }
  return out;
}

const gyms = await collectGrouped(GYM_LEADERS, 'gym');
const elite = await collectGrouped(ELITE_FOUR, 'e4');
const champs = await collectFlat(CHAMPIONS, 'champion');
const villains = await collectFlat(VILLAIN_BOSSES, 'villain');
const rivals = await collectFlat(RIVALS, 'rival');
const battleTrainers = await collectFlat(BATTLE_TRAINERS, 'battleTrainer');

const flat = (entries) => entries.map(([gen, t]) => `  ${gen}: [${t.ids.join(', ')}],`).join('\n');
const flatAce = (entries) => entries.map(([gen, t]) => `  ${gen}: ${t.ace},`).join('\n');

const file = `/**
 * Canonical opponent rosters, by National Dex id.
 *
 * GENERATED FILE — do not edit by hand.
 * Regenerate with: node scripts/generate-trainer-teams.mjs
 *
 * Scraped from each trainer's Bulbapedia page in document order, which means the list
 * starts with the team they originally use in the games and continues with rematch,
 * remake and BW2 Pokémon World Tournament Pokémon. Opponents that need more slots than
 * their original team had simply take the next entries.
 */

/** Eight gym leaders per generation, in gym order. */
export const gymLeaderTeamsByGeneration: Record<number, number[][]> = {
${fmtGrouped(gyms)}
};

/** Four Elite Four members per generation, in challenge order. */
export const eliteFourTeamsByGeneration: Record<number, number[][]> = {
${fmtGrouped(elite)}
};

export const championTeamsByGeneration: Record<number, number[]> = {
${flat(champs)}
};

export const villainBossTeamsByGeneration: Record<number, number[]> = {
${flat(villains)}
};

export const rivalTeamsByGeneration: Record<number, number[]> = {
${flat(rivals)}
};

/** Roadside Battle Trainer encounters. */
export const battleTrainerTeamsByGeneration: Record<number, number[]> = {
${flat(battleTrainers)}
};

/**
 * Signature Pokémon — the highest-level member of each trainer's original party.
 *
 * In Type Advantage mode the opponent Mega Evolves this one when it has a Mega form, the
 * same way these trainers do in the games.
 */
export const gymLeaderAcesByGeneration: Record<number, number[]> = {
${fmtGroupedAces(gyms)}
};

export const eliteFourAcesByGeneration: Record<number, number[]> = {
${fmtGroupedAces(elite)}
};

export const championAceByGeneration: Record<number, number> = {
${flatAce(champs)}
};

export const villainBossAceByGeneration: Record<number, number> = {
${flatAce(villains)}
};

export const rivalAceByGeneration: Record<number, number> = {
${flatAce(rivals)}
};

export const battleTrainerAceByGeneration: Record<number, number> = {
${flatAce(battleTrainers)}
};
`;

await fs.writeFile('src/app/data/trainer-teams.ts', file);
console.log('wrote src/app/data/trainer-teams.ts');

if (failures.length) {
  console.log(`\n${failures.length} warning(s):`);
  for (const f of failures) console.log('  - ' + f);
}
