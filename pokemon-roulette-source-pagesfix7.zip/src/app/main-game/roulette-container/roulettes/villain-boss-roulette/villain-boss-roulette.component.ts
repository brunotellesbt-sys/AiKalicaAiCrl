import { NgIf } from '@angular/common';
import {
  Component,
  EventEmitter,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { WheelItem } from '../../../../interfaces/wheel-item';
import { ImgFallbackDirective } from '../../../../shared/img-fallback.directive';
import { WheelComponent } from '../../../../wheel/wheel.component';
import { GenerationService } from '../../../../services/generation-service/generation.service';
import { villainTeamByGeneration } from '../../../../data/generation-encounters';

@Component({
  selector: 'app-villain-boss-roulette',
  imports: [WheelComponent, ImgFallbackDirective, NgIf],
  templateUrl: './villain-boss-roulette.component.html',
  styleUrl: './villain-boss-roulette.component.css',
})
export class VillainBossRouletteComponent implements OnInit {
  constructor(private modalService: NgbModal, private generationService: GenerationService) {}

  @Output() defeatVillainEvent = new EventEmitter<void>();
  /**
   * Losing the boss battle means the villain team steals one of your Pokémon.
   * (No "run away" option for this finale encounter.)
   */
  @Output() stealPokemonEvent = new EventEmitter<void>();

  @ViewChild('villainBossModal', { static: true })
  villainBossModal!: TemplateRef<any>;

  villainTeamName = 'Villain Team';
  villainTeamBlurb = '';
  villainLeaderName = '';
  villainLeaderSpriteUrl = '';
  villainLeaderBlurb = '';

  outcomes: WheelItem[] = [];

  ngOnInit(): void {
    const genId = this.generationService.getCurrentGeneration().id;
    const encounter = villainTeamByGeneration[genId] ?? villainTeamByGeneration[1];

    this.villainTeamName = encounter.teamName;
    this.villainTeamBlurb = encounter.blurb;

    const leaders = encounter.leaders ?? [];
    const leader = leaders[Math.floor(Math.random() * Math.max(leaders.length, 1))] ?? leaders[0];
    if (leader) {
      this.villainLeaderName = leader.name;
      this.villainLeaderSpriteUrl = leader.spriteUrl;
      this.villainLeaderBlurb = leader.blurb;
    }

    // Boss encounter: keep it simple and impactful.
    // 50/50 between "Defeat" and "Lose (they steal a Pokémon)".
    this.outcomes = [
      { text: `Defeat ${this.villainTeamName}`, fillStyle: 'green', weight: 1 },
      { text: `${this.villainTeamName} steals a Pokémon`, fillStyle: 'crimson', weight: 1 },
    ];

    this.modalService.open(this.villainBossModal, {
      centered: true,
      size: 'lg',
    });
  }

  onItemSelected(index: number): void {
    if (index === 0) {
      this.defeatVillainEvent.emit();
      return;
    }
    this.stealPokemonEvent.emit();
  }

  closeModal(): void {
    this.modalService.dismissAll();
  }
}
